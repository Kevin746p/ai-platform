package httpServer

import (
	"ai-platform-service/app/api"
	"ai-platform-service/config"
	"context"
	"fmt"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	"github.com/gogf/gf/util/gvalid"
)

type HttpServer struct {
	cfg    *config.ServerCfg
	ctx    context.Context
	cancel context.CancelFunc
	server *ghttp.Server
}

func (h *HttpServer) bindRouter() error {
	h.server.BindHandler("/actuator/:group/:action", api.HandlerFunc)
	h.server.BindHandler("/actuator/:group", api.HandlerFunc)
	for rule, ruleFunc := range api.CustomRules {
		if err := gvalid.RegisterRule(rule, ruleFunc); err != nil {
			g.Log().Error(fmt.Sprintf("[service][HttpServer] RegisterRule [%s] Failed , err :[%s]", rule, err.Error()))
			return err
		}
	}
	return nil
}

func (h *HttpServer) Init() {
	h.cfg = &config.Cfg.Server
	h.ctx, h.cancel = context.WithCancel(context.Background())
}

func (h *HttpServer) Start() error {
	h.server = g.Server()
	if err := h.server.SetConfigWithMap(g.Map{
		"Address":     h.cfg.Address,
		"ServerAgent": h.cfg.ServerAgent,
		"LogPath":     h.cfg.LogPath,
	}); err != nil {
		g.Log().Error("[service][HttpServer] g.Server SetConfigWithMap Failed : ", err)
		return err
	}
	if err := h.bindRouter(); err != nil {
		g.Log().Error("[service][HttpServer] g.Server bindRouter Failed : ", err)
		return err
	}
	go h.server.Run()
	return nil
}

func (h *HttpServer) Stop() error {
	h.cancel()
	return nil
}

func (h *HttpServer) Name() string { return "HttpServer" }
