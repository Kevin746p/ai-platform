package nacos

import (
	"testing"
)

// go test -v
func TestNacosGetInstance(t *testing.T) {
	// TODO
	//naocsClient := nacos.Nacos{
	//	cfg: &config.NacosCfg{
	//		Ip:          "10.114.242.31",
	//		Port:        699,
	//		ServiceName: "ai-platform",
	//		Weight:      10,
	//		DataID:      "ai-platform-service",
	//		Group:       "DEFAULT_GROUP",
	//		Enable:      true,
	//	},
	//}
	//assert.Equal(t, nil, naocsClient.newClient())
	//
	//_, err := naocsClient.namingClient.GetService(vo.GetServiceParam{
	//	ServiceName: "ai-platform",
	//})
	//assert.Equal(t, nil, err)
	//instances, err := naocsClient.getInstancesOrderByWeight(enum.OrderTypeAsc)
	//
	//assert.Equal(t, nil, err)
	//fmt.Println("Current Instances", instances)
}
