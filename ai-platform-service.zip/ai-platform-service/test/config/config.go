package config

import (
	"ai-platform-service/app/nacos"
	"ai-platform-service/config"
	"flag"
	"testing"

	"github.com/gogf/gf/frame/g"
)

func init() {
	var cfg string
	// 默认配置对象
	testing.Init()
	flag.StringVar(&cfg, "c", "./test/config/config.toml", "config file path")
	flag.Parse()
	g.Cfg().SetFileName(cfg)
	if err := config.GetCfg(); err != nil {
		g.Log().Error("[test][init] config init failed ", g.Cfg().GetFileName(), err.Error())
		return
	}
	nc := new(nacos.Nacos)
	nc.Init()
	nc.Start()
}
