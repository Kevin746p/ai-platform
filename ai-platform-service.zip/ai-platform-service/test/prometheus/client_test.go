package prometheus

import (
	"ai-platform-service/app/prometheus"
	_ "ai-platform-service/test/config"
	"fmt"
	"testing"

	"github.com/gogf/gf/util/gconv"

	"github.com/prometheus/common/model"

	"github.com/stretchr/testify/assert"
)

func TestQuery(t *testing.T) {
	pc := new(prometheus.Prometheus)
	pc.Init()
	assert.Equal(t, nil, pc.Start())

	err, data := pc.Query("count(count(DCGM_FI_DEV_FB_USED) by (resource_type ,UUID,GPU_I_ID)) by (resource_type)")

	assert.Equal(t, nil, err)
	var vector model.Vector
	err = gconv.Struct(data, &vector)

	for _, v := range vector {
		fmt.Println(v.Value)
	}

}
