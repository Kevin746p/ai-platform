package test

import (
	"ai-platform-service/app/cache"
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/nacos"
	"ai-platform-service/config"
	"ai-platform-service/httpServer"
	"fmt"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"testing"
	"time"

	"github.com/gogf/gf/frame/g"
	"github.com/stretchr/testify/assert"
)

type Service interface {
	Init()
	Start() error
	Stop() error
	Name() string
}

var services = []Service{
	new(database.DataBase),
	new(cache.Cache),
	new(k8s.K8sClient),
	new(httpServer.HttpServer),
}
var uid string

var TestServerConfig = "http://0.0.0.0:8080"

func run() error {
	if err := start(); err != nil {
		g.Log().Error(fmt.Sprintf("[test][run] service start failed %s", err.Error()))
		return err
	}

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGINT, syscall.SIGQUIT, syscall.SIGTERM)
	<-quit

	g.Log().Info("[test][run] got signal exit.")
	if err := stop(); err != nil {
		g.Log().Error(fmt.Sprintf("[test][run]  service stop failed %s", err.Error()))
		return err
	}
	return nil
}
func start() error {
	nacosService := new(nacos.Nacos)
	nacosService.Init()
	if err := nacosService.Start(); err != nil {
		return fmt.Errorf("%s : %w", nacosService.Name(), err)
	}
	g.Log().Info(fmt.Sprintf("[test][run]service %s start success", nacosService.Name()))
	if err := config.GetCfg(); err != nil {
		g.Log().Error("[test][start] config init failed ", g.Cfg().GetFileName(), err.Error())
		return err
	}
	for _, service := range services {
		service.Init()
		if err := service.Start(); err != nil {
			return fmt.Errorf("%s : %w", service.Name(), err)
		}
		g.Log().Info(fmt.Sprintf("[test][run] service %s start success", service.Name()))
	}
	return nil
}

func stop() error {
	for _, service := range services {
		if err := service.Stop(); err != nil {
			return fmt.Errorf("%s : %w", service.Name(), err)
		}
		g.Log().Info(fmt.Sprintf("[test][stop] service %s stop success", service.Name()))
	}
	return nil
}

func TestTaskApi(t *testing.T) {
	t.Log("start ...")
	assertObj := assert.New(t)
	go func() {
		fmt.Println("====协程启动服务====")
		err := run()
		assertObj.Nil(err, "---TestTaskApi-项目启动失败---")
	}()
	//等待服务启动....
	time.Sleep(10 * time.Second)
	//task创建接口调用测试
	_, err := taskPostApi()
	fmt.Println("====task创建接口调用测试====")
	assertObj.Nil(err, "---taskPostApi接口调用出错---")

	fmt.Println("====工作流提交测试====")
	var testParams = map[string]interface{}{
		"taskName":        "automl-trafficlightxc-train-6-14-1",
		"businessScene":   "1111",
		"gitUrl":          "http://git-auto.zeekrlife.com/zpilot/zdrive/perception/modules/network/environment.git",
		"branch":          "br_trafficlane_train_dev_shaoqb",
		"namespace":       "perception-project",
		"pNameValue":      "trafficlane",
		"gpuMode":         "A100",
		"gpuLimit":        16,
		"taskType":        1,
		"command":         "TRAIN",
		"env":             "'{\"model1\":\"\", \"model2\":\"\"}'",
		"datasetPath":     "/data/parking/1=6.txt",
		"modelPath":       "",
		"scriptPath":      "environment/traffic_light_detection.pytorch/",
		"baseImage":       "devops-harbor.zeekrlife.com/zeekr_automl/traffic_light_i·mage:baseline",
		"isPreprocessing": false,
		"testPath":        "'{\"train_name\":\"/data/perception/label_datasets/parking/train_list.txt\"}'",
		"BuildId":         "",
		"QueueId":         -1,
	}
	submitParams := map[string]string{
		"project":          "automl-trafficlightxc-train-6-14-1",
		"git_url":          "http://git-auto.zeekrlife.com/zpilot/zdrive/perception/modules/network/environment.git",
		"branch":           "br_trafficlane_train_dev_shaoqb",
		"gpu_mode":         "A100",
		"namespace":        "perception-project",
		"gpu_value":        "16",
		"pname_value":      "trafficlane",
		"run_command":      "TRAIN",
		"env":              "'{\"model1\":\"\", \"model2\":\"\"}'",
		"base_image":       "devops-harbor.zeekrlife.com/zeekr_automl/traffic_light_image:baseline",
		"script_path":      "environment/traffic_light_detection.pytorch/",
		"dataset_path":     "/data/parking/1=6.txt",
		"model_path":       "",
		"is_preprocessing": "0",
		"train_path":       "",
		"test_path":        "'{\"train_name\":\"/data/perception/label_datasets/parking/train_list.txt\"}'",
	}
	workflowName, workflowID, err := submitWorkFlow(submitParams)
	assertObj.Nil(err, "---工作流提交测试出错：%v---", err)
	// argo 工作流提交测试
	fmt.Println("====argo工作流提交测试====")
	err = argoSubmitWorkflow(testParams)
	assertObj.Nil(err, "---argo工作流提交测试出错:---", err)

	// jenkins 工作流提交测试
	fmt.Println("====jenkins工作流提交测试====")
	err = jenkinsSubmitWorkflow(submitParams)
	assertObj.Nil(err, "---jenkins工作流提交测试出错:---", err)

	if config.Cfg.Workflow.MiddleWare == enum.MiddleWareArgo {
		testParams["BuildId"] = workflowID
	} else {
		qid, _ := strconv.Atoi(workflowID)
		testParams["QueueId"] = int64(qid)
	}
	fmt.Println("====数据入库测试====")
	ok, err := insertData(uid, workflowName, testParams)
	assertObj.True(ok, "---数据入库出错:%v---", err)

	fmt.Println("====数据查询测试====")
	ok = searchTargetData("69121630-497c-490c-9365-91da0868a1c5")
	assertObj.True(ok, "---数据查询出错---")

	// task获取接口测试
	fmt.Println("====task获取接口测试====")
	err = taskGet()
	assertObj.Nil(err, "---TaskGet-接口调用失败---")

	cache.SyncTaskInfo()
	fmt.Println(uid, "======================================")
	_, ok = cache.GetTaskInfo(uid)
	assertObj.True(ok, "---获取任务信息出错---")

	//task删除接口调用测试
	fmt.Println("====task删除接口调用测试====")
	err = taskDeleteApi()
	assertObj.Nil(err, "---DeleteTask-接口调用失败:%v---", err)

	pipelineID, err := taskPostApi()
	fmt.Println("=======删除测试用pipelineID：", pipelineID)
	assertObj.Nil(err, "---删除测试创建task失败:%v---", err)

	time.Sleep(2 * time.Second)
	cache.SyncTaskInfo()
	fmt.Println("====task获取pods接口测试====")
	taskInfo, ok := cache.GetTaskInfo("635d31b7-965f-4a25-8cee-c7fce4c75e3f")
	assertObj.True(ok, "---task获取pods接口测试---")

	switch taskInfo.Status {
	//case enum.TaskBuilding:
	//	ok, _ = jenkins.JClient.StopTask(taskInfo.BuildID, taskInfo.WorkflowName)
	//	assertObj.True(ok, "---jenkins停止任务出错---")
	//
	//case enum.TaskRunning, enum.TaskPodPending:
	//	// argo需要删除workflow
	//	if taskInfo.Workflow == enum.MiddleWareArgo {
	//		err = k8s.K8s.DeleteJobByName(enum.MiddleWareArgo, taskInfo.WorkflowName, uid, 16) // 批量删除的参数
	//		assertObj.Nil(err, "---argo删除失败---")
	//	}
	//	err = k8s.K8s.DeleteJobByName(taskInfo.Namespace, taskInfo.TaskName+"-"+taskInfo.BuildID, uid, taskInfo.GpuLimit)
	//	assertObj.Nil(err, "---k8s删除job失败---")
	//case enum.TaskCanceled:
	//	fmt.Println(uid)
	//case enum.TaskWaiting:
	//
	//	_, err = jenkins.JClient.CancelQueuedTask(taskInfo.QueueID)
	//	assertObj.Nil(err, "---jenkins删除队列失败:%v---", err)
	//
	//	// argo需要删除workflow
	//	if taskInfo.Workflow == enum.MiddleWareArgo {
	//		err = k8s.K8s.DeleteJobByName(enum.MiddleWareArgo, taskInfo.WorkflowName, uid, 16) //
	//		assertObj.Nil(err, "---k8s删除job失败:%v---", err)
	//
	//	}
	default:
		fmt.Printf("ReqUuid：%v---DargoeleteJobByName:%v--%v", uid, enum.ErrCodeCancelNotSupport, fmt.Sprintf(enum.ErrDescCancelNotSupport, enum.TaskStatusMap[taskInfo.Status]))

	}
	err = taskGetPods()
	assertObj.Nil(err, "---获取taskPods出错：%v---", err)
}
