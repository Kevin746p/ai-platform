package test

import (
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"strings"
)

//request 接口测试
func taskGetPods() error {
	//Post请求示例
	url := TestServerConfig + "/actuator/task/pods"

	contentType := "application/json"
	data := `{
    "PipelineID": ["046f90b9-58af-4873-ad25-57af2f3abbe5"]
}`
	resp, err := http.Post(url, contentType, strings.NewReader(data))
	if err != nil {
		fmt.Println("post failed, err:", err)
		return err
	}
	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {
			fmt.Println(err)
		}
	}(resp.Body)
	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("get resp failed, err", err)
		return err
	}
	fmt.Println(string(b))
	return nil
}
