package test

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/utils"
	"ai-platform-service/app/workflow"
	"ai-platform-service/config"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"strconv"
	"strings"
	"time"

	wfv1 "github.com/argoproj/argo-workflows/v3/pkg/apis/workflow/v1alpha1"
	wfclientset "github.com/argoproj/argo-workflows/v3/pkg/client/clientset/versioned"
	"github.com/bndr/gojenkins"
	"github.com/gogf/gf/frame/g"
	"go.uber.org/zap"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/fields"
	"k8s.io/client-go/rest"
	"k8s.io/utils/pointer"
)

// 提交工作流
func submitWorkFlow(submitParams map[string]string) (workflowName, workflowID string, err error) {

	workflowName, workflowID, err = workflow.Wf.SubmitWorkflow(submitParams)
	return workflowName, workflowID, err
}

// 数据入库
func insertData(uid, workflowName string, params map[string]interface{}) (bool, error) {
	fmt.Println("====================入库pipelineID:", uid)
	if _, err := database.Train.DB.Model(model.Task{}).Save(&model.Task{
		PipelineID:    uid,
		QueueID:       params["QueueId"].(int64),
		TaskName:      params["taskName"].(string),
		BusinessScene: params["businessScene"].(string),
		Namespace:     params["namespace"].(string),
		Status:        enum.TaskWaiting,
		CreateTime:    time.Now(),
		ModifyTime:    time.Now(),
		GpuLimit:      params["gpuLimit"].(int),
		BuildID:       params["BuildId"].(string),
		Remark:        config.Cfg.Workflow.MiddleWare, // TODO 暂时使用remark标记使用的服务
		WorkflowName:  workflowName,                   // TODO 暂时保存workflow name
	}); err != nil {

		return false, err
	}
	return true, nil
}

// 查询数据是否入库
func searchTargetData(uid string) bool {
	record, _ := database.Train.DB.Model(model.Task{}).Where("pipeline_id = (?)", uid).One()

	fmt.Println(record)
	// TODO 数据校验下
	if record == nil {
		return false
	}
	return true

}

//Jenkins流
func jenkinsSubmitWorkflow(submitParams map[string]string) error {
	var err error

	type JenkinsClient struct {
		cfg    *config.JenkinsCfg
		Client *gojenkins.Jenkins
		ctx    context.Context
		cancel context.CancelFunc
	}

	jenkinsClientObj := JenkinsClient{
		cfg: &config.JenkinsCfg{
			URL:      config.Cfg.Jenkins.URL,
			Job:      config.Cfg.Jenkins.Job,
			MultiJob: config.Cfg.Jenkins.MultiJob,
			User:     config.Cfg.Jenkins.User,
			Pwd:      config.Cfg.Jenkins.Pwd,
			Enable:   true},
	}
	jenkinsClientObj.ctx, jenkinsClientObj.cancel = context.WithCancel(context.Background())
	jenkinsClientObj.Client, err = gojenkins.CreateJenkins(nil, jenkinsClientObj.cfg.URL, jenkinsClientObj.cfg.User, jenkinsClientObj.cfg.Pwd).Init(jenkinsClientObj.ctx)
	if err != nil {
		return err
	}
	qid, err := jenkinsClientObj.Client.BuildJob(jenkinsClientObj.ctx, jenkinsClientObj.cfg.MultiJob, submitParams)
	if err != nil {
		return err
	}
	g.Log().Info("build job succeed", zap.Any("param", submitParams))
	fmt.Printf("%d", qid)
	return nil

}
func isMultiGpuTask(gpuLimit int64) bool {
	return gpuLimit > enum.GpuNodeCount && gpuLimit%enum.GpuNodeCount == 0
}

// Argo流
func argoSubmitWorkflow(params map[string]interface{}) error {
	var host = config.Cfg.K8s.Host
	var token = config.Cfg.K8s.Token
	var namespace = "argo"
	var k8sCfg = rest.Config{
		Host:            host,
		BearerToken:     token,
		BearerTokenFile: "",
		TLSClientConfig: rest.TLSClientConfig{
			Insecure: true, // 设置为true时 不需要CA
		},
	}
	gpuLimit, _ := strconv.ParseInt(strconv.Itoa(params["gpuLimit"].(int)), 10, 64)

	workflowName := ""
	if isMultiGpuTask(gpuLimit) {
		workflowName = "zeekr-mm-argo"
	} else {
		workflowName = "zeekr-ad-argo"
	}
	buildId := utils.RandStringBytesMaskImpr(enum.BuildIDLength)
	var testWorkflow = wfv1.Workflow{
		ObjectMeta: metav1.ObjectMeta{
			Name: "hello-world-" + buildId,
		},
		Spec: wfv1.WorkflowSpec{
			Entrypoint: "whalesay",
			WorkflowTemplateRef: &wfv1.WorkflowTemplateRef{
				Name: workflowName,
			},
			Templates: []wfv1.Template{
				{
					Name: "whalesay",
					Container: &corev1.Container{
						Image:   "docker/whalesay:latest",
						Command: []string{"cowsay", "hello world"},
					},
				},
			},
		},
	}
	wfClient := wfclientset.NewForConfigOrDie(&k8sCfg).ArgoprojV1alpha1().Workflows(namespace)

	// submit the hello world workflow
	ctx := context.Background()
	createdWf, err := wfClient.Create(ctx, &testWorkflow, metav1.CreateOptions{})
	if err != nil {
		return err
	}

	fmt.Printf("workflow %s submitted\n", createdWf.Name)

	// submit the hello world workflow
	fieldSelector := fields.ParseSelectorOrDie(fmt.Sprintf("metadata.name=%s", createdWf.Name))
	watchIf, err := wfClient.Watch(ctx, metav1.ListOptions{FieldSelector: fieldSelector.String(), TimeoutSeconds: pointer.Int64(180)})
	if err != nil {
		return err
	}

	defer watchIf.Stop()
	for next := range watchIf.ResultChan() {
		wf, ok := next.Object.(*wfv1.Workflow)
		if !ok {
			continue
		}
		if !wf.Status.FinishedAt.IsZero() {
			fmt.Printf("Workflow %s %s at %v. Message: %s.\n", wf.Name, wf.Status.Phase, wf.Status.FinishedAt, wf.Status.Message)
			break
		}
	}
	return nil
}

type ResponseData struct {
	RetCode int
	Message string
	Data    map[string]string
	ReqUuid string
}

//request 接口测试
func taskPostApi() (pipelineID string, err error) {
	//Post请求示例
	url := TestServerConfig + "/ai-platform/actuator/task"
	contentType := "application/json"
	data := `{
    "taskName": "automl-trafficlightxc-train-6-14-1",
    "businessScene": "1111",
    "gitUrl": "http://git-auto.zeekrlife.com/zpilot/zdrive/perception/modules/network/environment.git",
    "branch": "br_trafficlane_train_dev_shaoqb",
    "namespace": "perception-project",
    "pNameValue": "trafficlane",
    "gpuMode": "A100",
    "gpuLimit": 16,
    "taskType": 1,
    "command": "TRAIN",
    "env":"'{\"model1\":\"\", \"model2\":\"\"}'",
    "datasetPath":"/data/parking/1=6.txt",
    "modelPath":"",
    "scriptPath":"environment/traffic_light_detection.pytorch/",
    "baseImage":"devops-harbor.zeekrlife.com/zeekr_automl/traffic_light_image:baseline",
    "isPreprocessing":false,
    "testPath":"'{\"train_name\":\"/data/perception/label_datasets/parking/train_list.txt\"}'"}`
	resp, err := http.Post(url, contentType, strings.NewReader(data))
	if err != nil {
		fmt.Println("post failed, err:", err)
		return "", err
	}
	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {
			fmt.Println(err)
		}
	}(resp.Body)
	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("get resp failed, err", err)
		return "", err
	}
	result := new(ResponseData)
	_ = json.Unmarshal(b, result)
	return result.Data["PipelineID"], nil
}
