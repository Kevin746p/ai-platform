package test

import (
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"net/url"
)

func taskGet() error {

	apiUrl := TestServerConfig + "/actuator/task"
	data := url.Values{}
	data.Set("PipelineID", "635d31b7-965f-4a25-8cee-c7fce4c75e3f")
	u, err := url.ParseRequestURI(apiUrl)
	if err != nil {
		return err
	}
	u.RawQuery = data.Encode()
	fmt.Println(u.String())
	resp, err := http.Get(u.String())
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {
			fmt.Println(err)
		}
	}(resp.Body)
	_, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("get resp failed, err:", err)
		return err
	}
	return nil
}
