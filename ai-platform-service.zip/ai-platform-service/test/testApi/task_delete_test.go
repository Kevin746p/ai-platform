package test

import (
	"fmt"
	"net/http"
	"net/url"
	"strings"
)

//request 接口测试
func taskDeleteApi() error {
	//Post请求示例
	pipelineID, err := taskPostApi()
	fmt.Println(pipelineID, "========================================")
	if err != nil {
		return err
	}
	targetUrl := TestServerConfig + "/actuator/task"
	data := url.Values{}
	data.Set("PipelineID", pipelineID)

	req, _ := http.NewRequest("DELETE", targetUrl, strings.NewReader(data.Encode()))

	_, err = http.DefaultClient.Do(req)
	if err != nil {

		fmt.Println(err, req, "-----------------------------------------")

		return err
	}
	// TODO 返回的数据校验
	return nil

}
