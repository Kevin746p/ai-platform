package k8s

import (
	"ai-platform-service/app/k8s"
	_ "ai-platform-service/test/config"
	"context"
	"fmt"
	"testing"

	pods "k8s.io/api/core/v1"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/stretchr/testify/assert"
)

// go test -v
func init() {
	k8sService := new(k8s.K8sClient)
	k8sService.Init()
	k8sService.Start()
}

func TestGetK8sMessage(t *testing.T) {
	assertObj := assert.New(t)

	namespace := "perception-project"
	testCase := []struct {
		eventName string
		want      string
		name      string
	}{
		{
			name:      "调度失败的pod",
			eventName: "automl-trafficlane-train-eventperform-1506", //pod
			want:      "0/14 nodes are available: 1 node(s) had taint {node-role.kubernetes.io/master: }, that the pod didn't tolerate, 1 node(s) had taint {node.kubernetes.io/disk-pressure: }, that the pod didn't tolerate, 3 Insufficient nvidia.com/gpu, 3 node(s) were unschedulable, 6 node(s) didn't match Pod's node affinity/selector.",
		},
		{
			name:      "没有事件",
			eventName: "automl-trafficlane-train-eventperform-1506", //job
			want:      "object has no event",
		},
	}
	for _, item := range testCase {
		message := k8s.K8s.GetLatestEventMessage(namespace, item.eventName, string(pods.PodFailed))
		assertObj.Equal(item.want, message)
	}

}

func TestGetJob(t *testing.T) {
	namespace := "perception-project"
	jobName := "sby-test-task-status-q2mpe"
	job, err := k8s.K8s.Client.BatchV1().Jobs(namespace).Get(context.Background(), jobName, metav1.GetOptions{})
	assert.Equal(t, nil, err)
	fmt.Println("======", job.Status.Active, job.Status.CompletionTime)
	for _, item := range job.Status.Conditions {
		fmt.Println(item)
	}
	//podList, err := k8s.K8s.Client.CoreV1().Pods(namespace).
	//	List(context.Background(), metav1.ListOptions{LabelSelector: fmt.Sprintf("job-name=%s", jobName)})
	//sort.Sort(sort.Reverse(k8s.PodList(podList.Items)))
	//for _, item := range podList.Items {
	//	fmt.Println(item.Status.Phase)
	//}
}

func TestGetEvent(t *testing.T) {
	namespace := "perception-project"
	jobName := "sby-test-task-status-ltbh7"
	//event := k8s.K8s.GetLatestEventMessage(namespace, jobName, string(pods.PodFailed))

	watch, err := k8s.K8s.Client.BatchV1().Jobs(namespace).Watch(context.Background(),
		metav1.ListOptions{FieldSelector: fmt.Sprintf("metadata.name=%s", jobName)})
	fmt.Println("====", err)
	for {
		result := <-watch.ResultChan()
		fmt.Println(fmt.Sprintf("+%v", result))

	}

}
func TestGetResourceStatus(t *testing.T) {

	//testCase := []struct {
	//	namespace    string
	//	jobName      string
	//	resourceType string
	//}{
	//	{
	//		namespace:    "kubeflow-perception",
	//		jobName:      "notebook-test-sby-u5qo1", //notebook
	//		resourceType: "Notebook",
	//	},
	//}
	//for _, item := range testCase {
	//	status, statusDesc := k8s.K8s.GetResourceStatus(item.namespace, item.resourceType, item.jobName)
	//	fmt.Println(status, statusDesc)
	//}
	k8s.K8s.GetAllNode()
}

func TestUpdateStatefulSetReplicas(t *testing.T) {

	testCase := []struct {
		namespace    string
		jobName      string
		resourceType string
	}{
		{
			namespace:    "perception-project",
			jobName:      "automl-trafficlane-train-ssasdadasdwsad-0y553", //notebook
			resourceType: "Job",
		},
	}
	for _, item := range testCase {
		err := k8s.K8s.DeleteResourceObject(item.namespace, item.jobName, item.resourceType)
		fmt.Println(err)
	}

}
