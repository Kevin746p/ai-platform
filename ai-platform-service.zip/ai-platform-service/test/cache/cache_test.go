package cache

import (
	"ai-platform-service/app/cache"
	"ai-platform-service/app/database"
	k8s2 "ai-platform-service/app/k8s"
	"ai-platform-service/app/prometheus"
	"fmt"
	"testing"
	"time"

	_ "ai-platform-service/test/config"

	"github.com/go-co-op/gocron"

	"github.com/stretchr/testify/assert"
)

func TestSyncGpuCache(t *testing.T) {
	cache.SyncGpuUnusedInfo()
	assert.Equal(t, int64(0), cache.GetGpuUnusedInfo("A101"))
}
func init() {
	cache := new(cache.Cache)
	database := new(database.DataBase)
	k8s := new(k8s2.K8sClient)
	prometheus := new(prometheus.Prometheus)
	cache.Init()
	database.Init()
	database.Start()
	k8s.Init()
	k8s.Start()
	prometheus.Init()
	prometheus.Start()

}
func TestSyncResourceGpuUsage(t *testing.T) {
	cache.SyncResourceGpuUsage()
}

var mockDelayTask = struct {
	runCount int
	next     bool
	Name     string
}{
	Name: "mockDelayTask",
}

func mockDelayTaskExec() {
	if mockDelayTask.next { // 跳过本次执行
		fmt.Println("task is running", time.Now())
	} else { //
		mockDelayTask.next = true
		fmt.Println("task start", time.Now())
		time.Sleep(15 * time.Second)
		fmt.Println("task end", time.Now())
		mockDelayTask.next = false
	}

}
func TestCronTaskStatusRunning(t *testing.T) {
	scheduler := gocron.NewScheduler(time.Local)
	_, err := scheduler.Every(10).Seconds().Do(mockDelayTaskExec)
	scheduler.StartAsync()
	for {
		if err != nil {
			assert.Equal(t, nil, err)
			return
		}
	}
}
