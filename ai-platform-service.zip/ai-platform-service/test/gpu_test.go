package test

import (
	"ai-platform-service/app/utils"
	"fmt"
	"testing"

	"github.com/gogf/gf/frame/g"
)

type Value []interface{}
type Metric struct {
	Gpu      string
	GpuMode  string
	HostName string
}
type ResultItem struct {
	Metric Metric
	Value  Value
}
type getGpuInfoResponse struct {
	Status string
	Data   struct {
		ResultType string
		Result     []ResultItem
	}
}

func TestGetGpuInfo_Do(t *testing.T) {
	resp := getGpuInfoResponse{}
	resp.Status = "success"
	resp.Data.ResultType = "vector"
	resp.Data.Result = append(resp.Data.Result, ResultItem{Metric: Metric{
		Gpu:      "5",
		GpuMode:  "A100",
		HostName: "gpu-metrics-exporter-42qcw",
	}, Value: Value{1658748848.585, "0"}}, ResultItem{Metric: Metric{
		Gpu:      "5",
		GpuMode:  "A100",
		HostName: "gpu-metrics-exporter-42qcw",
	}, Value: Value{1658748848.585, "0"}}, ResultItem{Metric: Metric{
		Gpu:      "5",
		GpuMode:  "A100",
		HostName: "gpu-metrics-exporter-42qcw",
	}, Value: Value{1658748848.585, "0"}}, ResultItem{Metric: Metric{
		Gpu:      "5",
		GpuMode:  "A100",
		HostName: "gpu-metrics-exporter-42qcw",
	}, Value: Value{1658748848.585, "0"}}, ResultItem{Metric: Metric{
		Gpu:      "1",
		GpuMode:  "A100",
		HostName: "gpu-metrics-exporter-42qcw",
	}, Value: Value{1658748848.585, "0"}})
	gpuModeCount := make(map[string]*struct {
		Count, NotUsed int64
		GpuList        []string
	})
	fmt.Println(resp)
	for _, eachGpuInfo := range resp.Data.Result {
		gpuCountKey := eachGpuInfo.Metric.GpuMode + "-" + eachGpuInfo.Metric.HostName + "-" + eachGpuInfo.Metric.Gpu
		if _, ok := gpuModeCount[eachGpuInfo.Metric.GpuMode]; ok {
			if !utils.IsExistString(gpuModeCount[eachGpuInfo.Metric.GpuMode].GpuList, gpuCountKey) {
				gpuModeCount[eachGpuInfo.Metric.GpuMode].Count += 1
				gpuModeCount[eachGpuInfo.Metric.GpuMode].GpuList = append(gpuModeCount[eachGpuInfo.Metric.GpuMode].GpuList, gpuCountKey)
			}

		} else {
			gpuModeCount[eachGpuInfo.Metric.GpuMode] = new(struct {
				Count, NotUsed int64
				GpuList        []string
			})
			gpuModeCount[eachGpuInfo.Metric.GpuMode].Count = 1
			gpuModeCount[eachGpuInfo.Metric.GpuMode].GpuList = append(gpuModeCount[eachGpuInfo.Metric.GpuMode].GpuList, gpuCountKey)

		}
	}
	if gpuModeCount["A100"].Count == 2 {
		fmt.Println("正确")
	} else {
		t.Fatalf("出错了")
	}
}
func TestGClient(t *testing.T) {
	_, err := g.Client().Get("https://git-devops.zee111krlife.com/devops/pipeline/-/raw/dev/GPU/ZEEKR-AD/deploy-dist.yaml")
	fmt.Println("====", err)
}
