# ai-platform-service

模型训练调度服务。对接模型训练业务方,串联训练流程，提供模型训练底层资源支持。
## 功能列表
- [x] 提供训练任务CRUD服务API 
- [x] 支持pytorchJob，Notebook 等自定义资源CRUD
- [x] 支持全局任务节点亲和性调度
- [x] 任务数据详细信息归档mysql
- [x] GPU监控信息获取
    - [x] GPU节点平均使用率，卡数，pod占用情况等

## TODO List
P2 
- [x] 启动包引用
- [x] 配置项归一化，迁移至nacos，支持部分动态更新
    -[x] 需要初始化连接信息的配置，如mysql IP更新后需要重启服务
- [x] 单个服务开关 
- [x] 服务多节点部署，状态更新逻辑只需单节点运行
- [x] 镜像当前123M 确认是否可以优化
- [ ] 补齐单测
- [x] 日志收集/查询
- [x] 云cicd
- [ ] 任务排队，优先级
- [ ] 节点亲和性软调度 

P1 
- [x] k8s /argo 资源回收（k8s的GC）ttl回收策略已加
- [x] mysql 任务记录表结构设计，字段整理
- [x] 获取任务信息，不要从缓存获取,多节点部署导致查询任务状态返回结果不一致
- [ ] redis 分布式锁 - 解决服务启动后cron延时问题
- [x] cron 更新覆盖上次任务，增加进行中判断 
- [ ] 服务更新后，原有pod处于删除中状态，nacos服务未下线，下线前部分服务不可用



## others 
- 业务方模型训练部署参考yaml
[单机任务](https://git-devops.zeekrlife.com/devops/pipeline/-/blob/dev/GPU/ZEEKR-AD/deploy.yaml
)
[多机任务](https://git-devops.zeekrlife.com/devops/pipeline/-/blob/dev/GPU/ZEEKR-MM/deploy.yaml
)

