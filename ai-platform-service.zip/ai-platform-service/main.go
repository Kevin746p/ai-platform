package main

import (
	"ai-platform-service/app/cache"
	"ai-platform-service/app/database"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/nacos"
	"ai-platform-service/app/prometheus"
	"ai-platform-service/app/workflow"
	"ai-platform-service/config"
	"ai-platform-service/httpServer"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"github.com/gogf/gf/frame/g"
)

type Service interface {
	Init()
	Start() error
	Stop() error
	Name() string
}

//  注意，nacos需要最先启动获取配置
var services = []Service{
	new(nacos.Nacos),
	new(database.DataBase),
	new(prometheus.Prometheus),
	new(k8s.K8sClient),
	new(cache.Cache),
	new(workflow.Workflow),
	new(httpServer.HttpServer),
}

// 初始化默认配置文件
func init() {
	var cfg string
	// 默认配置对象
	flag.StringVar(&cfg, "c", "./config/myconfig.toml", "config file path")
	flag.Parse()
	g.Cfg().SetFileName(cfg)

	if err := config.GetCfg(); err != nil {
		g.Log().Error(" [main][init] config init failed ", g.Cfg().GetFileName(), err.Error())
		return
	}

}
func main() {

	if err := start(); err != nil {
		g.Log().Error(fmt.Sprintf("[main][start] service start failed %s", err.Error()))
		return
	}

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGINT, syscall.SIGQUIT, syscall.SIGTERM, syscall.SIGKILL)
	<-quit

	g.Log().Info("Got Signal. Exit.")
	if err := stop(); err != nil {
		g.Log().Error(fmt.Sprintf("[main][start] service stop failed %s", err.Error()))
		return
	}
}

func start() error {
	for _, service := range services {
		service.Init()
		if err := service.Start(); err != nil {
			return fmt.Errorf("%s : %w", service.Name(), err)
		}
		g.Log().Info(fmt.Sprintf("service %s start success", service.Name()))
	}
	return nil
}
func stop() error {
	for _, service := range services {
		if err := service.Stop(); err != nil {
			return fmt.Errorf("%s : %w", service.Name(), err)
		}
		g.Log().Info(fmt.Sprintf("service %s stop success", service.Name()))
	}
	return nil
}
