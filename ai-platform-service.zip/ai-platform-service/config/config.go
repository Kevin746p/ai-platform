package config

import (
	"github.com/gogf/gf/frame/g"
)

var Cfg Config

type Config struct {
	Server      ServerCfg      `json:"Server"`
	Logger      LoggerCfg      `json:"Logger"`
	Mysql       MysqlCfg       `json:"Mysql"`
	Nacos       NacosCfg       `json:"Nacos"`
	K8s         K8sCfg         `json:"K8s"`
	ExternalUrl ExternalUrlCfg `json:"ExternalUrl"`
	Workflow    WorkflowCfg    `json:"Workflow"`
	Cache       CacheCfg       `json:"Cache"`
	Prometheus  PrometheusCfg  `json:"Prometheus"`
	GPUCalPower GPUCalPower    `json:"GPUCalPower"`
}

type ServerCfg struct {
	Address     string `json:"Address"`
	ServerAgent string `json:"ServerAgent"`
	LogPath     string `json:"LogPath"`
}

type LoggerCfg struct {
	Path              string   `json:"Path"`
	Level             string   `json:"Level"`
	Stdout            bool     `json:"Stdout"`
	WriterColorEnable bool     `json:"writerColorEnable"`
	CtxKeys           []string `json:"CtxKeys"`
}

type MysqlCfg struct {
	Host     string `json:"Host"`
	Port     int    `json:"Port"`
	Database string `json:"Database"`
	User     string `json:"User"`
	Pwd      string `json:"Pwd"`
	Type     string `json:"Type"`
	Timezone string `json:"Timezone"`
	Debug    bool   `json:"Debug"`
}

type NacosCfg struct {
	Ip          string  `json:"Ip"`
	Port        int     `json:"Port"`
	ServiceName string  `json:"ServiceName"`
	Weight      float64 `json:"Weight"`
	DataID      string  `json:"DataID"`
	Group       string  `json:"Group"`
	Enable      bool    `json:"Enable"`
}

type K8sCfg struct {
	Host                      string            `json:"Host"`
	Token                     string            `json:"Token"`
	DeployYaml                string            `json:"DeployYaml"`      // 单机任务部署yaml下载地址
	MultiDeployYaml           string            `json:"MultiDeployYaml"` // 多机多卡任务部署yaml下载地址
	WorkflowTemplateNamespace string            `json:"WorkflowTemplateNamespace"`
	WorkflowTemplateName      string            `json:"WorkflowTemplateName"`
	WorkflowMultiTemplateName string            `json:"WorkflowMultiTemplateName"` // 多机多卡任务
	JobGroup                  string            `json:"JobGroup"`
	JobVersion                string            `json:"JobVersion"`
	JobResource               string            `json:"JobResource"`
	JobKind                   string            `json:"JobKind"`
	PytorchJobGroup           string            `json:"PytorchJobGroup"`
	PytorchJobVersion         string            `json:"PytorchJobVersion"`
	PytorchJobResource        string            `json:"PytorchJobResource"`
	PytorchJobKind            string            `json:"PytorchJobKind"`
	NotebookGroup             string            `json:"NotebookGroup"`
	NotebookVersion           string            `json:"NotebookVersion"`
	NoteBookResource          string            `json:"NoteBookResource"`
	NoteBookKind              string            `json:"NoteBookKind"`
	PvcGroup                  string            `json:"PvcGroup"`
	PvcVersion                string            `json:"PvcVersion"`
	PvcResource               string            `json:"PvcResource"`
	PvcKind                   string            `json:"PvcKind"`
	Enable                    bool              `json:"Enable"` // TODO k8s 开
	NodeComponent             []string          `json:"NodeComponent"`
	TencentVcuda              int64             `json:"TencentVcuda"`
	NvidiaGpu                 int64             `json:"NvidiaGpu"`
	A100Labels                map[string]string `json:"A100Labels"`
	RTX3090Labels             map[string]string `json:"RTX3090Labels"`
	LegalTaints               map[string]string `json:"LegalTaints"`
	NoUseGpuNodeType          string            `json:"NoUseGpuNodeType"`
}

type ExternalUrlCfg struct {
	GpuMonitorBase                    string             `json:"GpuMonitorBase"`
	GpuMonitorRangeBase               string             `json:"GpuMonitorRangeBase"`
	GpuMonitorUrl                     string             `json:"GpuMonitorUrl"`
	GpuAvgUsageUrl                    string             `json:"GpuAvgUsageUrl"`
	GpuPodUsageUrl                    string             `json:"GpuPodUsageUrl"`
	GpuNotUseUrl                      string             `json:"GpuNotUseUrl"`                      // gpu剩余卡数，按照卡类型聚合
	GpuLeftUrl                        string             `json:"GpuLeftUrl"`                        // gpu剩余卡数，按照节点+卡类型聚合
	Gpu8FreeNodeUrl                   string             `json:"Gpu8FreeNodeUrl"`                   // gpu8卡空闲节点数
	Gpu4FreeNodeUrl                   string             `json:"Gpu4FreeNodeUrl"`                   // gpu4卡空闲节点数 （包括 > 4）
	GpuNodeCountUrl                   string             `json:"GpuNodeCountUrl"`                   // gpu节点数
	GpuPodCardAvgUsageUrl             string             `json:"GpuPodCardAvgUsageUrl"`             //pod Gpu 平均使用率
	CpuPodCardUsageUrl                string             `json:"CpuPodCardUsageUrl"`                //pod Cpu 平均使用率
	MemoryPodUsageUrl                 string             `json:"MemoryPodUsageUrl"`                 //pod 内存使用率
	GpuPodCardUsageUrlRange           int                `json:"GpuPodCardUsageUrlRange"`           // Pod Gpu使用率查询时间范围
	CpuPodCardUsageUrlRange           int                `json:"CpuPodCardUsageUrlRange"`           // Pod Cpu使用率查询时间范围
	GpuPodCardUsageUrlThreshold       int                `json:"GpuPodCardUsageUrlThreshold"`       // Pod Gpu使用率阈值
	GpuMemoryPodCardUsageUrlThreshold int                `json:"GpuMemoryPodCardUsageUrlThreshold"` // Pod Gpu显存使用率阈值
	CpuPodCardUsageUrlThreshold       int                `json:"CpuPodCardUsageUrlThreshold"`       // Pod Cpu使用率阈值
	GpuClusterAvgUsageUrl             string             `json:"GpuClusterAvgUsageUrl"`             // GPU集群使用率
	GpuClusterMemoryUsageUrl          string             `json:"GpuClusterMemoryUsageUrl"`          // GPU集群显存使用率
	GpuPodUsedCount                   string             `json:"GpuPodUsedCount"`                   // GPU pod 占用卡数
	GpuPodMemoryUsage                 string             `json:"GpuPodMemoryUsage"`                 // GPU pod显存使用率
	NodeMemoryUsage                   string             `json:"NodeMemoryUsage"`                   // node 内存使用率
	NodeCpuUsage                      string             `json:"NodeCpuUsage"`                      // node cpu使用率
	NodeGpuUsage                      string             `json:"NodeGpuUsage"`                      // node gpu使用率
	NodeGpuUsageByNode                string             `json:"NodeGpuUsageByNode"`                // 指定node gpu使用率
	NodeCpuUsageByNode                string             `json:"NodeCpuUsageByNode"`                // 指定node gpu使用率
	NodeMemoryUsageByNode             string             `json:"NodeMemoryUsageByNode"`             // 指定node gpu使用率
	ResourceNodeCount                 map[string]float64 `json:"ResourceNodeCount"`                 //资源节点机器数
}

type WorkflowCfg struct {
	SchedulerNodeCount int `json:"SchedulerNodeCount"` //调度节点数
}
type CacheCfg struct {
	IntervalSyncTaskInfo          int     `json:"IntervalSyncTaskInfo"`
	IntervalSyncTaskStatus        int     `json:"IntervalSyncTaskStatus"`
	WaitingDurationSyncTaskStatus float64 `json:"WaitingDurationSyncTaskStatus"`
	IntervalSyncGpuUnusedInfo     int     `json:"IntervalSyncGpuUnusedInfo"`
	IntervalSyncResourceGpuUsage  int     `json:"IntervalSyncResourceGpuUsage"`
	IntervalSyncMonitorData       int     `json:"IntervalSyncMonitorData"`
	IntervalSyncNodesErrorInfo    int     `json:"IntervalSyncNodesErrorInfo"`
	IntervalSyncMonitorDataTime   string  `json:"IntervalSyncMonitorDataTime"`
	SyncMonitorTaskStatus         []int   `json:"SyncMonitorTaskStatus"`
}

type PrometheusCfg struct {
	Address string `json:"Address"`
	Timeout int    `json:"Timeout"`
}
type GPUCalPower struct {
	RTX3090 float64 `json:"RTX3090"`
	A100    float64 `json:"A100"`
}

func GetCfg() error {
	//	 获取配置文件
	if err := g.Cfg().Struct(&Cfg); err != nil {
		return err
	}
	return nil
}
