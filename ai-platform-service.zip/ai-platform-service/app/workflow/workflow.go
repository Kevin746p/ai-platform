package workflow

import (
	"ai-platform-service/app/api/common"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/k8s/resource_types"
	"ai-platform-service/config"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"

	"sigs.k8s.io/yaml"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/util/gconv"
	v1 "k8s.io/api/batch/v1"
	pods "k8s.io/api/core/v1"
)

type WfService interface {
	Init()
	Start() error
	Stop() error

	ParseParam(map[string]string)
	SubmitWorkflow(map[string]string, string) (string, error)
}

type Workflow struct {
	cfg    *config.WorkflowCfg
	ctx    context.Context
	cancel context.CancelFunc
}

var Wf *Workflow

func (m *Workflow) Init() {
	m.ctx, m.cancel = context.WithCancel(context.Background())
	m.cfg = &config.Cfg.Workflow
	Wf = m
}

func (m *Workflow) Start() error {
	return nil
}

func (m *Workflow) Stop() error {
	return nil
}

func (m *Workflow) Name() string { return "Workflow" }

func (m *Workflow) checkWorkflowParams(param map[string]string) error {
	if _, ok := param["gpu_limits"]; !ok {
		if _, ok = param["gpu_limit"]; !ok {
			return errors.New("invalid param gpu_limits")
		}
		param["gpu_limits"] = param["gpu_limit"]
	}
	if _, ok := param["gpu_mode"]; !ok {
		return errors.New("invalid param gpu_mode")
	}
	if _, ok := param["namespace"]; !ok {
		return errors.New("invalid param namespace")
	}
	if _, ok := param["project"]; !ok {
		return errors.New("invalid param project")
	}
	if _, ok := param["id"]; !ok {
		return errors.New("invalid param id")
	}
	return nil
}

// Yaml检查，替换，提交k8s
func (m *Workflow) SubmitWorkflow(param map[string]string, isReTry bool, yamlUrl, jobType, uuid string) (workflowName, workflowID string, err error) {

	if err = m.checkWorkflowParams(param); err != nil {
		return
	}
	_yaml, err := m.GetDeployYamlFromGit(yamlUrl)
	if err != nil {
		g.Log().Error("[workflow][SubmitWorkflow] GetDeployYamlFromGit failed", uuid, err.Error())
		return
	}
	job, err := m.ParseDeployYamlToResource(_yaml, param, jobType)
	if err != nil {
		g.Log().Error("[workflow][SubmitWorkflow] ParseDeployYamlToResource failed", uuid, err.Error())
		return
	}
	// TODO 是否所有任务都可以指定任务名称
	if isReTry {
		metaName := param["project"] + "-" + param["id"]
		m.ReplaceResourceParams(job, metaName, common.TranslateNodeSelector(param["gpu_mode"], gconv.Int(param["gpu_limit"])))
	}
	// 创建任务
	err = k8s.K8s.CreateResource(param["namespace"], job)
	workflowID = param["id"]
	return workflowName, workflowID, err
}
func (m *Workflow) ReplaceResourceParams(resource interface{}, metaName string, gpuMode string) {
	switch resource.(type) {
	case *v1.Job:
		resource.(*v1.Job).ObjectMeta.Name = metaName
		resource.(*v1.Job).Spec.Template.Spec.NodeSelector = map[string]string{"resource.type": gpuMode}
	case *resource_types.Notebook:
		resource.(*resource_types.Notebook).ObjectMeta.Name = metaName
		resource.(*resource_types.Notebook).ObjectMeta.Labels = map[string]string{"app": metaName}
		resource.(*resource_types.Notebook).Spec.Template.Spec.Containers[0].Name = metaName
		resource.(*resource_types.Notebook).Spec.Template.Spec.NodeSelector = map[string]string{"resource.type": gpuMode}
	}
}
func (m *Workflow) SubmitWorkflowByResource(resource interface{}, namespace, uuid string) error {
	//TODO 增加uuid日志打印
	return k8s.K8s.CreateResource(namespace, resource)
}

func (m *Workflow) isMultiGpuTask(gpuLimit int64) bool {
	return gpuLimit > enum.GpuNodeCount && gpuLimit%enum.GpuNodeCount == 0
}

// 获取yaml
func (m *Workflow) GetDeployYamlFromGit(url string) (yaml []byte, err error) {
	resp, err := g.Client().Get(url)
	if err != nil || resp.StatusCode != http.StatusOK {
		return
	}
	yaml = resp.ReadAll()
	return
}

// yaml基础校验 - 需要包含资源限制
func (m *Workflow) CheckAndReplaceBaseYaml(deployYaml string, param map[string]string) (err error, _yaml []byte) {
	if deployYaml == "" {
		err = fmt.Errorf("deployYaml is empty")
		return
	} else if !strings.Contains(deployYaml, "resources") || !strings.Contains(deployYaml, "requests") || !strings.Contains(deployYaml, "limits") {
		err = fmt.Errorf("deployYaml resources limit is needed")
		return
	}
	// TODO一个Job包含多个container，GPU使用率不对
	// 参数个数校验
	if strings.Count(deployYaml, "{") != strings.Count(deployYaml, "}") {
		err = fmt.Errorf("deployYaml invalid param configuration")
		return
	}
	for k, v := range param {
		deployYaml = strings.ReplaceAll(deployYaml, fmt.Sprintf("{%s}", k), v)
	}
	_yaml, err = yaml.YAMLToJSON([]byte(deployYaml))
	return
}

// 解析yaml到资源
func (m *Workflow) ParseDeployYamlToResource(_yaml []byte, param map[string]string, resourceType string) (resource interface{}, err error) {
	err, _yaml = m.CheckAndReplaceBaseYaml(string(_yaml), param)
	if err != nil {
		return
	}
	switch resourceType {
	case config.Cfg.K8s.JobKind:
		resource = new(v1.Job)
	case config.Cfg.K8s.PytorchJobKind:
		resource = new(resource_types.PyTorchJob)
	case config.Cfg.K8s.NoteBookKind:
		resource = new(resource_types.Notebook)
	case config.Cfg.K8s.PvcKind:
		resource = new(pods.PersistentVolumeClaim)
	default:
		return nil, fmt.Errorf("invalid resource type %s", resourceType)
	}
	err = json.Unmarshal(_yaml, &resource)
	return
}
