package k8s

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s/resource_types"
	"ai-platform-service/config"
	"context"
	"encoding/json"
	"fmt"
	"reflect"
	"sort"
	"strings"
	"time"

	"github.com/gogf/gf/util/gconv"
	_resource "k8s.io/apimachinery/pkg/api/resource"

	"github.com/gogf/gf/frame/g"
	"go.uber.org/zap"
	v1 "k8s.io/api/batch/v1"
	pods "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"sigs.k8s.io/yaml"
)

var K8s *K8sClient

type K8sClient struct {
	cfg           *config.K8sCfg
	ctx           context.Context
	cancel        context.CancelFunc
	Client        *kubernetes.Clientset
	dynamicClient dynamic.Interface
}

func (k *K8sClient) Init() {
	k.cfg = &config.Cfg.K8s
	k.ctx, k.cancel = context.WithCancel(context.Background())
	K8s = k
}

func (k *K8sClient) Start() (err error) {
	k8sCfg := &rest.Config{
		Host:            k.cfg.Host,
		BearerToken:     k.cfg.Token,
		BearerTokenFile: "",
		TLSClientConfig: rest.TLSClientConfig{
			Insecure: true, // 设置为true时 不需要CA
		},
	}
	k.Client, err = kubernetes.NewForConfig(k8sCfg)
	if err != nil {
		g.Log().Error("[k8s][start] k8s client connected failed: ", err.Error())
		return err
	}
	k.dynamicClient, err = dynamic.NewForConfig(k8sCfg)
	if err != nil {
		g.Log().Error("[k8s][start] k8s dynamicClient connected failed: ", err.Error())
		return err
	}
	g.Log().Info("[k8s][start] k8s connected")
	return
}

func (k *K8sClient) Stop() (err error) {
	k.cancel()
	return
}
func (k *K8sClient) Name() string {
	return "K8s"
}

func (k *K8sClient) GetJobStatusByName(namespace, jobName string) (status int, desc string) {
	job, err := k.Client.BatchV1().Jobs(namespace).Get(context.Background(), jobName, metav1.GetOptions{})
	if err != nil {
		g.Log().Error("[k8s][GetJobStatusByName] Get Jod Err:", namespace, jobName, err)
		status = enum.TaskPodPending // "error"
		desc = enum.ErrDescJobNotExists
		return
	}
	// Todo
	if job == nil {
		g.Log().Error("[k8s][GetJobStatusByName] Get Jod Err:", namespace, jobName, "job is nil")
		status = enum.TaskPodPending // "error"
		desc = enum.ErrDescNilJob
		return
	}
	g.Log().Info("[k8s][GetJobStatusByName] get job success:", namespace, jobName, job.Status.Active, job.Status.Succeeded, job.Status.Failed, job.Status.Conditions, job.Spec.BackoffLimit)
	g.Log().Info(fmt.Sprintf("[k8s][GetJobStatusByName] get job status: %s , %v", jobName, job.Status.Conditions))
	if job.Status.Succeeded == 1 {
		status = enum.TaskComplete // "complete"
		return
	}
	if job.Status.Failed > 0 && job.Status.Failed == *job.Spec.BackoffLimit+1 {
		status = enum.TaskFailed // "failed"
		desc = enum.ErrDescJobExecFailed
		if len(job.Status.Conditions) > 0 {
			desc = job.Status.Conditions[0].Message
		}
		return
	}
	if job.Status.Active > 0 {
		status = enum.TaskRunning // "running"
		podStatus, err, podCount, podName := k.GetLatestJobPodStatus(namespace, jobName, job)
		if err != nil {
			status = enum.TaskRunErr
			desc = enum.ErrDescGetPodStatusFailed
			g.Log().Error("[k8s][GetJobStatusByName] get pod status failed", namespace, jobName)
			return
		}

		switch podStatus {
		case string(pods.PodPending):
			status = enum.TaskPodPending
		case string(pods.PodSucceeded): // TODO 当一个job创建多个pod时该判断无效
			status = enum.TaskComplete
		case string(pods.PodFailed):
			// 任务重试中
			if podCount < *job.Spec.BackoffLimit+1 {
				return
			}
			status = enum.TaskFailed
			desc = k.GetLatestEventMessage(namespace, podName, string(pods.PodFailed))
		case "":
			// 任务重试中
			if podCount < *job.Spec.BackoffLimit+1 {
				return
			}
			status = enum.TaskRunErr
			desc = enum.ErrDescUnknownPodStatus
		}
	}
	return
}

func (k *K8sClient) GetLatestJobPodStatus(namespace, jobName string, job *v1.Job) (string, error, int32, string) {
	set := labels.Set(job.Spec.Selector.MatchLabels)
	listOptions := metav1.ListOptions{LabelSelector: set.AsSelector().String()}
	podList, err := k.Client.CoreV1().Pods(namespace).List(context.Background(), listOptions)
	if err != nil {
		g.Log().Error("[k8s][GetJobPodStatus] Get k8s podList Err:", namespace, jobName, err)
		return "", err, 0, ""
	}
	if podList != nil && len(podList.Items) > 0 {
		// TODO 按照pod创建时间倒序排序，若1S内重试多次返回的不一定最新的Pod,考虑换成pod index
		sort.Sort(sort.Reverse(PodList(podList.Items)))
		g.Log().Info("[k8s][GetJobPodStatus] get pod status success", namespace, jobName, podList.Items[0].Name, string(podList.Items[0].Status.Phase))
		return string(podList.Items[0].Status.Phase), nil, int32(len(podList.Items)), podList.Items[0].Name
	}
	return "", nil, 0, ""
}
func (k *K8sClient) GetLatestEventMessage(namespace, objectName string, status string) (message string) {
	event, err := k.Client.CoreV1().Events(namespace).List(k.ctx,
		metav1.ListOptions{FieldSelector: fmt.Sprintf("involvedObject.name=%s,reason=%s", objectName, status)})
	if err != nil {
		g.Log().Error("[k8s][GetLatestEventMessage] get k8s event err:", namespace, objectName, err)
		return enum.ErrDescGetEventErr
	}

	if len(event.Items) > 0 {
		sort.Sort(sort.Reverse(EventList(event.Items)))
		message = event.Items[0].Message
		g.Log().Info("[k8s][GetLatestEventMessage] get object message", namespace, objectName, message)
		return
	}
	return enum.ErrDescObjectHasNoEvent
}

type EventList []pods.Event

func (e EventList) Len() int { return len(e) }

func (e EventList) Swap(i, j int) { e[i], e[j] = e[j], e[i] }

func (e EventList) Less(i, j int) bool {
	return e[i].CreationTimestamp.Unix() < e[j].CreationTimestamp.Unix()
}

type PodList []pods.Pod

func (p PodList) Len() int { return len(p) }

func (p PodList) Swap(i, j int) { p[i], p[j] = p[j], p[i] }

func (p PodList) Less(i, j int) bool {
	return p[i].CreationTimestamp.Unix() < p[j].CreationTimestamp.Unix()
}

func (k *K8sClient) GetPytorchJobStatus(namespace, jobName string) (status int, desc string) {
	defer func() {
		g.Log().Info("GetPytorchJobStatus",
			zap.String("namespace", namespace),
			zap.String("jobName", jobName),
			zap.Int("job status", status),
			zap.String("desc", desc))
	}()
	set := labels.Set(map[string]string{
		"job-name": jobName,
	})
	listOptions := metav1.ListOptions{LabelSelector: set.AsSelector().String()}
	podList, err := k.Client.CoreV1().Pods(namespace).List(context.Background(), listOptions)
	if err != nil {
		g.Log().Error("[k8s][GetPytorchJobStatus] get k8s podList err:", zap.String("namespace", namespace), zap.String("jobName", jobName), err)
		status = enum.TaskPodPending
		desc = err.Error()
		return
	}
	var pending, running, success int
	if podList == nil {
		status = enum.TaskPodPending
		desc = enum.ErrDescNilPodList
		return
	} else if len(podList.Items) == 0 {
		status = enum.TaskPodPending
		desc = enum.ErrDescZeroPodListItem
		return
	} else {
		g.Log().Info("[k8s][GetPytorchJobStatus] get k8s podList success",
			zap.String("namespace", namespace),
			zap.String("jobName", jobName),
			zap.Int("podList count", len(podList.Items)))

		for _, pod := range podList.Items {
			g.Log().Info("[k8s][GetPytorchJobStatus] get k8s pod name/status:", pod.Name, pod.Status.Phase, zap.String("namespace", pod.Namespace))
			switch pod.Status.Phase {
			case pods.PodFailed:
				status = enum.TaskFailed
				desc = k.GetLatestEventMessage(namespace, jobName, string(pods.PodFailed))
				return
			case pods.PodPending:
				pending++
			case pods.PodRunning:
				running++
			case pods.PodSucceeded:
				success++
			}
		}
	}
	if pending >= 1 {
		status = enum.TaskPodPending
		return
	}
	if running >= 1 {
		status = enum.TaskRunning
		return
	}
	status = enum.TaskComplete

	return
}

func (k *K8sClient) GetPodsByLabel(namespace string, label []string) (*pods.PodList, error) {
	return k.Client.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{
		LabelSelector: fmt.Sprintf("app in (%s)", strings.Join(label, ",")),
	})
}

func (k *K8sClient) GetDeployYamlFromGit(url string) (yaml []byte, err error) {
	err = g.Client().GetVar(url).Scan(&yaml)
	return
}

func (k *K8sClient) ParseDeployYamlToJob(_yaml []byte, param map[string]string, isMulti bool) (job interface{}, err error) {
	// 强限制Yaml中必须声明资源限制
	yamlString := string(_yaml)
	if yamlString == "" {
		return job, fmt.Errorf("invalid deploy yaml")
	} else if !strings.Contains(yamlString, "resources") && !strings.Contains(yamlString, "requests") {
		return job, fmt.Errorf("resource limit is needed")
	}
	for k, v := range param {
		yamlString = strings.ReplaceAll(yamlString, fmt.Sprintf("{%s}", k), v)
	}
	_yaml, err = yaml.YAMLToJSON([]byte(yamlString))
	if err != nil {
		return job, err
	}
	if !isMulti {
		job := new(v1.Job)
		err = json.Unmarshal(_yaml, &job)
		if param["resume"] != "" {
			job.Spec.Template.Spec.Containers[0].Env = append(job.Spec.Template.Spec.Containers[0].Env, pods.EnvVar{Name: "RESUME", Value: param["resume"]})
		}
		return job, err
	} else {
		job := new(resource_types.PyTorchJob)
		err = json.Unmarshal(_yaml, &job)
		if param["resume"] != "" {
			job.Spec.PyTorchReplicaSpecs["Master"].Template.Spec.Containers[0].Env = append(job.Spec.PyTorchReplicaSpecs["Master"].Template.Spec.Containers[0].Env, pods.EnvVar{Name: "RESUME", Value: param["resume"]})
			job.Spec.PyTorchReplicaSpecs["Worker"].Template.Spec.Containers[0].Env = append(job.Spec.PyTorchReplicaSpecs["Worker"].Template.Spec.Containers[0].Env, pods.EnvVar{Name: "RESUME", Value: param["resume"]})
		}
		return job, err
	}
}

func (k *K8sClient) CreateResource(namespace string, job interface{}) (err error) {
	switch job.(type) {
	case *v1.Job:
		_, err = k.Client.BatchV1().Jobs(namespace).Create(k.ctx, job.(*v1.Job), metav1.CreateOptions{})
	case *resource_types.PyTorchJob:
		pytorchJob := job.(*resource_types.PyTorchJob)
		deploymentRes := schema.GroupVersionResource{Group: config.Cfg.K8s.PytorchJobGroup, Version: config.Cfg.K8s.PytorchJobVersion, Resource: config.Cfg.K8s.PytorchJobResource}
		deployment := &unstructured.Unstructured{Object: map[string]interface{}{
			"apiVersion": config.Cfg.K8s.PytorchJobGroup + "/" + config.Cfg.K8s.PytorchJobVersion,
			"kind":       config.Cfg.K8s.PytorchJobKind,
			"metadata":   pytorchJob.ObjectMeta,
			"spec":       pytorchJob.Spec,
		}}
		_, err = k.dynamicClient.Resource(deploymentRes).Namespace(namespace).Create(k.ctx, deployment, metav1.CreateOptions{})
	case *resource_types.Notebook:
		noteBook := job.(*resource_types.Notebook)
		deploymentRes := schema.GroupVersionResource{Group: config.Cfg.K8s.NotebookGroup, Version: config.Cfg.K8s.NotebookVersion, Resource: config.Cfg.K8s.NoteBookResource}
		deployment := &unstructured.Unstructured{Object: map[string]interface{}{
			"apiVersion": config.Cfg.K8s.NotebookGroup + "/" + config.Cfg.K8s.NotebookVersion,
			"kind":       config.Cfg.K8s.NoteBookKind,
			"metadata":   noteBook.ObjectMeta,
			"spec":       noteBook.Spec,
		}}
		_, err = k.dynamicClient.Resource(deploymentRes).Namespace(namespace).Create(k.ctx, deployment, metav1.CreateOptions{})
	case *pods.PersistentVolumeClaim:
		pvc := job.(*pods.PersistentVolumeClaim)
		_, err = k.Client.CoreV1().PersistentVolumeClaims(namespace).Create(k.ctx, pvc, metav1.CreateOptions{})
	default:
		err = fmt.Errorf("invalid job type :%s ", reflect.TypeOf(job).String())
	}
	return
}

// 获取资源状态
func (k *K8sClient) GetResourceStatus(namespace, resourceType, resourceName string) (status int, desc string) {
	resourceGroupVersion, err := k.TranslateResourceType(resourceType)
	if err != nil {
		status = enum.TaskRunErr
		desc = err.Error()
		return
	}
	resource, err := k.GetResourceObject(namespace, resourceName, resourceGroupVersion)
	if err != nil {
		status = enum.TaskPodPending
		desc = err.Error()
		return
	}
	return k.TranslateResourceStatus(resource)
}

// 获取资源对象
func (k *K8sClient) GetResourceObject(namespace, resourceName string, resourceGroupVersion schema.GroupVersionResource) (*unstructured.Unstructured, error) {
	return k.dynamicClient.Resource(resourceGroupVersion).Namespace(namespace).Get(k.ctx, resourceName, metav1.GetOptions{})
}

// 获取资源对象
func (k *K8sClient) TranslateResourceStatus(resource *unstructured.Unstructured) (status int, desc string) {
	resourceJson, err := resource.MarshalJSON()
	if err != nil {
		g.Log().Error("[k8s][start] TranslateResourceStatus failed", resource.GetName())
		return
	}
	switch resource.GetKind() {
	case config.Cfg.K8s.JobKind:
		job := new(v1.Job)
		err = json.Unmarshal(resourceJson, job)
		return k.TranslateJobStatus(job)
	case config.Cfg.K8s.PytorchJobKind:
		pytorchJob := new(resource_types.PyTorchJob)
		_ = json.Unmarshal(resourceJson, pytorchJob)
		return k.TranslatePytorchJobStatus(pytorchJob)
	case config.Cfg.K8s.NoteBookKind:
		notebook := new(resource_types.Notebook)
		err = json.Unmarshal(resourceJson, notebook)
		return k.TranslateNoteBookStatus(notebook)
	case config.Cfg.K8s.PvcKind:
		pvc := new(pods.PersistentVolumeClaim)
		err = json.Unmarshal(resourceJson, pvc)
		return k.TranslatePvcStatus(pvc)
	}
	return
}

func (k *K8sClient) TranslateJobStatus(job *v1.Job) (status int, desc string) {
	if job.Status.Succeeded == 1 {
		status = enum.TaskComplete // "complete"
		return
	}
	if job.Status.Failed > 0 && job.Status.Failed == *job.Spec.BackoffLimit+1 {
		status = enum.TaskFailed // "failed"
		desc = enum.ErrDescJobExecFailed
		if len(job.Status.Conditions) > 0 {
			desc = job.Status.Conditions[0].Message
		}
		return
	}
	if job.Status.Active > 0 {
		status = enum.TaskRunning // "running"
		podStatus, err, podCount, podName := k.GetLatestJobPodStatus(job.Namespace, job.Name, job)
		if err != nil {
			status = enum.TaskRunErr
			desc = enum.ErrDescGetPodStatusFailed
			g.Log().Error("[k8s][GetJobStatusByName] get pod status failed", job.Namespace, job.Name)
			return
		}

		switch podStatus {
		case string(pods.PodPending):
			status = enum.TaskPodPending
		case string(pods.PodSucceeded): // TODO 当一个job创建多个pod时该判断无效
			status = enum.TaskComplete
		case string(pods.PodFailed):
			// 任务重试中
			if podCount < *job.Spec.BackoffLimit+1 {
				return
			}
			status = enum.TaskFailed
			desc = k.GetLatestEventMessage(job.Namespace, podName, string(pods.PodFailed))
		case "":
			// 任务重试中
			if podCount < *job.Spec.BackoffLimit+1 {
				return
			}
			status = enum.TaskRunErr
			desc = enum.ErrDescUnknownPodStatus
		}
	}
	return
}
func (k *K8sClient) TranslateNoteBookStatus(notebook *resource_types.Notebook) (status int, desc string) {
	sort.Sort(sort.Reverse(resource_types.NotebookConditions(notebook.Status.Conditions)))
	if len(notebook.Status.Conditions) > 0 {
		if notebook.Status.ReadyReplicas == 0 {
			// 由于资源等待过程中 ReadyReplicas为0，进一步获取pod状态
			status = enum.TaskComplete
			podList, err := k.GetPodsByLabel(notebook.Namespace, []string{notebook.Name})
			if err != nil {
				g.Log().Error("[k8s][TranslateNoteBookStatus] GetPodsByLabel failed", notebook.Name, err.Error())
			}
			if podList != nil && len(podList.Items) > 0 {
				status, desc = k.TranslatePodStatus(&podList.Items[0])
			}
			return
		}
		switch notebook.Status.Conditions[0].Type {
		case resource_types.NotebookCreated:
			status = enum.TaskWaiting
		case resource_types.NotebookRunning:
			status = enum.TaskRunning
		case resource_types.NotebookWaiting:
			status = enum.TaskWaiting
		case resource_types.NotebookTerminated:
			status = enum.TaskComplete
		}
	}
	return
}

func (k *K8sClient) TranslatePodStatus(pod *pods.Pod) (status int, desc string) {
	switch pod.Status.Phase {
	case pods.PodPending:
		status = enum.TaskPodPending
	case pods.PodSucceeded:
		status = enum.TaskComplete
	case pods.PodFailed:
		status = enum.TaskFailed
		desc = pod.Status.Message
	case "":
		status = enum.TaskRunErr
		desc = enum.ErrDescUnknownPodStatus
	}
	return
}

// TODO 预留
func (k *K8sClient) TranslatePvcStatus(pvc *pods.PersistentVolumeClaim) (status int, desc string) {
	return
}

// 更新副本集数量 -TODO 由于控制器问题导致实际并非修改副本数，后续要替换
func (k *K8sClient) UpdateStatefulSetReplicas(namespace, resourceName string, replicas *int32) error {
	data := fmt.Sprintf(`{"metadata":{"annotations":{"kubeflow-resource-stopped":"%s"}}}`, time.Now().UTC().Format("2006-01-02T15:04:05Z"))
	if *replicas == 1 {
		data = fmt.Sprintf(`{"metadata":{"annotations":{"kubeflow-resource-stopped":null}}}`)
	}
	resource := schema.GroupVersionResource{
		Group:    config.Cfg.K8s.NotebookGroup,
		Version:  config.Cfg.K8s.NotebookVersion,
		Resource: config.Cfg.K8s.NoteBookResource,
	}
	_, err := k.dynamicClient.Resource(resource).Namespace(namespace).Patch(k.ctx, resourceName, "application/merge-patch+json", []byte(data), metav1.PatchOptions{})
	return err
}

//
func (k *K8sClient) UpdateNotebookResource(namespace string, notebook *unstructured.Unstructured) error {
	resource := schema.GroupVersionResource{
		Group:    config.Cfg.K8s.NotebookGroup,
		Version:  config.Cfg.K8s.NotebookVersion,
		Resource: config.Cfg.K8s.NoteBookResource,
	}
	deployment := &unstructured.Unstructured{Object: map[string]interface{}{
		"apiVersion": config.Cfg.K8s.NotebookGroup + "/" + config.Cfg.K8s.NotebookVersion,
		"kind":       config.Cfg.K8s.NoteBookKind,
		"metadata":   notebook.Object["metadata"],
		"spec":       notebook.Object["spec"],
	}}
	_, err := k.dynamicClient.Resource(resource).Namespace(namespace).Update(k.ctx, deployment, metav1.UpdateOptions{})
	return err
}

func (k *K8sClient) UpdateNotebookResourceGpu(namespace, notebookName, resourceType, gpuMode string, gpuLimit, cpuLimit, memLimit *int32) error {

	resource, err := k.TranslateResourceType(resourceType)
	if err != nil {
		return err
	}
	resourceObject, err := k.GetResourceObject(namespace, notebookName, resource)
	if err != nil {
		return err
	}
	// 更新资源信息
	notebook := new(resource_types.Notebook)
	errJson, err := json.Marshal(resourceObject.Object)
	if err != nil {
		return err
	}
	err = json.Unmarshal(errJson, notebook)
	if err != nil {
		return err
	}
	annotations := resourceObject.GetAnnotations()
	resourceObject.SetAnnotations(annotations)
	resourceLimit := make(pods.ResourceList)
	if gpuLimit != nil {
		resourceLimit[enum.ResourceTypeA100RequestKey] = _resource.MustParse(gconv.String(*gpuLimit))
	}
	if cpuLimit != nil {
		resourceLimit[pods.ResourceCPU] = _resource.MustParse(gconv.String(*cpuLimit))

	}
	if memLimit != nil {
		resourceLimit[pods.ResourceMemory] = _resource.MustParse(gconv.String(*memLimit) + "Gi")

	}
	if len(notebook.Spec.Template.Spec.Containers) > 0 {
		notebook.Spec.Template.Spec.Containers[0].Resources.Limits = resourceLimit
		notebook.Spec.Template.Spec.Containers[0].Resources.Requests = resourceLimit
	}
	notebook.Spec.Template.Spec.NodeSelector = map[string]string{"resource.type": gpuMode}
	resourceObject.Object["spec"] = notebook.Spec

	// 重新部署
	return k.UpdateNotebookResource(namespace, resourceObject)
}

func (k *K8sClient) TranslatePytorchJobStatus(pytorchJob *resource_types.PyTorchJob) (status int, desc string) {
	sort.Sort(sort.Reverse(resource_types.JobConditions(pytorchJob.Status.Conditions)))
	if len(pytorchJob.Status.Conditions) > 0 {
		switch pytorchJob.Status.Conditions[0].Type {
		case resource_types.JobSucceeded:
			status = enum.TaskComplete
		case resource_types.JobCreated:
			status = enum.TaskPodPending
		case resource_types.JobFailed:
			status = enum.TaskFailed
			desc = pytorchJob.Status.Conditions[0].Message
		case resource_types.JobRunning:
			status = enum.TaskRunning
		case resource_types.JobRestarting:
			status = enum.TaskRunning
		}
	}
	return
}

// 根据k8s中api-resources定义
func (k *K8sClient) TranslateResourceType(resourceType string) (resource schema.GroupVersionResource, err error) {
	switch resourceType {
	case config.Cfg.K8s.JobKind:
		resource = schema.GroupVersionResource{
			Group:    config.Cfg.K8s.JobGroup,
			Version:  config.Cfg.K8s.JobVersion,
			Resource: config.Cfg.K8s.JobResource,
		}
	case config.Cfg.K8s.PytorchJobKind:
		resource = schema.GroupVersionResource{
			Group:    config.Cfg.K8s.PytorchJobGroup,
			Version:  config.Cfg.K8s.PytorchJobVersion,
			Resource: config.Cfg.K8s.PytorchJobResource,
		}
	case config.Cfg.K8s.NoteBookKind:
		resource = schema.GroupVersionResource{
			Group:    config.Cfg.K8s.NotebookGroup,
			Version:  config.Cfg.K8s.NotebookVersion,
			Resource: config.Cfg.K8s.NoteBookResource,
		}
	case config.Cfg.K8s.PvcKind:
		resource = schema.GroupVersionResource{
			Group:    config.Cfg.K8s.PvcGroup,
			Version:  config.Cfg.K8s.PvcVersion,
			Resource: config.Cfg.K8s.PvcResource,
		}
	default:
		return schema.GroupVersionResource{}, fmt.Errorf("invalid resource type")
	}
	return
}

// 删除资源对象
func (k *K8sClient) DeleteResourceObject(namespace, resourceName string, resourceType string) error {
	resourceSchema, err := k.TranslateResourceType(resourceType)
	if err != nil {
		return err
	}
	propagationPolicy := metav1.DeletePropagationBackground
	err = k.dynamicClient.Resource(resourceSchema).Namespace(namespace).Delete(k.ctx, resourceName, metav1.DeleteOptions{PropagationPolicy: &propagationPolicy})
	if err != nil && !strings.Contains(err.Error(), "not found") {
		return err
	}
	return nil
}

//获取所有节点
func (k *K8sClient) GetAllNode() (*pods.NodeList, error) {
	return k.Client.CoreV1().Nodes().List(context.Background(), metav1.ListOptions{})
}

// GetNodeDescribe 获取节点详情
func (k *K8sClient) GetNodeDescribe(nodeName string) (*pods.Node, error) {

	return k.Client.CoreV1().Nodes().Get(k.ctx, nodeName, metav1.GetOptions{})
}

//
func (k *K8sClient) GetAllPodByNode(nodeName string) (*pods.PodList, error) {
	return k.Client.CoreV1().Pods("").List(k.ctx, metav1.ListOptions{
		FieldSelector: fmt.Sprintf("spec.nodeName=%s", nodeName),
	})
}
