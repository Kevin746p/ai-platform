package resource_types

import (
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

type PyTorchJob struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   PyTorchJobSpec `json:"spec,omitempty"`
	Status JobStatus      `json:"status,omitempty"`
}

// PyTorchJobSpec defines the desired state of PyTorchJob
type PyTorchJobSpec struct {
	// RunPolicy encapsulates various runtime policies of the distributed training
	// job, for example how to clean up resources and how long the job can stay
	// active.
	RunPolicy `json:"runPolicy"`

	// A map of PyTorchReplicaType (type) to ReplicaSpec (value). Specifies the PyTorch cluster configuration.
	// For example,
	//   {
	//     "Master": PyTorchReplicaSpec,
	//     "Worker": PyTorchReplicaSpec,
	//   }
	PyTorchReplicaSpecs map[ReplicaType]*ReplicaSpec `json:"pytorchReplicaSpecs"`

	// ModelVersion represents the model output by this job run.
	// +optional
	ModelVersion *ModelVersionSpec `json:"modelVersion,omitempty"`

	// CacheBackend is used to configure the cache engine for job
	// +optional
	CacheBackend *CacheBackendSpec `json:"cacheBackend"`
}

type JobStatus struct {
	// Conditions is an array of current observed job conditions.
	Conditions []JobCondition `json:"conditions,omitempty"`

	// ReplicaStatuses is map of ReplicaType and ReplicaStatus,
	// specifies the status of each replica.
	ReplicaStatuses map[ReplicaType]*ReplicaStatus `json:"replicaStatuses"`

	// Represents time when the job was acknowledged by the job controller.
	// It is not guaranteed to be set in happens-before order across separate operations.
	// It is represented in RFC3339 form and is in UTC.
	StartTime *metav1.Time `json:"startTime,omitempty"`

	// Represents time when the job was completed. It is not guaranteed to
	// be set in happens-before order across separate operations.
	// It is represented in RFC3339 form and is in UTC.
	CompletionTime *metav1.Time `json:"completionTime,omitempty"`

	// Represents last time when the job was reconciled. It is not guaranteed to
	// be set in happens-before order across separate operations.
	// It is represented in RFC3339 form and is in UTC.
	LastReconcileTime *metav1.Time `json:"lastReconcileTime,omitempty"`

	// ModelVersionName represents the model version name output by this job run.
	ModelVersionName string `json:"modelVersionName,omitempty"`

	// CacheBackendName is the name for the backend cache
	CacheBackendName string `json:"cacheBackendName,omitempty"`
}

type RunPolicy struct {
	// CleanPodPolicy defines the policy to kill pods after the job completes.
	// Default to Running.
	CleanPodPolicy *CleanPodPolicy `json:"cleanPodPolicy,omitempty"`

	// TTLSecondsAfterFinished is the TTL to clean up jobs.
	// It may take extra ReconcilePeriod seconds for the cleanup, since
	// reconcile gets called periodically.
	// Default to infinite.
	TTLSecondsAfterFinished *int32 `json:"ttlSecondsAfterFinished,omitempty"`

	// Specifies the duration in seconds relative to the startTime that the job may be active
	// before the system tries to terminate it; value must be positive integer.
	// +optional
	ActiveDeadlineSeconds *int64 `json:"activeDeadlineSeconds,omitempty"`

	// Optional number of retries before marking this job failed.
	// +optional
	BackoffLimit *int32 `json:"backoffLimit,omitempty"`

	// SchedulingPolicy defines the policy related to scheduling, e.g. gang-scheduling
	// +optional
	SchedulingPolicy *SchedulingPolicy `json:"schedulingPolicy,omitempty"`

	// +optional
	CronPolicy *CronPolicy `json:"cronPolicy,omitempty"`
}

// ReplicaType represents the type of the replica. Each operator needs to define its
// own set of ReplicaTypes.
type ReplicaType string

// ReplicaStatus represents the current observed state of the replica.
type ReplicaStatus struct {
	// The number of actively running pods.
	Active int32 `json:"active,omitempty"`

	// The number of pods which reached phase Succeeded.
	Succeeded int32 `json:"succeeded,omitempty"`

	// The number of pods which reached phase Failed.
	Failed int32 `json:"failed,omitempty"`

	// The number of pods which reached phase Failed and reason is Evicted,
	// it is included in the number of Failed.
	Evicted int32 `json:"evicted,omitempty"`
}

type ReplicaSpec struct {
	// Replicas is the desired number of replicas of the given template.
	// If unspecified, defaults to 1.
	Replicas *int32 `json:"replicas,omitempty"`

	// Spot replicas are a subset of Replicas that allow for interruptions. They can use resources with less SLO guarantee.
	// Spot replicas are suitable for stateless or fault-tolerant jobs.
	// These replicas can be scheduled with higher chance at lower resource pricing.
	SpotReplicaSpec *SpotReplicaSpec `json:"spotReplicaSpec,omitempty"`

	// Template is the object that describes the pod that
	// will be created for this replica. RestartPolicy in PodTemplateSpec
	// will be overide by RestartPolicy in ReplicaSpec
	Template v1.PodTemplateSpec `json:"template,omitempty"`

	// Restart policy for all replicas within the job.
	// One of Always, OnFailure, Never and ExitCode.
	// Default to Never.
	RestartPolicy RestartPolicy `json:"restartPolicy,omitempty"`

	// DependOn represents a list of upstream vertex conditions to be dependent on for this RepicaType to start.
	// For example, in TensorFlow workers depend on ps to start first. If not set, KubeDL will populates the
	// default DependOn based on each framework's requirements. This feature is enabled by default, and can be
	// disabled with DAGScheduling feature gate.
	DependOn []DAGCondition `json:"-"`
}

// CacheBackendSpec defines the desired state of CacheBackend
type CacheBackendSpec struct {
	// The location in the container where the dataset should be mounted
	MountPath string `json:"mountPath,omitempty"`

	// Dataset describes the parameters related to the dataset file
	Dataset *Dataset `json:"dataset,omitempty"`

	// CacheEngine is different kinds of cache engine
	CacheEngine *CacheEngine `json:"cacheEngine,omitempty"`
}

// JobCondition describes the state of the job at a certain point.
// +k8s:deepcopy-gen=true
type JobCondition struct {
	// Type of job condition.
	Type JobConditionType `json:"type"`
	// Status of the condition, one of True, False, Unknown.
	Status v1.ConditionStatus `json:"status"`
	// The reason for the condition's last transition.
	Reason string `json:"reason,omitempty"`
	// A human readable message indicating details about the transition.
	Message string `json:"message,omitempty"`
	// The last time this condition was updated.
	LastUpdateTime metav1.Time `json:"lastUpdateTime,omitempty"`
	// Last time the condition transitioned from one status to another.
	LastTransitionTime metav1.Time `json:"lastTransitionTime,omitempty"`
}

// CleanPodPolicy describes how to deal with pods when the job is finished.
type CleanPodPolicy string

type CronPolicy struct {
	// The schedule in Cron format, see https://en.wikipedia.org/wiki/Cron.
	Schedule string `json:"schedule"`

	// Specifies how to treat concurrent executions of a Task.
	// Valid values are:
	// - "Allow" (default): allows CronJobs to run concurrently;
	// - "Forbid": forbids concurrent runs, skipping next run if previous run hasn't finished yet;
	// - "Replace": cancels currently running job and replaces it with a new one
	// +optional
	ConcurrencyPolicy ConcurrencyPolicy `json:"concurrencyPolicy,omitempty"`

	// This flag tells the controller to suspend subsequent executions, it does
	// not apply to already started executions.  Defaults to false.
	// +optional
	Suspend *bool `json:"suspend,omitempty"`

	// Deadline is the timestamp that a cron job can keep scheduling util then.
	Deadline *metav1.Time `json:"deadline,omitempty"`

	// The number of finished job history to retain.
	// This is a pointer to distinguish between explicit zero and not specified.
	// +optional
	HistoryLimit *int32 `json:"historyLimit,omitempty"`
}

// SchedulingPolicy encapsulates various scheduling policies of the distributed training
// job, for example `minAvailable` for gang-scheduling.
type SchedulingPolicy struct {
	// MinAvailable is the minimum number of scheduable instances for a gang-scheduling to go.
	MinAvailable *int32 `json:"minAvailable,omitempty"`
	// The priority value. KubeDL use this field to find the priority of the job.
	// The controller populates this field from PriorityClassName by default.
	// The higher the value, the higher the priority.
	// +optional
	Priority *int32 `json:"priority,omitempty"`
	// If specified, indicates the jobs's priority. Any other name must be defined
	// by creating a PriorityClass object with that name.
	// If not specified, the job priority will be default or zero if there is no
	// default.
	// +optional
	PriorityClassName string `json:"priorityClassName,omitempty"`
	// Queue indicates the name of tenant queue the job should be enqueued to, this field
	// can be specified manually by job owner, or partitioned by built-in plugin on basis
	// of its namespace/quota or other granularity.
	// +optional
	Queue string `json:"queue,omitempty"`
}

type DAGCondition struct {
	// Upstream defines which replica type is the source tigger.
	Upstream ReplicaType `json:"upstream"`
	// OnPhase defines at which phase the upstream replica will trigger this condition.
	OnPhase v1.PodPhase `json:"onPhase"`
}

// SpotReplicaSpec is the differential spec of spot replicas, to override the replica template.
type SpotReplicaSpec struct {
	// SpotReplicaNumber is the desired number of spot replicas.
	// If unspecified, SpotReplicaNumber defaults to 0.
	// By default, replicas with index in the range from (Replicas - SpotReplicaNumber) to (Replicas -1 ) are spot replicas.
	SpotReplicaNumber int32 `json:"spotReplicaNumber,omitempty"`
	// PriorityClassName is the priorityClassName of spot replicas, to override that in replica template.
	PriorityClassName string `json:"priorityClassName,omitempty"`
	// Labels are the extra set of labels to add on the spot replicas, overriding coinciding labels in the replica template if any.
	Labels map[string]string `json:"labels,omitempty"`
}

type RestartPolicy string

// Dataset is used to define where specific data sources are stored and mounted
// A job may have multiple mount points, so it is a list
type Dataset struct {
	// DataSources is a list of dataset path
	DataSources []DataSource `json:"dataSources,omitempty"`
}

type DataSource struct {
	// Location is the dataset path in variety file system
	Location string `json:"location,omitempty"`

	// SubdirectoryName is used as the file name of the data source in mountPath.
	// The directory structure in container is as follows:
	// - MountPath
	//   - SubDirName1
	//   - SubDirName2
	//   - ...
	SubDirName string `json:"subDirName,omitempty"`
}

type CacheEngine struct {
	// Fluid may be the only caching engine for the time being
	Fluid *Fluid `json:"fluid,omitempty"`
}

// JobConditionType defines all kinds of types of JobStatus.
type JobConditionType string

// ConcurrencyPolicy describes how the job will be handled.
// Only one of the following concurrent policies may be specified.
// If none of the following policies is specified, the default one
// is AllowConcurrent.
type ConcurrencyPolicy string

type Fluid struct {
	// AlluxioRuntime is used to configure the cache runtime
	// If this parameter is not specified, the cache will not take effect and the data set will be directly mounted
	AlluxioRuntime *AlluxioRuntime `json:"alluxioRuntime,omitempty"`
}

type AlluxioRuntime struct {
	// Replicas is the min replicas of dataset in the cluster
	Replicas int32 `json:"replicas,omitempty"`

	// Fluid supports multi-tier configuration
	TieredStorage []Level `json:"tieredStorage,omitempty"`
}

type Level struct {
	// For Alluxio, it will use the cache path directory as its cache store
	CachePath string `json:"cachePath,omitempty"`

	// Quota defines a cache capacity of the directory
	Quota string `json:"quota,omitempty"`

	// Fluid sorts levels according to mediumType
	MediumType string `json:"mediumType,omitempty"`
}

// ModelVersionSpec defines a particular version of the Model.
// Each time a new ModelVersion crd is created, the ModelVersionController will create an image that incorporates the model.
type ModelVersionSpec struct {
	// The Model name for this ModelVersion
	// +required
	ModelName string `json:"modelName,omitempty"`

	// CreatedBy indicates the entity that creates the model version. e.g. the name of the tfjob that creates the ModelVersion. the name
	// of the user that creates the ModelVersion
	// +optional
	CreatedBy string `json:"createdBy,omitempty"`

	// Storage is the location where this ModelVersion is stored.
	// +optional
	Storage *Storage `json:"storage,omitempty"`

	// ImageRepo is the image repository to push the generated model image. e.g. docker hub.  "modelhub/mymodel"
	// A particular image tag is automatically generated by the system when ImageTag is nil, e.g.
	// "modelhub/mymodel:v9epgk"
	// +required
	ImageRepo string `json:"imageRepo,omitempty"`

	// ImageTag is the image tag suffixed with image repo, which indicates a specific image version/variant.
	// If empty, the first 5 digits of this ModelVersion object UID will be used as image tag.
	// +optional
	ImageTag string `json:"imageTag,omitempty"`
}

type Storage struct {
	// NFS represents the alibaba cloud nas storage
	NFS *NFS `json:"nfs,omitempty"`

	// LocalStorage represents the local host storage
	LocalStorage *LocalStorage `json:"localStorage,omitempty"`

	// AWSEfs represents the AWS Elastic FileSystem
	AWSEfs *AWSEfs `json:"AWSEfs,omitempty"`
}

// NFS represents the Alibaba Cloud Nas storage
type NFS struct {
	// NFS server address, e.g. "***.cn-beijing.nas.aliyujcs.com"
	Server string `json:"server,omitempty"`

	// The path under which the model is stored, e.g. /models/my_model1
	Path string `json:"path,omitempty"`

	// The mounted path inside the container.
	// The training code is expected to export the model artifacts under this path, such as storing the tensorflow saved_model.
	MountPath string `json:"mountPath,omitempty"`
}

// LocalStorage defines the local storage for storing the model version.
// For a distributed training job, the nodeName will be the node where the chief/master worker run to export the model.
type LocalStorage struct {
	// The local host path to export the model.
	// +required
	Path string `json:"path,omitempty"`

	// The mounted path inside the container.
	// The training code is expected to export the model artifacts under this path, such as storing the tensorflow saved_model.
	MountPath string `json:"mountPath,omitempty"`

	// The name of the node for storing the model. This node will be where the chief worker run to export the model.
	// +required
	NodeName string `json:"nodeName,omitempty"`
}

type AWSEfs struct {
	// VolumeHandle indicates the backend EFS volume. Check the link for details
	// https://github.com/kubernetes-sigs/aws-efs-csi-driver/tree/master/examples/kubernetes
	// It is of the form "[FileSystemId]:[Subpath]:[AccessPointId]"
	// e.g. FilesystemId with subpath and access point Id:  fs-e8a95a42:/my/subpath:fsap-19f752f0068c22464.
	// FilesystemId with access point Id:   fs-e8a95a42::fsap-068c22f0246419f75
	// FileSystemId with subpath: 	 fs-e8a95a42:/dir1
	VolumeHandle string `json:"volumeHandle,omitempty"`

	// The attributes passed to the backend EFS
	Attributes map[string]string `json:"attributes,omitempty"`
}

const (
	// JobCreated means the job has been accepted by the system,
	// but one or more of the pods/services has not been started.
	// This includes time before pods being scheduled and launched.
	JobCreated JobConditionType = "Created"

	// JobRunning means all sub-resources (e.g. services/pods) of this job
	// have been successfully scheduled and launched.
	// The training is running without error.
	JobRunning JobConditionType = "Running"

	// JobRestarting means one or more sub-resources (e.g. services/pods) of this job
	// reached phase failed but maybe restarted according to it's restart policy
	// which specified by user in v1.PodTemplateSpec.
	// The training is freezing/pending.
	JobRestarting JobConditionType = "Restarting"

	// JobSucceeded means all sub-resources (e.g. services/pods) of this job
	// reached phase have terminated in success.
	// The training is complete without error.
	JobSucceeded JobConditionType = "Succeeded"

	// JobFailed means one or more sub-resources (e.g. services/pods) of this job
	// reached phase failed with no restarting.
	// The training has failed its execution.
	JobFailed JobConditionType = "Failed"
)

type JobConditions []JobCondition

func (jcs JobConditions) Len() int { return len(jcs) }

func (jcs JobConditions) Swap(i, j int) { jcs[i], jcs[j] = jcs[j], jcs[i] }

func (jcs JobConditions) Less(i, j int) bool {
	return jcs[i].LastUpdateTime.Unix() < jcs[j].LastUpdateTime.Unix()
}
