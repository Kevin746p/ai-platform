package response

type GetAbnormalNodes struct {
	NodeName       string   `json:"NodeName"`
	NodeIP         string   `json:"NodeIP"`
	NodeType       string   `json:"NodeType"`
	PodList        []GpuPod `json:"PodList"`
	AbnormalReason string   `json:"AbnormalReason"`
	AbnormalInfo   string   `json:"AbnormalInfo"`
}
type GpuPod struct {
	PodName  string
	GpuCount int
}

type GetResourceNodes struct {
	NodeName   string  `json:"NodeName"`
	NodeIP     string  `json:"NodeIP"`
	CpuRate    float64 `json:"CpuRate"`
	GpuRate    float64 `json:"GpuRate"`
	MemoryRate float64 `json:"MemoryRate"`
}
