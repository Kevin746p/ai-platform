package response

type GpuInfo struct {
	GpuMode   string  `json:"GpuMode"`
	Count     float64 `json:"Count"`     // 总数
	Used      float64 `json:"Used"`      // 已使用数
	NotUsed   float64 `json:"NotUsed"`   // 未使用数
	EightNode float64 `json:"EightNode"` // 空闲8卡节点数
	FourNode  float64 `json:"FourNode"`  // 空闲4卡节点数
	NodeCount float64 `json:"NodeCount"` // 节点数
}

type GpuAvgUsage struct {
	GpuMode          string               `json:"GpuMode"`
	HostName         string               `json:"HostName"`
	Instance         string               `json:"Instance"` // 节点IP
	AvgUsage         float64              `json:"AvgUsage"` // 实时使用率
	AvgUsageWithTime AvgUsageWithTimeList `json:"AvgUsageWithTime,omitempty"`
}
type AvgUsageWithTime struct {
	Time     int64   `json:"Time"`
	AvgUsage float64 `json:"AvgUsage"`
}

type GpuPods struct {
	GpuMode   string  `json:"GpuMode"`
	HostName  string  `json:"HostName"`
	AvgUsage  float64 `json:"AvgUsage"`
	Pod       string  `json:"Pod"`
	PodUsage  int64   `json:"PodUsage"`
	HostUsage int64   `json:"HostUsage"`
}
type GpuClusterAvgUsage struct {
	GPUCalPower          float64                  `json:"GPUCalPower"`
	GPUClusterPowerRate  GpuClusterPowerRateList  `json:"GPUClusterPowerRate"`
	GPUClusterMemoryRate GpuClusterMemoryRateList `json:"GPUClusterMemoryRate"`
}
type GpuScene struct {
	Scene             string  `json:"Scene"`
	ResourceType      string  `json:"ResourceType"`
	GpuCalRateA100    float64 `json:"GpuCalRateA100"`
	GpuCalRateRtx3090 float64 `json:"GpuCalRateRtx3090"`
	OccupyA100        float64 `json:"OccupyA100"`
	OccupyRtx3090     float64 `json:"OccupyRtx3090"`
}
type GpuMonitorTop struct {
	PipelineID   string  `json:"PipelineID"`
	TaskName     string  `json:"TaskName"`
	ResourceType string  `json:"ResourceType"`
	Scene        string  `json:"Scene"`
	Creator      string  `json:"Creator"`
	GpuCalRate   float64 `json:"GpuCalRate"`
	OccupyGpu    float64 `json:"OccupyGpu"`
	GpuMode      string  `json:"GpuMode"`
}
type GpuSceneMonitor struct {
	Scene        string  `json:"Scene"`
	CountA100    int     `json:"CountA100"`
	CountRtx3090 int     `json:"CountRtx3090"`
	ResourceType string  `json:"ResourceType"`
	GpuCalRate   float64 `json:"GpuCalRate"`
}
type GpuPodCalRate struct {
	PipelineID      string  `json:"PipelineID"`
	RateInFiveMin   float64 `json:"RateInFiveMin"`
	RateInThirtyMin float64 `json:"RateInThirtyMin"`
	RateInWhole     float64 `json:"RateInWhole"`
}
type CommonRateWithTime struct {
	Time int64   `json:"Time"`
	Rate float64 `json:"Rate"`
}
type GpuAvgUsageList []GpuAvgUsage
type GpuSceneList []GpuScene
type GpuMonitorTopList []GpuMonitorTop
type GpuSceneMonitorList []GpuSceneMonitor

func (s GpuAvgUsageList) Len() int { return len(s) }

func (s GpuAvgUsageList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

// AvgUsageWithTime默认按照时间排序
func (s GpuAvgUsageList) Less(i, j int) bool {
	return s[i].AvgUsage < s[j].AvgUsage
}

type GpuInfoList []GpuInfo

func (s GpuInfoList) Len() int { return len(s) }

func (s GpuInfoList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s GpuInfoList) Less(i, j int) bool {
	return s[i].NotUsed < s[j].NotUsed
}

func (s GpuSceneMonitorList) Len() int { return len(s) }

func (s GpuSceneMonitorList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s GpuSceneMonitorList) Less(i, j int) bool {
	return s[i].Scene < s[j].Scene
}
func (s GpuSceneList) Len() int { return len(s) }

func (s GpuSceneList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s GpuSceneList) Less(i, j int) bool {
	return s[i].Scene < s[j].Scene
}

type AvgUsageWithTimeList []AvgUsageWithTime

func (s AvgUsageWithTimeList) Len() int { return len(s) }

func (s AvgUsageWithTimeList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s AvgUsageWithTimeList) Less(i, j int) bool {
	return s[i].Time < s[j].Time
}

type GpuClusterPowerRateList []CommonRateWithTime

func (s GpuClusterPowerRateList) Len() int { return len(s) }

func (s GpuClusterPowerRateList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s GpuClusterPowerRateList) Less(i, j int) bool {
	return s[i].Time < s[j].Time
}

type GpuClusterMemoryRateList []CommonRateWithTime

func (s GpuClusterMemoryRateList) Len() int { return len(s) }

func (s GpuClusterMemoryRateList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s GpuClusterMemoryRateList) Less(i, j int) bool {
	return s[i].Time < s[j].Time
}

type PodRangeAvgUsage []CommonRateWithTime

func (s PodRangeAvgUsage) Len() int { return len(s) }

func (s PodRangeAvgUsage) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s PodRangeAvgUsage) Less(i, j int) bool {
	return s[i].Time < s[j].Time
}
