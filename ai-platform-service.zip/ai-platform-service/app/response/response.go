package response

import (
	"reflect"
)

type Response struct {
	RetCode int         `json:"RetCode"`
	Message string      `json:"Message"`
	Data    interface{} `json:"Data"`
	ReqUuid string      `json:"ReqUuid,omitempty"`
	Count   *int        `json:"Count,omitempty"`
}

func NewResponse(reqUuid string, retCode int, message string, data interface{}, count *int) *Response {
	return &Response{
		RetCode: retCode,
		Message: message,
		ReqUuid: reqUuid,
		Data:    data,
		Count:   count,
	}
}

type Pagination struct {
	TotalCount int `json:"TotalCount"`
	Offset     int `json:"Offset"`
	Limit      int `json:"Limit"`
}

func NewPagination(totalCount int, offset int, limit int) *Pagination {
	return &Pagination{
		TotalCount: totalCount,
		Offset:     offset,
		Limit:      limit,
	}
}

type ResponseWithPagination struct {
	*Pagination
	*Response
}

func NewResponseWithPagination(response *Response, pagination *Pagination) *ResponseWithPagination {
	return &ResponseWithPagination{
		Response:   response,
		Pagination: pagination,
	}
}

func Success(reqUuid string, data interface{}) *Response {
	return NewResponse(reqUuid, 0, "", data, nil)
}
func SuccessWithCount(reqUuid string, data interface{}, count *int) *Response {
	return NewResponse(reqUuid, 0, "", data, count)
}

func SuccessWithPagination(reqUuid string, data interface{}, pagination *Pagination) *ResponseWithPagination {
	if v := reflect.ValueOf(data); v.IsNil() {
		data = []interface{}{}
	}
	response := NewResponse(reqUuid, 0, "", data, nil)
	return NewResponseWithPagination(response, pagination)
}

func Error(reqUuid string, retCode int, message string) *Response {
	return NewResponse(reqUuid, retCode, message, nil, nil)
}
