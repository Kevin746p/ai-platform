package response

import "time"

// TODO
type Task struct {
	PipelineID string `json:"PipelineID"`
	BuildID    string `json:"BuildID"`
	PodName    string `json:"PodName,omitempty"`
	Status     string `json:"Status"`
	StatusDesc string `json:"StatusDesc,omitempty"`
	Detail     string `json:"Detail,omitempty"`
	TaskName   string `json:"TaskName"`
	Creator    string `json:"Creator"`
	Namespace  string `json:"Namespace"`
	Scene      string `json:"Scene"`
	CreateTime int64  `json:"CreateTime"`
	UpdateTime int64  `json:"UpdateTime"`
	StatusCode int    `json:"StatusCode"`
	GpuLimit   int    `json:"GpuLimit"`
	MemLimit   int    `json:"MemLimit"`
	CpuLimit   int    `json:"CpuLimit"`
	Stage      []int  `json:"Stage"`
}

type GetTaskPodsResp struct {
	PipelineID string   `json:"PipelineID"`
	BuildID    string   `json:"BuildID"`
	PodName    []string `json:"PodName"`
	Status     string   `json:"Status"`
	StatusDesc string   `json:"StatusDesc"`
}

type GetTask struct {
	PipelineID string `json:"PipelineID"`
	BuildID    string `json:"BuildID"`
	TaskName   string `json:"TaskName"`
	Creator    string `json:"Creator"`
	Namespace  string `json:"Namespace"`
	Scene      string `json:"Scene"`
	CreateTime int64  `json:"CreateTime"`
	UpdateTime int64  `json:"UpdateTime"`
	StatusCode int    `json:"StatusCode"`
	Status     string `json:"Status"`
	StatusDesc string `json:"StatusDesc"`
	GpuLimit   int    `json:"GpuLimit"`
	MemLimit   int    `json:"MemLimit"`
	CpuLimit   int    `json:"CpuLimit"`
	Detail     string `json:"Detail"`
	Stage      []int  `json:"Stage"`
}

type GetLog struct {
	Uuid         string `json:"Uuid"`
	ReqUuid      string `json:"ReqUuid"`
	BusinessType string `json:"BusinessType"`
	OperateType  string `json:"OperateType"`
	ChangeField  string `json:"ChangeField"`
	CurrentValue string `json:"CurrentValue"`
	OldValue     string `json:"OldValue"`
	Creator      string `json:"Creator"`
	CreateTime   int64  `json:"CreateTime"`
	Remark       string `json:"Remark"`
}

type LogItem struct {
	GetLog
	IsTurnOn       int       `json:"IsTurnOn"`
	GpuLimit       int       `json:"GpuLimit"`
	CreateDateTime time.Time `json:"CreateDateTime"`
}

type TaskOperateLogList []LogItem

func (s TaskOperateLogList) Len() int { return len(s) }

func (s TaskOperateLogList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s TaskOperateLogList) Less(i, j int) bool {
	return s[i].CreateTime < s[j].CreateTime
}
