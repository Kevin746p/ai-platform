package cache

import (
	"ai-platform-service/config"
	"context"
	"time"

	"github.com/go-co-op/gocron"
)

type Cache struct {
	cfg       *config.CacheCfg
	scheduler *gocron.Scheduler
	ctx       context.Context
	cancel    context.CancelFunc
}

func (c *Cache) Init() {
	c.cfg = &config.Cfg.Cache
	c.ctx, c.cancel = context.WithCancel(context.Background())
	c.scheduler = gocron.NewScheduler(time.Local)
	//_, _ = c.scheduler.Every(c.cfg.IntervalSyncTaskInfo).Seconds().Do(SyncTaskInfo)
	//_, _ = c.scheduler.Every(c.cfg.IntervalSyncTaskStatus).Seconds().Do(SyncTaskStatus)
	//_, _ = c.scheduler.Every(c.cfg.IntervalSyncResourceGpuUsage).Minute().Do(SyncResourceGpuUsage)
	//_, _ = c.scheduler.Every(c.cfg.IntervalSyncMonitorData).Day().At(c.cfg.IntervalSyncMonitorDataTime).Do(syncMonitorData)
}
func (c *Cache) Start() error {
	c.scheduler.StartAsync()
	return nil
}
func (c *Cache) Stop() error {
	c.cancel()
	c.scheduler.Stop()
	return nil
}
func (c *Cache) Name() string { return "SyncCache" }
