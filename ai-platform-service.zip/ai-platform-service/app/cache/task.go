package cache

import (
	"ai-platform-service/app/api/gpu"
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/model"
	"ai-platform-service/app/nacos"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/config"
	"fmt"
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/util/gconv"
	"go.uber.org/zap"
	"strings"
	"sync"
	"time"
)

var taskCacheObj = &taskCache{}

type taskCache struct {
	lock    sync.RWMutex
	taskMap map[string]model.Task
}

var AbnormalNodeList []response.GetAbnormalNodes

type nodeComponent struct {
	NodeType            string
	GpuUseAble          bool
	GpuUseAbleErrorInfo string
	NodeIP              string
	NodeName            string
	IsComponentRight    bool
	LackedComponents    string
	IsLabelRight        bool
	LabelErrorInfo      string
	IsTaintsRight       bool
	TaintsErrorInfo     string
	GpuPodList          []response.GpuPod
}
type podItem struct {
	podName, podStatus string
}
type timeInterval struct {
	Start      int64
	End        int64
	IsNew      bool
	IsComplete bool
	GpuLimit   int
}
type gpuUseRate struct {
	Start    int64
	End      int64
	Rate     float64
	GpuLimit int
}
type gpuUseList []gpuUseRate
type timeIntervalList []timeInterval
type cronTaskSyncTaskStatus struct {
	runCount int
	next     bool
	Name     string
}

var cronSyncTaskStatus = cronTaskSyncTaskStatus{
	Name: "CronSyncTaskStatus",
}

func GetTaskInfo(pid string) (model.Task, bool) {
	taskCacheObj.lock.RLock()
	defer taskCacheObj.lock.RUnlock()
	if v, ok := taskCacheObj.taskMap[pid]; ok {
		return v, ok
	}
	return model.Task{}, false
}

func GetAllTaskInfo() map[string]model.Task {
	taskCacheObj.lock.RLock()
	defer taskCacheObj.lock.RUnlock()
	tasks := make(map[string]model.Task)
	for k, v := range taskCacheObj.taskMap {
		tasks[k] = v
	}
	return tasks
}

func SyncTaskInfo() {
	g.Log().Info("[cache][SyncTaskInfo] task start")
	var tasks []model.Task
	if err := database.Train.DB.Model(model.Task{}).
		Where("status != ?", enum.TaskDeleted).
		Scan(&tasks); err != nil {
		g.Log().Error("[cache][SyncTaskInfo] get tasks failed :", err.Error())
		return
	}
	taskMap := make(map[string]model.Task)
	for _, v := range tasks {
		taskMap[v.PipelineID] = v
	}
	taskCacheObj.lock.Lock()
	defer taskCacheObj.lock.Unlock()
	taskCacheObj.taskMap = taskMap
	g.Log().Info("[cache][SyncTaskInfo] sync task info end", len(taskMap), len(taskCacheObj.taskMap))
}

func SyncTaskStatus() {
	if !nacos.NacosClients.IsMinWeightInstance() {
		return
	}
	if cronSyncTaskStatus.next {
		return
	}
	cronSyncTaskStatus.next = true
	tasks := GetAllTaskInfo()
	g.Log().Info("[cache][SyncTaskInfo] sync task status start, task count", len(tasks))
	updatedCount := cronSyncTaskStatus.updateTasksStatus(tasks)
	cronSyncTaskStatus.next = false
	cronSyncTaskStatus.runCount++
	g.Log().Info("[cache][SyncTaskInfo] sync task status end, update count:", updatedCount, "task run count:", cronSyncTaskStatus.runCount)
}

func (c *cronTaskSyncTaskStatus) updateTasksStatus(tasks map[string]model.Task) (updatedCount int) {
	var logList []*model.Log
	for _, v := range tasks {
		if v.Status == enum.TaskComplete || v.Status == enum.TaskCanceled || v.Status == enum.TaskFailed || v.Status == enum.TaskRunErr || v.Status == enum.TaskJobNotExists {
			continue
		}
		status, errDesc := k8s.K8s.GetResourceStatus(v.Namespace, v.ResourceType, v.TaskName+"-"+v.BuildID)

		if strings.Contains(errDesc, "connect: connection refused") || strings.Contains(errDesc, "context canceled") {
			continue
		}
		// TODO 由于镜像过大，可能存在20min镜像未创建 暂定为 20 min
		if status == enum.TaskPodPending && errDesc != "" && time.Since(v.CreateTime).Minutes() > config.Cfg.Cache.WaitingDurationSyncTaskStatus {
			status = enum.TaskRunErr
		}
		// TODO Notebook 暂定为 20 min 镜像初始化
		if status == enum.TaskComplete && v.ResourceType == config.Cfg.K8s.NoteBookKind && time.Since(v.ModifyTime).Minutes() < config.Cfg.Cache.WaitingDurationSyncTaskStatus {
			continue
		}

		// TODO 批量更新

		if status != v.Status && status != 0 {
			if v.ResourceType == config.Cfg.K8s.NoteBookKind && utils.IsExistInt(config.Cfg.Cache.SyncMonitorTaskStatus, status) {

				logList = append(logList, &model.Log{
					UUID:         v.PipelineID,
					BusinessType: enum.NotebookBusinessType,
					OperateType:  "",
					IsTurnOn:     enum.TurnOff,
					GpuLimit:     v.GpuLimit,
					ChangeField:  "status",
					CurrentValue: gconv.String(status),
					OldValue:     gconv.String(v.Status),
					Remark:       enum.WebIEDFirstDemotion,
					CreateBy:     enum.OperatorType,
					CreateTime:   time.Now(),
				})
			}
			_, err := database.Train.DB.Model(model.Task{}).
				Data(g.Map{
					"status":      status,
					"err_desc":    errDesc,
					"modify_time": time.Now(),
				}).
				Where("pipeline_id = ? and status = ?", v.PipelineID, v.Status).
				Update()
			g.Log().Info("sync task status, task update", zap.String("pipeline id", v.PipelineID), zap.Any("status", status), zap.Any("errdesc", errDesc))
			if err != nil {
				g.Log().Error("update task info error", v.PipelineID, status, err.Error())
				continue
			}
			updatedCount++
		}
	}
	if len(logList) > 0 {
		err := model.Log{}.Insert(logList)
		if err != nil {
			g.Log().Error("[cache][cronTaskSyncTaskStatus] write log failed", err)
		}
	}

	return updatedCount
}
func syncMonitorData() {
	g.Log().Info("[cache][syncMonitorData] task start")
	now := time.Now()
	d, _ := time.ParseDuration("-24h")
	StartDate := now.Add(d).Format("2006-01-02")
	EndDate := now.Format("2006-01-02")
	StartTime, _ := time.ParseInLocation("2006-01-02", StartDate, time.Local)
	EndTime, _ := time.ParseInLocation("2006-01-02", EndDate, time.Local)

	var tasks []model.Task
	if err := database.Train.DB.Model(model.Task{}).
		Where("(scene is not null and scene != ?) and (task_name like ? or task_name like ?) and"+
			" ( status = ? or ((status in (?)) and modify_time between ? and ?))",
			"", fmt.Sprint(enum.TaskPrefix, "%"), fmt.Sprint(enum.NotebookPrefix, "%"),
			enum.TaskRunning, config.Cfg.Cache.SyncMonitorTaskStatus, StartDate, EndDate).
		Scan(&tasks); err != nil {
		g.Log().Error("[cache][SyncTaskInfo] get tasks failed :", err.Error())
		return
	}
	g.Log().Info("[cache][syncMonitorData] task start", len(tasks))

	var GpuStatisticsData []model.TaskMonitor

	for _, task := range tasks {
		taskName := task.TaskName + "-" + task.BuildID
		var isFinish bool
		var gpuUsage, gpuOccupyTime, GpuCalRate float64
		var resourceType string
		if strings.HasPrefix(taskName, enum.NotebookPrefix) {
			resourceType = enum.NotebookBusinessType
		} else if strings.HasPrefix(taskName, enum.TaskPrefix) {
			resourceType = enum.TaskBusinessType
		}
		if task.ResourceType == enum.TaskNotebookResorceType {
			//取时间交集的对标时间
			targetTimeInterval := utils.TimeInterval{
				Start: StartTime.Unix(),
				End:   EndTime.Unix(),
			}
			logList, err := getLogList(task.PipelineID)
			if err != nil {
				g.Log().Error("[cache][syncMonitorData] get task operate log failed", task.PipelineID, err.Error())
				continue
			}
			timeIntervalSlice := timeIntervalList{}
			timeIntervalEnd := timeInterval{
				IsNew: true,
			}
			var lastGpuLimit int
			timeIntervalSlice = getTimeIntervalList(logList, timeIntervalEnd, timeIntervalSlice, lastGpuLimit, EndTime)
			if len(timeIntervalSlice) == 0 {
				gpuOccupyTime = 0
			} else {
				gpuOccupyTime, GpuCalRate = getOccupyTimeAndCpuCalRate(timeIntervalSlice, targetTimeInterval, taskName, gpuOccupyTime, GpuCalRate)
			}

		} else {
			var startUseGpuTime, endUseGpuTime time.Time
			startUseGpuTime = task.CreateTime
			if task.CreateTime.Before(StartTime) {
				startUseGpuTime = StartTime
			}
			if task.Status == enum.TaskRunning {
				endUseGpuTime = EndTime
				isFinish = false
			} else { //完成状态的任务
				endUseGpuTime = task.ModifyTime
				isFinish = true
			}
			if endUseGpuTime.Before(startUseGpuTime) {
				g.Log().Info("[cache][syncMonitorData] endUseGpuTime before startUseGpuTime", task.PipelineID, taskName)
				continue
			}
			podGpuUsage, err := utils.GetPodCardGpuUsage(startUseGpuTime.Unix(), endUseGpuTime.Unix(), 0, taskName)
			if err != nil {
				g.Log().Error("[cache][syncMonitorData] get pod gpu cal failed", task.PipelineID, taskName, err.Error())
				continue
			}
			if len(podGpuUsage) == 0 {
				if _, err := database.Train.DB.Model(model.TaskMonitor{}).Save(&model.TaskMonitor{
					PipelineID:    task.PipelineID,
					Scene:         task.Scene,
					TaskName:      taskName,
					ResourceType:  resourceType,
					GpuCalRate:    0,
					GpuOccupyTime: 0,
					GpuMode:       task.NodeType,
					IsFinish:      utils.FormatBoolWithInt(isFinish),
					CreateDate:    StartTime,
					CreateTime:    now,
				}); err != nil {
					g.Log().Error("[cache][syncMonitorData] insert monitor data failed", task, err.Error())

				}
				continue
			}
			gpuOccupyTime = endUseGpuTime.Sub(startUseGpuTime).Minutes() * float64(task.GpuLimit)
			for _, eachGpuInfo := range podGpuUsage {
				gpuUsage += gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(eachGpuInfo.Rate)))
			}
			GpuCalRate = gpuUsage / gconv.Float64(len(podGpuUsage))

		}
		taskMonitor := model.TaskMonitor{
			PipelineID:    task.PipelineID,
			Scene:         task.Scene,
			TaskName:      taskName,
			ResourceType:  resourceType,
			GpuCalRate:    GpuCalRate,
			GpuOccupyTime: gpuOccupyTime,
			GpuMode:       task.NodeType,
			IsFinish:      utils.FormatBoolWithInt(isFinish),
			CreateDate:    StartTime,
			CreateTime:    now,
		}
		GpuStatisticsData = append(GpuStatisticsData, taskMonitor)
		if _, err := database.Train.DB.Model(model.TaskMonitor{}).Save(&taskMonitor); err != nil {
			g.Log().Error("[cache][syncMonitorData] insert monitor data failed", task, err.Error())
		}
	}
	syncGpuStatisticsData(GpuStatisticsData)
}

func syncGpuStatisticsData(syncData []model.TaskMonitor) {
	g.Log().Info("[cache][syncGpuStatisticsData] task start")
	GpuInfo := gpu.GetGpuInfo{}
	data, err := GpuInfo.GetData()
	if err != nil {
		g.Log().Error("GpuInfo error", err)
		return
	}
	statisticData := map[string]model.GpuUsageStatistics{}
	statisticData["A100"] = model.GpuUsageStatistics{GpuMode: "A100"}
	statisticData["RTX3090"] = model.GpuUsageStatistics{GpuMode: "RTX3090"}
	for _, statistics := range statisticData {
		now := time.Now()
		d, _ := time.ParseDuration("-24h")
		statistics.StatisticsData = now.Add(d)
		statistics.CreateTime = now
		for _, datum := range data {
			if datum.GpuMode == statistics.GpuMode {
				statistics.GpuTotal = int(datum.Count)
			}
		}
		for _, item := range syncData {
			if item.GpuMode == statistics.GpuMode {
				statistics.OccupyDuration += item.GpuOccupyTime
				statistics.UsageDuration += item.GpuOccupyTime * item.GpuCalRate / 100
			}
		}
		if statistics.OccupyDuration != 0 {
			statistics.UsageRate = statistics.UsageDuration / statistics.OccupyDuration * 100
		}
		if statistics.GpuTotal != 0 {
			statistics.OccupyRate = statistics.OccupyDuration / (float64(statistics.GpuTotal) * 24 * 60) * 100
		}
		g.Log().Info("[cache][syncGpuStatisticsData]", statistics)
		err := savaStatisticsData(statistics)
		if err != nil {
			g.Log().Error("savaStatisticsData error ", err)
			return
		}
	}
	g.Log().Info("[cache][syncGpuStatisticsData] task end")
}

func savaStatisticsData(data model.GpuUsageStatistics) error {
	db := database.Train.DB.Model(model.GpuUsageStatistics{})
	_, err := db.Save(&data)
	if err != nil {
		g.Log().Error("savaStatisticsData", err)
		return err
	}
	return nil
}

func getOccupyTimeAndCpuCalRate(timeIntervalSlice timeIntervalList, targetTimeInterval utils.TimeInterval, taskName string, gpuOccupyTime float64, GpuCalRate float64) (float64, float64) {
	notebookGpuUseRate := gpuUseList{}
	for _, timeItem := range timeIntervalSlice {
		logTimeInterval := utils.TimeInterval{
			Start: timeItem.Start,
			End:   timeItem.End,
		}
		timeSlice := utils.TimeSlice{targetTimeInterval, logTimeInterval}
		timeIntersect := timeSlice.Intersect()
		var step int64
		if len(timeIntersect) > 0 {
			if timeIntersect[0].End-timeIntersect[0].Start > int64(time.Hour.Seconds()) {
				step = int64(time.Hour.Seconds())
			} else if timeIntersect[0].End-timeIntersect[0].Start > int64(time.Hour.Seconds()*24) {
				step = int64(time.Hour.Seconds()) * 24
			} else {
				step = int64(time.Minute.Seconds())
			}
			podGpuUsage, err := utils.GetPodCardGpuUsage(timeIntersect[0].Start, timeIntersect[0].End, step, taskName)
			if err != nil {
				g.Log().Error("[cache][syncMonitorData] GetPodCardGpuUsage  failed", taskName,
					timeIntersect[0].Start, timeIntersect[0].End, step, err.Error())
				notebookGpuUseRate = append(notebookGpuUseRate, gpuUseRate{
					Start:    timeIntersect[0].Start,
					End:      timeIntersect[0].End,
					Rate:     0,
					GpuLimit: timeItem.GpuLimit,
				})
				continue
			}
			if len(podGpuUsage) == 0 {
				notebookGpuUseRate = append(notebookGpuUseRate, gpuUseRate{
					Start:    timeIntersect[0].Start,
					End:      timeIntersect[0].End,
					Rate:     0,
					GpuLimit: timeItem.GpuLimit,
				})
				continue
			}
			var gpuUsage float64
			for _, eachGpuMemoryInfo := range podGpuUsage {
				gpuUsage += gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(eachGpuMemoryInfo.Rate)))
			}
			notebookGpuUseRate = append(notebookGpuUseRate, gpuUseRate{
				Start:    timeIntersect[0].Start,
				End:      timeIntersect[0].End,
				Rate:     gpuUsage / gconv.Float64(len(podGpuUsage)),
				GpuLimit: timeItem.GpuLimit,
			})

		}
	}
	var totalRateNumerator, totalRateDenominator float64 //计算使用率的分子 分母
	for _, rateItem := range notebookGpuUseRate {
		itemOccupyTime := float64((rateItem.End-rateItem.Start)/int64(time.Minute.Seconds())) * float64(rateItem.GpuLimit)
		gpuOccupyTime += itemOccupyTime
		totalRateNumerator += itemOccupyTime * rateItem.Rate * float64(rateItem.GpuLimit)
		totalRateDenominator += itemOccupyTime * float64(rateItem.GpuLimit)
	}
	if totalRateDenominator == 0 {
		GpuCalRate = 0
	} else {
		GpuCalRate = totalRateNumerator / totalRateDenominator
	}
	return gpuOccupyTime, GpuCalRate
}

func getTimeIntervalList(logList response.TaskOperateLogList, timeIntervalEnd timeInterval, timeIntervalSlice timeIntervalList, lastGpuLimit int, EndTime time.Time) timeIntervalList {
	for _, item := range logList {
		if item.IsTurnOn == enum.TurnOn {
			if timeIntervalEnd.IsNew {
				timeIntervalEnd.IsNew = false
				timeIntervalEnd.Start = item.CreateTime
				timeIntervalEnd.GpuLimit = item.GpuLimit
			} else {
				timeIntervalEnd = timeInterval{
					IsNew: true,
				}
			}
		} else if item.IsTurnOn == enum.TurnOff {
			if !timeIntervalEnd.IsNew {
				timeIntervalEnd.End = item.CreateTime
				timeIntervalEnd.IsComplete = true
			}
		} else {
			continue
		}
		if timeIntervalEnd.IsComplete {
			timeIntervalSlice = append(timeIntervalSlice, timeIntervalEnd)
			timeIntervalEnd = timeInterval{
				IsNew: true,
			}
		}
		lastGpuLimit = item.GpuLimit
	}
	if !timeIntervalEnd.IsComplete {
		timeIntervalEnd.End = EndTime.Unix()
		timeIntervalEnd.IsComplete = true
		timeIntervalEnd.GpuLimit = lastGpuLimit
		timeIntervalSlice = append(timeIntervalSlice, timeIntervalEnd)
	}
	return timeIntervalSlice
}

func getLogList(PipelineID string) (dataList response.TaskOperateLogList, err error) {
	var logList []model.Log
	err = database.Train.DB.Model(model.Log{}).
		Where("uuid = ? and business_type = ?",
			PipelineID, enum.NotebookBusinessType).Scan(&logList)
	if err != nil {
		return
	}
	if len(logList) == 0 {
		return dataList, fmt.Errorf("%s log is nil", PipelineID)
	}
	for _, item := range logList {
		dataList = append(dataList, response.LogItem{
			GetLog: response.GetLog{
				Uuid:         item.UUID,
				ReqUuid:      item.ReqUuid,
				BusinessType: item.BusinessType,
				OperateType:  item.OperateType,
				ChangeField:  item.ChangeField,
				CurrentValue: item.CurrentValue,
				OldValue:     item.OldValue,
				Creator:      item.CreateBy,
				CreateTime:   item.CreateTime.Unix(),
				Remark:       item.Remark,
			},
			IsTurnOn:       item.IsTurnOn,
			GpuLimit:       item.GpuLimit,
			CreateDateTime: item.CreateTime,
		})
	}
	return
}
