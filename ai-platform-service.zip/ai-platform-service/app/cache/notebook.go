package cache

import (
	"ai-platform-service/app/api/common"
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/model"
	"ai-platform-service/app/utils"
	"ai-platform-service/config"
	"database/sql"
	"fmt"
	uuid "github.com/satori/go.uuid"
	"time"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/util/gconv"
)

var cronSyncResourceGpuUsage = cronTaskResourceGpuUsage{
	Name: "cronSyncResourceGpuUsage",
}

type cronTaskResourceGpuUsage struct {
	runCount int
	next     bool
	Name     string
}

func SyncResourceGpuUsage() {
	if cronSyncResourceGpuUsage.next {
		return
	}
	cronSyncResourceGpuUsage.next = true
	notebooks, err := cronSyncResourceGpuUsage.getRunningNotebooks()
	if err != nil {
		g.Log().Error("[cache][SyncResourceGpuUsage] getRunningNotebooks failed ", err)
		cronSyncResourceGpuUsage.next = false
		return
	}
	updatedCount := cronSyncResourceGpuUsage.checkTaskResource(notebooks)
	cronSyncResourceGpuUsage.next = false
	cronSyncResourceGpuUsage.runCount++
	g.Log().Info("[cache][SyncResourceGpuUsage] sync resource usage, update count:", updatedCount, "task run count:", cronSyncResourceGpuUsage.runCount)
}

// 部分数据不降级
func (c *cronTaskResourceGpuUsage) getRunningNotebooks() (tasks []model.Task, err error) {
	err = database.Train.DB.Model(model.Task{}).
		Where("status = ? and resource_type  = ? and remark != ?", enum.TaskRunning, config.Cfg.K8s.NoteBookKind, enum.ResourceRecycleNever).
		Scan(&tasks)
	return
}

func (c *cronTaskResourceGpuUsage) checkTaskResource(tasks []model.Task) (updatedCount int) {
	reqUid := uuid.NewV4().String()
	for _, v := range tasks {
		resourceName := v.TaskName + "-" + v.BuildID
		timeNow := time.Now()
		// Cpu降级
		if v.GpuLimit == 0 || v.NodeType == enum.ResourceTypeMIG {
			// 若任务距离上次更新时间不足则不更新
			if time.Since(v.ModifyTime).Minutes() <= gconv.Float64(config.Cfg.ExternalUrl.CpuPodCardUsageUrlRange) {
				continue
			}
			cpuUsage, err := utils.GetPodCpuUsage(resourceName)
			if err != nil {
				g.Log().Error("[cache][SyncResourceGpuUsage] checkTaskResource GetPodCpuUsage failed", err.Error())
				continue
			}
			g.Log().Info("[cache][SyncResourceGpuUsage] checkTaskResource cpu info", resourceName, cpuUsage)
			// 未获取到直接跳过本次降级
			if len(cpuUsage) == 0 {
				continue
			}
			var usage float64
			for _, eachCpuInfo := range cpuUsage {
				usage += gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(eachCpuInfo.Value)))
			}
			if (usage / gconv.Float64(len(cpuUsage))) <= gconv.Float64(config.Cfg.ExternalUrl.CpuPodCardUsageUrlThreshold) {
				var replicas int32
				if err := k8s.K8s.UpdateStatefulSetReplicas(v.Namespace, resourceName, &replicas); err != nil {
					g.Log().Info("[cache][SyncResourceGpuUsage] UpdateStatefulSetReplicas", resourceName, err.Error())
					continue
				}
				g.Log().Info("[cache][SyncResourceGpuUsage] UpdateStatefulSetReplicas stopped", resourceName)
				var updateResult sql.Result
				if updateResult, err = database.Train.DB.Model(model.Task{}).
					Data(g.Map{"status": enum.TaskComplete, "modify_time": time.Now()}).
					Where("pipeline_id = ? and status = ?", v.PipelineID, v.Status).
					Update(); err != nil {
					g.Log().Error("[cache][SyncResourceGpuUsage] cronTaskResourceGpuUsage ", resourceName, err.Error())
					continue
				}
				count, err := updateResult.RowsAffected()
				if err != nil {
					g.Log().Error("[cache][SyncResourceGpuUsage] get log count failed", err)
				}
				if count > 0 {
					var logList []*model.Log
					logList = append(logList, &model.Log{
						UUID:         v.PipelineID,
						ReqUuid:      reqUid,
						BusinessType: enum.NotebookBusinessType,
						ChangeField:  "status",
						CurrentValue: gconv.String(enum.TaskComplete),
						OldValue:     gconv.String(v.Status),
						Remark:       enum.WebIEDSecondDemotion,
						IsTurnOn:     enum.TurnOff,
						CreateBy:     enum.OperatorType,
						CreateTime:   timeNow,
					})
					err = model.Log{}.Insert(logList)
					if err != nil {
						g.Log().Error("[cache][SyncResourceGpuUsage] write log failed", err)
					}
				}

				updatedCount++
			}
		} else {
			// 若任务距离上次更新时间不足则不更新
			if time.Since(v.ModifyTime).Minutes() <= gconv.Float64(config.Cfg.ExternalUrl.GpuPodCardUsageUrlRange) {
				continue
			}
			start := time.Now().Add(-(time.Duration(config.Cfg.ExternalUrl.GpuPodCardUsageUrlRange) * time.Minute)).Unix()
			podGpuUsage, err := utils.GetPodCardGpuUsage(start, 0, 0, resourceName)
			if err != nil {
				g.Log().Error("[cache][SyncResourceGpuUsage] checkTaskResource GetPodCardGpuUsage failed", reqUid, err.Error())
				continue
			}
			g.Log().Info("[cache][SyncResourceGpuUsage] GetPodCardGpuUsage gpu info", resourceName, podGpuUsage)
			gpuMemoryQuery := fmt.Sprintf(config.Cfg.ExternalUrl.GpuPodMemoryUsage, resourceName, resourceName, resourceName)
			podGpuMemoryUsage, err := utils.GetPodRangeAvgUsage(start, 0, 0, gpuMemoryQuery)
			if err != nil {
				g.Log().Error("[cache][SyncResourceGpuUsage] checkTaskResource GetPodRangeAvgUsage failed", reqUid, err.Error())
				continue
			}
			g.Log().Info("[cache][SyncResourceGpuUsage] GetPodRangeAvgUsage gpu memory info", reqUid, resourceName, podGpuMemoryUsage)
			// 未获取到直接跳过本次降级
			if len(podGpuUsage) == 0 || len(podGpuMemoryUsage) == 0 {
				continue
			}
			var gpuUsage, gpuMemoryUsage float64
			for _, eachGpuMemoryInfo := range podGpuUsage {
				gpuMemoryUsage += gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(eachGpuMemoryInfo.Rate)))

			}
			for _, eachGpuInfo := range podGpuMemoryUsage {
				gpuUsage += gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(eachGpuInfo.Rate)))

			}
			// 剥离Gpu
			if gpuUsage/gconv.Float64(len(podGpuUsage)) <= gconv.Float64(config.Cfg.ExternalUrl.GpuPodCardUsageUrlThreshold) &&
				gpuMemoryUsage/gconv.Float64(len(podGpuMemoryUsage)) <= gconv.Float64(config.Cfg.ExternalUrl.GpuMemoryPodCardUsageUrlThreshold) {
				cpuLimit := gconv.Int32(v.CpuLimit)
				memLimit := gconv.Int32(v.MemLimit)
				gpuMode := common.TranslateNodeSelector(v.NodeType, 0)
				if err := k8s.K8s.UpdateNotebookResourceGpu(v.Namespace, resourceName, v.ResourceType, gpuMode, nil, &cpuLimit, &memLimit); err != nil {
					g.Log().Error("[cache][SyncResourceGpuUsage] UpdateNotebookResourceGpu failed", reqUid, resourceName, err.Error())
					continue
				}
				g.Log().Info("[cache][SyncResourceGpuUsage] UpdateNotebookResourceGpu", reqUid, resourceName, cpuLimit, memLimit)
				var updateResult sql.Result
				if updateResult, err = database.Train.DB.Model(model.Task{}).
					Data(g.Map{"gpu_limit": 0, "modify_time": time.Now()}).
					Where("pipeline_id = ? and gpu_limit = ?", v.PipelineID, v.GpuLimit).
					Update(); err != nil {
					g.Log().Error("[cache][SyncResourceGpuUsage] cronTaskResourceGpuUsage ", reqUid, resourceName, err.Error())
					continue
				}
				count, err := updateResult.RowsAffected()
				if err != nil {
					g.Log().Error("[cache][SyncResourceGpuUsage] get log count failed", reqUid, err)
				}
				if count > 0 {
					var logList []*model.Log
					logList = append(logList, &model.Log{
						UUID:         v.PipelineID,
						ReqUuid:      reqUid,
						BusinessType: enum.NotebookBusinessType,
						ChangeField:  "gpu_limit",
						CurrentValue: "0",
						OldValue:     gconv.String(v.GpuLimit),
						Remark:       enum.WebIEDFirstDemotion,
						IsTurnOn:     enum.TurnOn,
						CreateBy:     enum.OperatorType,
						CreateTime:   timeNow,
					})
					err = model.Log{}.Insert(logList)
					if err != nil {
						g.Log().Error("[cache][SyncResourceGpuUsage] write log failed", err)
					}
				}
				updatedCount++
			}
		}

	}
	return updatedCount
}
