package api

import (
	"ai-platform-service/app/enum"
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/gogf/gf/text/gregex"

	"github.com/gogf/gf/util/gconv"
	"github.com/gogf/gf/util/gvalid"
)

// API 自定义校验规则
var CustomRules = map[string]gvalid.RuleFunc{
	"integerMulti":   integerMultiChecker,  // 整数倍校验
	"caseSensitive":  caseSensitiveChecker, // 大小写敏感校验
	"validTimestamp": validTimestamp,       // 时间戳级别校验
}

//results        = ruleRegex.FindStringSubmatch(ruleItems[index]) // split single rule.
const singleRulePattern = `^([\w-]+):{0,1}(.*)` // regular expression pattern for single validation rule.

// 整数倍校验
func integerMultiChecker(ctx context.Context, rule string, value interface{}, message string, data interface{}) error {
	mod := gconv.Int(strings.Split(rule, ":")[1])
	num := gconv.Int(value)
	if mod == 0 {
		return fmt.Errorf("integerMultiChecker invalid mod %s ", rule)
	}
	if num > enum.GpuNodeCount && num%mod != 0 {
		return fmt.Errorf("%s %d ", message, num)
	}
	return nil
}

// 字段Key大小写敏感校验
func caseSensitiveChecker(ctx context.Context, rule string, value interface{}, message string, data interface{}) error {
	if len(strings.Split(rule, ":")) != 2 {
		return fmt.Errorf("invalid rule %s", rule)
	}
	fieldName := strings.Split(rule, ":")[1]
	switch data.(type) {
	case map[string]interface{}:
		if _, ok := data.(map[string]interface{})[fieldName]; !ok && value != nil {
			return fmt.Errorf("the field key %s is required", fieldName)
		}
	default:
		return errors.New("invalid request param type")
	}
	return nil
}

// 时间戳级别校验
func validTimestamp(ctx context.Context, rule string, value interface{}, message string, data interface{}) error {
	result, err := gregex.MatchString(singleRulePattern, rule)
	if err != nil {
		return err
	}
	_err := fmt.Errorf("invalid timestamp level,need level:" + result[2])
	switch result[2] {
	case "s":
		if gconv.Int64(value)/1e10 != 0 {
			return _err
		}
		return nil
	case "ms":
		if gconv.Int64(value)/1e13 != 0 {
			return _err
		}
		return nil
	case "μs":
		if gconv.Int64(value)/1e16 != 0 {
			return _err
		}
		return nil
	}
	return _err
}
