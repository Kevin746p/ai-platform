package log

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"fmt"
	"github.com/gogf/gf/database/gdb"
	"github.com/gogf/gf/net/ghttp"
)

type OperateLog struct {
	req request.GetLog
}

func (a OperateLog) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	var logList []model.Log
	query := database.Train.DB.Model(model.Log{})
	countQuery := database.Train.DB.Model(model.Log{}).Fields("id")
	query = a.getQuery(query)
	countQuery = a.getQuery(countQuery)
	err := query.Scan(&logList)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	count, err := countQuery.Count()
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	var dataList []response.GetLog
	for _, item := range logList {
		dataList = append(dataList, response.GetLog{
			Uuid:         item.UUID,
			ReqUuid:      item.ReqUuid,
			BusinessType: item.BusinessType,
			OperateType:  item.OperateType,
			ChangeField:  item.ChangeField,
			CurrentValue: item.CurrentValue,
			OldValue:     item.OldValue,
			Remark:       item.Remark,
			Creator:      item.CreateBy,
			CreateTime:   item.CreateTime.Unix(),
		})
	}

	return response.SuccessWithCount(a.req.Common.ReqUuid, dataList, &count)
}
func (a *OperateLog) getQuery(query *gdb.Model) *gdb.Model {
	query = query.Where("uuid = ? and business_type = ?", a.req.Uuid, a.req.BusinessType).OrderDesc("id")
	if a.req.OperateType != "" {
		query.Where("operate_type =", a.req.OperateType)
	}
	if a.req.Creator != "" {
		query.Where("create_by =", a.req.Creator)
	}
	return query
}
