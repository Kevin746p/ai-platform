package gpu

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/config"
	"fmt"
	"sort"

	"go.uber.org/zap"

	"github.com/gogf/gf/net/ghttp"

	"github.com/gogf/gf/frame/g"
)

type GetGpuInfo struct {
	req request.GetGpuInfo
}

func (a GetGpuInfo) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(fmt.Sprintf(fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()), err.Error()), err.Error()),
		)
	}
	resp, err := a.GetData()
	if err != nil {
		g.Log().Error("[api][gpu] info get gpu info failed:", a.req.Common.ReqUuid, zap.Error(err))
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuInfoFailed,
			fmt.Sprintf(enum.ErrDescGetGpuInfoFailed, err.Error()),
		)
	}
	return response.Success(a.req.Common.ReqUuid, resp)
}

func (a *GetGpuInfo) GetData() (gpuInfo response.GpuInfoList, err error) {
	// 获取GPU卡数
	err, count := utils.GetGpuCardCountByType()
	if err != nil {
		g.Log().Error("[api][gpu] info GetGpuCardCountByType failed", a.req.Common.ReqUuid, err.Error())
		return
	}
	g.Log().Info("[api][gpu] info GetGpuCardCountByType ", a.req.Common.ReqUuid, count)
	err, notUsedCount := utils.GetGpuLeftCardCount()
	if err != nil {
		g.Log().Error("[api][gpu] info GetGpuLeftCardCount failed", a.req.Common.ReqUuid, err.Error())
		return
	}
	g.Log().Info("[api][gpu] info GetGpuLeftCardCount", a.req.Common.ReqUuid, notUsedCount)
	err, freeNodeCount := utils.GetGpuFreeNode()
	if err != nil {
		g.Log().Error("[api][gpu] info GetFreeNodeCount failed", a.req.Common.ReqUuid, err.Error())
		return
	}
	g.Log().Info("[api][gpu] info GetFreeNodeCount", a.req.Common.ReqUuid, freeNodeCount)
	nodeCountMap := config.Cfg.ExternalUrl.ResourceNodeCount
	for _, v := range nodeCountMap {
		if v < 0 {
			err, nodeCountMap = utils.GetGpuNodeCount()
			if err != nil {
				g.Log().Error("[api][gpu] info GetGpuNodeCount failed", a.req.Common.ReqUuid, err.Error())
				return
			}
			break
		}
	}
	for gpuMode, count := range count {
		freeNode := new(utils.GpuCardCount)
		if _, ok := freeNodeCount[gpuMode]; ok {
			freeNode = freeNodeCount[gpuMode]
		}
		nodeCount, ok := nodeCountMap[gpuMode]
		if !ok {
			nodeCount = 0
		}
		gpuInfo = append(gpuInfo, response.GpuInfo{
			GpuMode:   gpuMode,
			Count:     count,
			Used:      count - notUsedCount[gpuMode],
			NotUsed:   notUsedCount[gpuMode],
			EightNode: freeNode.EightNode,
			FourNode:  freeNode.FourNode,
			NodeCount: nodeCount,
		})
	}
	sort.Sort(gpuInfo)
	return gpuInfo, nil
}
