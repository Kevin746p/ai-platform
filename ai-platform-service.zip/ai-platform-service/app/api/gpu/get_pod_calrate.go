package gpu

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"fmt"
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	"github.com/gogf/gf/util/gconv"
	"go.uber.org/zap"
	"time"
)

type GetPodCalRate struct {
	req request.GetPodCalRate
}

func (a GetPodCalRate) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	var info model.Task
	if err := database.Train.DB.Model(info).
		Where("pipeline_id = ?", a.req.PipelineID).
		Scan(&info); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	taskName := info.TaskName + "-" + info.BuildID
	now := time.Now()
	fiveMin, _ := time.ParseDuration("-5m")
	thirtyMin, _ := time.ParseDuration("-30m")
	var RateInFiveMin, RateInThirtyMin, RateInWhole float64
	RateInFiveMin, err := a.getData(now.Add(fiveMin).Unix(), 0, taskName)
	if err != nil {
		g.Log().Error("[api][gpu] get gpu five min cal failed:", zap.String("uuid", a.req.Common.ReqUuid), zap.Error(err), taskName)
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuAvgUsageFailed,
			fmt.Sprintf(enum.ErrDescGetGpuAvgUsageFailed, err.Error()),
		)
	}
	RateInThirtyMin, err = a.getData(now.Add(thirtyMin).Unix(), 0, taskName)
	if err != nil {
		g.Log().Error("[api][gpu] get gpu five min cal failed:", zap.String("uuid", a.req.Common.ReqUuid), zap.Error(err), taskName)
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuAvgUsageFailed,
			fmt.Sprintf(enum.ErrDescGetGpuAvgUsageFailed, err.Error()),
		)
	}
	RateInWhole, err = a.getData(info.CreateTime.Unix(), int64(time.Hour.Seconds()), taskName)
	if err != nil {
		g.Log().Error("[api][gpu] get gpu whole cal failed:", zap.String("uuid", a.req.Common.ReqUuid), zap.Error(err), taskName)
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuAvgUsageFailed,
			fmt.Sprintf(enum.ErrDescGetGpuAvgUsageFailed, err.Error()),
		)
	}
	result := response.GpuPodCalRate{
		PipelineID:      info.PipelineID,
		RateInFiveMin:   RateInFiveMin,
		RateInThirtyMin: RateInThirtyMin,
		RateInWhole:     RateInWhole,
	}
	return response.Success(a.req.Common.ReqUuid, result)
}

func (a *GetPodCalRate) getData(start, step int64, podName string) (rate float64, err error) {
	GpuUsage, err := utils.GetPodCardGpuUsage(start, 0, step, podName)
	if err != nil {
		return
	}
	if len(GpuUsage) == 0 {
		rate = 0
	} else {
		for _, eachGpuCal := range GpuUsage {
			rate += gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(eachGpuCal.Rate)))

		}
		rate = rate / float64(len(GpuUsage))
	}
	return
}
