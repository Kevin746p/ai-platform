package gpu

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"fmt"
	"sort"
	"time"

	"github.com/gogf/gf/util/gconv"

	"github.com/gogf/gf/net/ghttp"

	"github.com/gogf/gf/frame/g"
	"go.uber.org/zap"
)

type GetGpuAvgUsage struct {
	req request.GetGpuAvgUsage
}

func (a GetGpuAvgUsage) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()), err.Error()),
		)
	}
	if a.req.Start == nil && a.req.End == nil {
		timeStamp := time.Now().Unix()
		a.req.Start = &timeStamp
		a.req.End = &timeStamp
	}
	if *a.req.Start > *a.req.End {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(fmt.Sprintf(enum.ErrDescInvalidParameter, "start can not larger than end")))
	}
	resp, err := a.getData()
	if err != nil {
		g.Log().Error("[api][gpu] usage get avg usage failed:", zap.String("uuid", a.req.Common.ReqUuid), zap.Error(err))
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuAvgUsageFailed,
			fmt.Sprintf(enum.ErrDescGetGpuAvgUsageFailed, err.Error()),
		)
	}

	return response.Success(a.req.Common.ReqUuid, resp)
}

func (a *GetGpuAvgUsage) getData() (gpuAvgUsage response.GpuAvgUsageList, err error) {
	var step int64
	if a.req.Step == "1h" {
		step = int64(time.Hour.Seconds())
	}
	if a.req.Step == "1d" {
		step = int64(time.Hour.Seconds()) * 24
	}
	monitorData, err := utils.GetGpuUsage(*a.req.Start, *a.req.End, step, a.req.NodeName)
	if err != nil {
		g.Log().Error("[api][gpu] usage get avg usage from external url failed", zap.String("uuid", a.req.Common.ReqUuid), err.Error())
		return
	}
	g.Log().Info("[api][gpu] usage get avg usage from external url", monitorData, zap.String("uuid", a.req.Common.ReqUuid))
	timestamps := utils.GetStepTimeStamp(*a.req.Start, *a.req.End, utils.TransferTimeStepIntoSecond(a.req.Step))
	for _, eachGpuInfo := range monitorData {
		nodeUsage := response.GpuAvgUsage{
			HostName: eachGpuInfo.HostName,
			GpuMode:  eachGpuInfo.GpuMode,
			Instance: eachGpuInfo.Instance,
		}
		timestampExits := make(map[int64]bool)
		for _, timeData := range eachGpuInfo.RateWithTimeList {

			nodeUsage.AvgUsageWithTime = append(nodeUsage.AvgUsageWithTime, response.AvgUsageWithTime{
				Time:     gconv.Int64(timeData.Timestamp),
				AvgUsage: gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(timeData.Value))),
			})
			timestampExits[gconv.Int64(timeData.Timestamp)] = true

		}
		// 补足数据
		for _, timestamp := range timestamps {
			if !timestampExits[timestamp] {
				nodeUsage.AvgUsageWithTime = append(nodeUsage.AvgUsageWithTime, response.AvgUsageWithTime{
					Time:     timestamp,
					AvgUsage: 0,
				})

			}
		}
		sort.Sort(nodeUsage.AvgUsageWithTime)
		if len(nodeUsage.AvgUsageWithTime) > 0 {
			nodeUsage.AvgUsage = nodeUsage.AvgUsageWithTime[len(nodeUsage.AvgUsageWithTime)-1].AvgUsage
		}
		gpuAvgUsage = append(gpuAvgUsage, nodeUsage)
	}
	sort.Sort(gpuAvgUsage)
	return
}
