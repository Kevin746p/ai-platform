package gpu

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"fmt"
	"github.com/gogf/gf/database/gdb"
	"github.com/gogf/gf/net/ghttp"
	"github.com/gogf/gf/util/gconv"
	"time"
)

type GetMonitorTopN struct {
	req request.GetMonitorTopN
}

func (a GetMonitorTopN) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()))
	}
	type MonitorJoinTask struct {
		PipelineID    string    `orm:"pipeline_id" json:"PipelineID"`
		Scene         string    `orm:"mt.scene" json:"Scene"`
		ResourceType  string    `orm:"mt.resource_type" json:"ResourceType"`
		GpuCalRate    float64   `orm:"gpu_cal_rate" json:"GpuCalRate"`
		MemoryUse     float64   `orm:"memory_use" json:"MemoryUse"`
		GpuOccupyTime float64   `orm:"gpu_occupy_time" json:"GpuOccupyTime"`
		GpuMode       string    `orm:"gpu_mode" json:"GpuMode"`
		IsFinish      int       `orm:"is_finish" json:"IsFinish"`
		CreateDate    time.Time `orm:"create_date" json:"CreateDate"`
		Creator       string    `orm:"creator" json:"Creator"`
		TaskName      string    `orm:"task_name" json:"TaskName"`
		BuildID       string    `orm:"build_id" json:"BuildID"`
	}
	var tasks []MonitorJoinTask
	result := response.GpuMonitorTopList{}
	query := database.Train.DB.Model(model.TaskMonitor{}, "mt").LeftJoin(model.Task{}.TableName(), "st", "mt.pipeline_id=st.pipeline_id").Fields("mt.*,st.task_name,st.build_id,st.creator")
	query, err := a.getQuery(query)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			err.Error())
	}
	if err := query.Scan(&tasks); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	for _, item := range tasks {
		result = append(result, response.GpuMonitorTop{
			PipelineID:   item.PipelineID,
			TaskName:     item.TaskName + "-" + item.BuildID,
			ResourceType: item.ResourceType,
			Scene:        item.Scene,
			Creator:      item.Creator,
			GpuCalRate:   item.GpuCalRate,
			OccupyGpu:    gconv.Float64(fmt.Sprintf("%.2f", item.GpuOccupyTime/60)),
			GpuMode:      item.GpuMode,
		})
	}
	return response.Success(a.req.Common.ReqUuid, result)
}

func (a *GetMonitorTopN) getQuery(query *gdb.Model) (*gdb.Model, error) {
	query = query.Where("gpu_occupy_time > 0")
	if a.req.IsRange {
		if a.req.Start == "" || a.req.End == "" {
			return query, fmt.Errorf("Start or End can not be none")
		}
		query = query.Where("create_date between ? and  ?", a.req.Start, a.req.End)
	} else {
		if a.req.TargetDate == "" {
			return query, fmt.Errorf("TargetDate can not be none")
		}
		query = query.Where("create_date = ?", a.req.TargetDate)
	}
	if a.req.IsDesc {
		query = query.Order(fmt.Sprintf(a.req.Target), "desc", ",", "gpu_occupy_time desc")
	} else {
		query = query.Order(fmt.Sprintf(a.req.Target), ",", "gpu_occupy_time desc")
	}
	query = query.Limit(a.req.Limit)
	return query, nil
}
