package gpu

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"fmt"
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	"go.uber.org/zap"
	"sort"
	"time"
)

type GetGpuIndicators struct {
	req request.GetGpuIndicators
}

func (a GetGpuIndicators) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	if a.req.Start > a.req.End {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, enum.ErrorDesc1),
		)
	}
	if a.req.Start == 0 || a.req.End == 0 {
		a.req.Start = time.Now().Unix()
		a.req.End = a.req.Start
	}
	result, err := a.getData()
	if err != nil {
		g.Log().Error("[api][gpu] get gpu indicators failed:", zap.String("uuid", a.req.Common.ReqUuid), zap.Error(err))
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuAvgUsageFailed,
			fmt.Sprintf(enum.ErrDescGetGpuAvgUsageFailed, err.Error()),
		)
	}
	return response.Success(a.req.Common.ReqUuid, result)
}

func (a *GetGpuIndicators) getData() (*response.GpuClusterAvgUsage, error) {
	// 获取GPU卡数
	var data = new(response.GpuClusterAvgUsage)
	GpuClusterUsage, err := utils.GetGpuClusterUsage(a.req.Start, a.req.End, a.req.Step)
	if err != nil {
		g.Log().Error("[api][gpu] indicators GetGpuIndicators failed", a.req.Common.ReqUuid, err.Error())
		return nil, err
	}
	g.Log().Info("[api][gpu] info indicators GetGpuIndicators", a.req.Common.ReqUuid, GpuClusterUsage)
	clusterPower, err := utils.GetGpuClusterPower()
	if err != nil {
		g.Log().Error("[api][gpu] indicators GetGpuClusterPower failed", a.req.Common.ReqUuid, err.Error())
		return nil, err
	}
	g.Log().Info("[api][gpu] info indicators GetGpuClusterPower", a.req.Common.ReqUuid, clusterPower)
	clusterMemory, err := utils.GetGpuClusterMemory(a.req.Start, a.req.End, a.req.Step)
	if err != nil {
		g.Log().Error("[api][gpu] indicators GetGpuClusterMemory failed", a.req.Common.ReqUuid, err.Error())
		return nil, err
	}
	g.Log().Info("[api][gpu] info indicators GetGpuClusterMemory", a.req.Common.ReqUuid, clusterMemory)
	sort.Sort(GpuClusterUsage)
	sort.Sort(clusterMemory)
	data.GPUClusterPowerRate = GpuClusterUsage
	data.GPUCalPower = clusterPower.PowerTotal
	data.GPUClusterMemoryRate = clusterMemory
	return data, nil
}
