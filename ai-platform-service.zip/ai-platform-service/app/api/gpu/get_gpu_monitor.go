package gpu

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/config"
	"fmt"
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	"go.uber.org/zap"
	"time"
)

type GetPodMonitorRate struct {
	req request.GetPodMonitorRate
}

func (a GetPodMonitorRate) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	if a.req.Start > a.req.End {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, enum.ErrorDesc1),
		)
	}
	if a.req.Start == 0 || a.req.End == 0 {
		a.req.Start = time.Now().Unix()
		a.req.End = a.req.Start
	}
	var info model.Task
	if err := database.Train.DB.Model(info).
		Where("pipeline_id = ?", a.req.PipelineID).
		Scan(&info); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	result, err := a.getData(info.TaskName + "-" + info.BuildID)
	if err != nil {
		g.Log().Error("[api][gpu] get gpu monitor failed:", zap.String("uuid", a.req.Common.ReqUuid), zap.Error(err))
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuAvgUsageFailed,
			fmt.Sprintf(enum.ErrDescGetGpuAvgUsageFailed, err.Error()),
		)
	}
	return response.Success(a.req.Common.ReqUuid, result)
}

func (a *GetPodMonitorRate) getData(podName string) (response.PodRangeAvgUsage, error) {
	var query string
	switch a.req.MonitorType {
	case enum.MonitorGPUCalPower:
		query = fmt.Sprintf(config.Cfg.ExternalUrl.GpuPodCardAvgUsageUrl, podName)
	case enum.MonitorCPU:
		query = fmt.Sprintf(config.Cfg.ExternalUrl.CpuPodCardUsageUrl, podName)
	case enum.MonitorGPUMemory:
		query = fmt.Sprintf(config.Cfg.ExternalUrl.GpuPodMemoryUsage, podName, podName, podName)
	case enum.MonitorMemory:
		query = fmt.Sprintf(config.Cfg.ExternalUrl.MemoryPodUsageUrl, podName)
	default:
		g.Log().Error("[api][pod] monitor GetPodMonitorRate failed", a.req.Common.ReqUuid)
		return nil, fmt.Errorf("invalid data type")
	}

	data, err := utils.GetPodRangeAvgUsage(a.req.Start, a.req.End, a.req.Step, query)
	if err != nil {
		g.Log().Error("[api][pod] monitor GetPodMonitorRate failed", a.req.Common.ReqUuid, err.Error())
		return nil, err
	}
	return data, nil
}
