package gpu

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"fmt"

	"github.com/gogf/gf/util/gconv"

	"github.com/gogf/gf/net/ghttp"

	"github.com/gogf/gf/frame/g"
	"go.uber.org/zap"
)

type GetGpuPods struct {
	req request.GetGpuPods
}

func (a GetGpuPods) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	resp, err := a.getData()
	if err != nil {
		g.Log().Error("get pods failed:", zap.String("uuid", a.req.Common.ReqUuid), zap.Error(err))
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeGetGpuPodsFailed,
			fmt.Sprintf(enum.ErrDescGetGpuPodsFailed, err.Error()),
		)
	}
	return response.Success(a.req.Common.ReqUuid, resp)
}

func (a *GetGpuPods) getData() (gpuPods []response.GpuPods, err error) {
	var result []response.GpuPods
	usageMap := make(map[string]response.GpuAvgUsage) // 节点平均使用率
	hostUsage := make(map[string]int64)               // 节点使用卡数
	respUsage, err := utils.GetLatestGpuUsage("")
	if err != nil {
		g.Log().Error("[api][task] pods receive gpu avg usage from external url failed", a.req.Common.ReqUuid, respUsage, err.Error())
		return
	}

	g.Log().Info("[api][task] pods receive gpu avg usage from external url", a.req.Common.ReqUuid, respUsage)
	for _, eachGpuInfo := range respUsage {
		usageMap[eachGpuInfo.HostName] = response.GpuAvgUsage{
			HostName: eachGpuInfo.HostName,
			GpuMode:  eachGpuInfo.GpuMode,
			AvgUsage: gconv.Float64(fmt.Sprintf("%.2f", eachGpuInfo.Rate)),
		}

	}
	respPods, err := utils.GetGpuPodUsage()
	if err != nil {
		g.Log().Error("[api][task] pods receive gpu pod usage from external url failed", a.req.Common.ReqUuid, respUsage, err.Error())
		return
	}

	g.Log().Info("[api][task] pods receive gpu pod usage from external url", a.req.Common.ReqUuid, respPods)
	for _, eachGpuInfo := range respPods {
		result = append(result, response.GpuPods{
			Pod:      eachGpuInfo.Pod,
			PodUsage: gconv.Int64(eachGpuInfo.PodUsage),
			HostName: eachGpuInfo.HostName,
		})
		hostUsage[eachGpuInfo.HostName] += gconv.Int64(eachGpuInfo.PodUsage)

	}
	for idx, val := range result {
		if _hostUsage, ok := hostUsage[val.HostName]; ok {
			result[idx].HostUsage = _hostUsage
		}
		if _hostAvgUsage, ok := usageMap[val.HostName]; ok {
			result[idx].AvgUsage = _hostAvgUsage.AvgUsage
			result[idx].GpuMode = _hostAvgUsage.GpuMode
		}
	}
	return result, nil
}
