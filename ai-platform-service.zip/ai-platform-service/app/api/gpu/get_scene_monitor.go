package gpu

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"fmt"
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	"github.com/gogf/gf/util/gconv"
	"sort"
	"strings"
)

type GetSceneMonitor struct {
	req request.GetSceneMonitor
}

func (a GetSceneMonitor) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()))
	}
	var taskList []model.Task
	query := database.Train.DB.Model(model.Task{}).Where("(scene is not null and scene != ?) and (task_name like ? or task_name like ?)  and status = ?",
		"", fmt.Sprint(enum.TaskPrefix, "%"), fmt.Sprint(enum.NotebookPrefix, "%"), enum.TaskRunning)
	query = query.Order("scene")
	err := query.Scan(&taskList)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	type sceneItem struct {
		countA100, countRtx3090, count     int
		scene, resourceType, taskQueryName string
	}
	sceneMap := make(map[string]*sceneItem)
	for _, task := range taskList {
		taskName := task.TaskName + "-" + task.BuildID
		resourceType := ""
		if strings.HasPrefix(taskName, enum.NotebookPrefix) {
			resourceType = enum.NotebookBusinessType
		} else if strings.HasPrefix(taskName, enum.TaskPrefix) {
			resourceType = enum.TaskBusinessType
		}

		if _, ok := sceneMap[task.Scene+resourceType]; !ok {
			sceneMap[task.Scene+resourceType] = &sceneItem{scene: task.Scene, count: 1,
				resourceType: resourceType, taskQueryName: taskName + ".*"}
			if task.NodeType == enum.ResourceTypeRTX3090 {
				sceneMap[task.Scene+resourceType].countRtx3090 = task.GpuLimit
			} else if task.NodeType == enum.ResourceTypeA100 {
				sceneMap[task.Scene+resourceType].countA100 = task.GpuLimit
			}
		} else {
			sceneMap[task.Scene+resourceType].taskQueryName = sceneMap[task.Scene+resourceType].taskQueryName + "|" + taskName + ".*"
			sceneMap[task.Scene+resourceType].count += 1
			if task.NodeType == enum.ResourceTypeRTX3090 {
				sceneMap[task.Scene+resourceType].countRtx3090 += task.GpuLimit

			} else if task.NodeType == enum.ResourceTypeA100 {
				sceneMap[task.Scene+resourceType].countA100 += task.GpuLimit
			}
		}
	}
	result := response.GpuSceneMonitorList{}
	for _, item := range sceneMap {
		g.Log().Info("[api][gpu] GetSceneMonitor filter task names", item.taskQueryName)
		podGpuUsage, err := utils.GetPodCardGpuUsage(0, 0, 0, item.taskQueryName)
		if err != nil {
			g.Log().Error("[api][GetSceneMonitor] GetPodCardGpuUsage failed", item.taskQueryName, err.Error())
			result = append(result, response.GpuSceneMonitor{
				Scene:        item.scene,
				CountA100:    item.countA100,
				CountRtx3090: item.countRtx3090,
				ResourceType: item.resourceType,
				GpuCalRate:   0,
			})
			continue
		}
		if len(podGpuUsage) == 0 {
			result = append(result, response.GpuSceneMonitor{
				Scene:        item.scene,
				CountA100:    item.countA100,
				CountRtx3090: item.countRtx3090,
				ResourceType: item.resourceType,
				GpuCalRate:   0,
			})
			continue
		}
		var gpuUsage float64
		for _, eachGpuMemoryInfo := range podGpuUsage {
			gpuUsage += gconv.Float64(fmt.Sprintf("%.2f", gconv.Float64(eachGpuMemoryInfo.Rate)))
		}
		result = append(result, response.GpuSceneMonitor{
			Scene:        item.scene,
			CountA100:    item.countA100,
			CountRtx3090: item.countRtx3090,
			ResourceType: item.resourceType,
			GpuCalRate:   gpuUsage / gconv.Float64(len(podGpuUsage)),
		})
	}
	sort.Sort(result)
	return response.Success(a.req.Common.ReqUuid, result)
}
