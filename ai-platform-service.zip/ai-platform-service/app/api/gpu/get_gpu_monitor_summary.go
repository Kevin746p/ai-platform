package gpu

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"encoding/json"
	"fmt"
	"github.com/gogf/gf/database/gdb"
	"github.com/gogf/gf/net/ghttp"
	"github.com/gogf/gf/util/gconv"
	"sort"
)

type GetMonitorSummary struct {
	req request.GetMonitorSummary
}

func (a GetMonitorSummary) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()))
	}
	var tasks []model.TaskMonitor
	type sceneItem struct {
		occupyA100, occupyRtx3090         float64
		gpuCalRateA100, gpuCalRateRtx3090 float64
		countA100, countRtx3090           int
		scene, resourceType               string
	}
	sceneMap := make(map[string]*sceneItem)
	query := database.Train.DB.Model(model.TaskMonitor{})
	query, err := a.getQuery(query)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			err.Error())
	}

	if err := query.Scan(&tasks); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	for _, task := range tasks {
		if _, ok := sceneMap[task.Scene+task.ResourceType]; !ok {
			var occupyA100, occupyRtx3090, gpuCalRateA100, gpuCalRateRtx3090 float64
			var countA100, countRtx3090 int
			if task.GpuMode == enum.ResourceTypeRTX3090 {
				occupyRtx3090 = task.GpuOccupyTime
				gpuCalRateRtx3090 = task.GpuCalRate * task.GpuOccupyTime
				countRtx3090 = 1
			} else if task.GpuMode == enum.ResourceTypeA100 {
				occupyA100 = task.GpuOccupyTime
				gpuCalRateA100 = task.GpuCalRate * task.GpuOccupyTime
				countA100 = 1
			}
			sceneMap[task.Scene+task.ResourceType] = &sceneItem{
				occupyA100:        occupyA100,
				occupyRtx3090:     occupyRtx3090,
				gpuCalRateA100:    gpuCalRateA100,
				gpuCalRateRtx3090: gpuCalRateRtx3090,
				countA100:         countA100,
				countRtx3090:      countRtx3090,
				scene:             task.Scene,
				resourceType:      task.ResourceType,
			}
		} else {
			if task.GpuMode == enum.ResourceTypeRTX3090 {
				sceneMap[task.Scene+task.ResourceType].gpuCalRateRtx3090 += task.GpuCalRate * task.GpuOccupyTime
				sceneMap[task.Scene+task.ResourceType].occupyRtx3090 += task.GpuOccupyTime
				sceneMap[task.Scene+task.ResourceType].countRtx3090 += 1
			} else if task.GpuMode == enum.ResourceTypeA100 {
				sceneMap[task.Scene+task.ResourceType].gpuCalRateA100 += task.GpuCalRate * task.GpuOccupyTime
				sceneMap[task.Scene+task.ResourceType].occupyA100 += task.GpuOccupyTime
				sceneMap[task.Scene+task.ResourceType].countA100 += 1

			}
		}
	}
	result := response.GpuSceneList{}
	for _, item := range sceneMap {
		var gpuCalRateA100, gpuCalRateRtx3090 float64
		if item.occupyA100 == 0 {
			gpuCalRateA100 = 0
		} else {
			gpuCalRateA100 = item.gpuCalRateA100 / item.occupyA100
		}
		if item.occupyRtx3090 == 0 {
			gpuCalRateRtx3090 = 0
		} else {
			gpuCalRateRtx3090 = item.gpuCalRateRtx3090 / item.occupyRtx3090
		}
		result = append(result, response.GpuScene{
			Scene:             item.scene,
			ResourceType:      item.resourceType,
			GpuCalRateA100:    gpuCalRateA100,
			GpuCalRateRtx3090: gpuCalRateRtx3090,
			OccupyA100:        gconv.Float64(fmt.Sprintf("%.2f", item.occupyA100/60)),
			OccupyRtx3090:     gconv.Float64(fmt.Sprintf("%.2f", item.occupyRtx3090/60)),
		})

	}
	sort.Sort(result)
	return response.Success(a.req.Common.ReqUuid, sortByFiled(&result, &a.req))
}

func (a *GetMonitorSummary) getQuery(query *gdb.Model) (*gdb.Model, error) {
	if a.req.IsRange {
		if a.req.Start == "" || a.req.End == "" {
			return query, fmt.Errorf("Start or End can not be none")
		}
		query = query.Where("create_date between ? and  ?", a.req.Start, a.req.End)

	} else {
		if a.req.TargetDate == "" {
			return query, fmt.Errorf("TargetDate can not be none")
		}
		query = query.Where("create_date = ?", a.req.TargetDate)
	}
	query = query.Where("scene != ? and scene is not null", "")

	if len(a.req.Scene) != 0 {
		query = query.Where("scene IN(?)", a.req.Scene)
	}

	if a.req.ResourceType != "" {
		query = query.Where("resource_type = ?", a.req.ResourceType)
	}

	return query, nil
}

func sortByFiled(result *response.GpuSceneList, req *request.GetMonitorSummary) []map[string]interface{} {
	var resultListMap []map[string]interface{}
	for _, item := range *result {
		var itemMap map[string]interface{}
		str, _ := json.Marshal(item)
		err := json.Unmarshal(str, &itemMap)
		if err != nil {
			fmt.Printf("return %s", err)
			return nil
		}
		resultListMap = append(resultListMap, itemMap)
	}
	sortType := true
	filed := req.Desc
	if filed == "" {
		filed = req.Asc
		sortType = false
	}

	if filed == "" {
		return resultListMap
	}

	if sortType {
		sort.Slice(resultListMap, func(i, j int) bool {
			Iv, Iok := resultListMap[i][filed].(float64)
			Jv, Jok := resultListMap[j][filed].(float64)
			if Iok && Jok {
				return Iv > Jv
			}
			return true
		})
	} else {
		sort.Slice(resultListMap, func(i, j int) bool {
			Iv, Iok := resultListMap[i][filed].(float64)
			Jv, Jok := resultListMap[j][filed].(float64)
			if Iok && Jok {
				return Iv < Jv
			}
			return true
		})
	}
	return resultListMap
}
