package node

import (
	"ai-platform-service/app/cache"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/gogf/gf/net/ghttp"
	"strings"
)

type GetAbnormalNodes struct {
	req request.GetAbnormalNodes
}

func (a *GetAbnormalNodes) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()))
	}
	var result []map[string]interface{}
	for _, nodes := range cache.AbnormalNodeList {
		result = append(result, jsonToMap(nodes))
	}
	result = filter(result, "NodeName", a.req.NodeName)
	result = filter(result, "NodeIP", a.req.NodeIP)
	result = filter(result, "AbnormalReason", a.req.AbnormalReason)
	result = filter(result, "NodeType", a.req.NodeType)
	return response.Success(a.req.Common.ReqUuid, result)
}

func filter(list []map[string]interface{}, filed string, filedValue string) []map[string]interface{} {
	var result []map[string]interface{}
	if filedValue == "" {
		return list
	}
	for _, item := range list {
		if v, ok := item[filed].(string); ok && strings.Contains(v, filedValue) {
			result = append(result, item)
		}
	}
	return result
}

func jsonToMap(content interface{}) map[string]interface{} {
	var name map[string]interface{}
	if marshalContent, err := json.Marshal(content); err != nil {
		fmt.Println(err)
	} else {
		d := json.NewDecoder(bytes.NewReader(marshalContent)) // 接受一个流进行解析
		d.UseNumber()                                         // 设置将float64转为一个number
		if err := d.Decode(&name); err != nil {               // json -> map
			fmt.Println(err)
		}
	}
	return name
}
