package node

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/config"
	"fmt"
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
)

type GetResourcesTopN struct {
	req request.GetResourcesTopN
}

func (a GetResourcesTopN) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	data, err := a.getData()
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	var result []response.GetResourceNodes
	switch a.req.Target {

	case enum.Cpu:
		for _, item := range data {
			gpuQuery := fmt.Sprintf(config.Cfg.ExternalUrl.NodeGpuUsageByNode, item.NodeName)
			memoryQuery := fmt.Sprintf(config.Cfg.ExternalUrl.NodeMemoryUsageByNode, item.NodeName)
			gpuRate, err := utils.GetNodeUseAgeByQuery(gpuQuery)
			if err != nil {
				g.Log().Error("[api][node] GetResourcesTopN  get node gpu rate failed", a.req.Common.ReqUuid, item.NodeName, err.Error())

			}
			memoryRate, err := utils.GetNodeUseAgeByQuery(memoryQuery)
			if err != nil {
				g.Log().Error("[api][node] GetResourcesTopN  get node memory rate failed", a.req.Common.ReqUuid, item.NodeName, err.Error())

			}
			result = append(result, response.GetResourceNodes{
				NodeName:   item.NodeName,
				NodeIP:     item.NodeIP,
				CpuRate:    item.Rate,
				GpuRate:    gpuRate,
				MemoryRate: memoryRate,
			})
		}
	case enum.Gpu:
		for _, item := range data {
			cpuQuery := fmt.Sprintf(config.Cfg.ExternalUrl.NodeCpuUsageByNode, item.NodeName)
			memoryQuery := fmt.Sprintf(config.Cfg.ExternalUrl.NodeMemoryUsageByNode, item.NodeName)
			cpuRate, err := utils.GetNodeUseAgeByQuery(cpuQuery)
			if err != nil {
				g.Log().Error("[api][node] GetResourcesTopN  get node cpu rate failed", a.req.Common.ReqUuid, item.NodeName, err.Error())

			}
			memoryRate, err := utils.GetNodeUseAgeByQuery(memoryQuery)
			if err != nil {
				g.Log().Error("[api][node] GetResourcesTopN  get node memory rate failed", a.req.Common.ReqUuid, item.NodeName, err.Error())

			}
			result = append(result, response.GetResourceNodes{
				NodeName:   item.NodeName,
				NodeIP:     item.NodeIP,
				CpuRate:    cpuRate,
				GpuRate:    item.Rate,
				MemoryRate: memoryRate,
			})
		}
	case enum.Memory:
		for _, item := range data {
			cpuQuery := fmt.Sprintf(config.Cfg.ExternalUrl.NodeCpuUsageByNode, item.NodeName)
			gpuQuery := fmt.Sprintf(config.Cfg.ExternalUrl.NodeGpuUsageByNode, item.NodeName)
			gpuRate, err := utils.GetNodeUseAgeByQuery(gpuQuery)
			if err != nil {
				g.Log().Error("[api][node] GetResourcesTopN  get node gpu rate failed", a.req.Common.ReqUuid, item.NodeName, err.Error())
			}
			cpuRate, err := utils.GetNodeUseAgeByQuery(cpuQuery)
			if err != nil {
				g.Log().Error("[api][node] GetResourcesTopN  get node cpu rate failed", a.req.Common.ReqUuid, item.NodeName, err.Error())

			}
			result = append(result, response.GetResourceNodes{
				NodeName:   item.NodeName,
				NodeIP:     item.NodeIP,
				CpuRate:    cpuRate,
				GpuRate:    gpuRate,
				MemoryRate: item.Rate,
			})
		}

	}
	return response.Success(a.req.Common.ReqUuid, result)
}

func (a GetResourcesTopN) getData() (result utils.NodeList, err error) {
	var isDesc string
	if a.req.IsDesc {
		isDesc = "topk"
	} else {
		isDesc = "bottomk"
	}

	result, err = utils.GetNodeMonitorData(isDesc, a.req.Target, a.req.Limit)
	return
}
