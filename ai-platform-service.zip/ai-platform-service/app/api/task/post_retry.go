package task

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/app/workflow"
	"ai-platform-service/config"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
)

type RetryTask struct {
	req request.RetryTask
}

func (a RetryTask) Do(r *ghttp.Request) interface{} {
	err := r.Parse(&a.req)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}

	var task model.Task
	if err := database.Train.DB.Model(model.Task{}).
		Where("pipeline_id =? and status!= ?", a.req.PipelineID, enum.TaskDeleted).
		Scan(&task); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	if task.Status != enum.TaskJobNotExists && task.Status != enum.TaskComplete && task.Status != enum.TaskRunErr && task.Status != enum.TaskFailed && task.Status != enum.TaskCanceled {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInvalidParameter, "Task status:"+enum.TaskStatusMap[task.Status]),
		)
	}
	// 清理k8s任务
	err = k8s.K8s.DeleteResourceObject(task.Namespace, task.TaskName+"-"+task.BuildID, task.ResourceType)
	if err != nil {
		g.Log().Error("[api][task] retry DeleteResourceObject failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()))
	}
	// 1. ResourceType获取类型yamlUrl
	// 2. 变量参数获取
	yamlUrl := config.Cfg.K8s.DeployYaml
	if task.GpuLimit > enum.GpuNodeCount {
		yamlUrl = config.Cfg.K8s.MultiDeployYaml
	}
	gpuWorker := (task.GpuLimit / enum.GpuNodeCount) - 1 // worker replicas
	if task.GpuLimit%enum.GpuNodeCount != 0 {
		gpuWorker++
	}
	oldParams := new(request.CreateTask)
	err = json.Unmarshal([]byte(task.TaskParam), oldParams)
	if err != nil {
		g.Log().Error("[api][task] retry get old params failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()))
	}

	param := make(map[string]string)
	if oldParams.GitUrl != "" {
		gpuDistributed := enum.GpuNodeCount
		if oldParams.IsDistributed {
			gpuDistributed = enum.DistributedGpuCount
		}
		param = map[string]string{
			"resume":           a.req.Resume,
			"project":          task.TaskName,
			"id":               task.BuildID,
			"gpu_limits":       strconv.Itoa(task.GpuLimit), // GPU
			"gpu_requests":     strconv.Itoa(task.GpuLimit), // GPU
			"gpu_machine":      strconv.Itoa(gpuWorker),     // GPU worker
			"pname_value":      oldParams.PNameValue,
			"is_preprocessing": utils.FormatBoolWithSymbol(oldParams.IsPreprocessing),
			"is_bad_case":      utils.FormatBoolWithSymbol(oldParams.IsBadCase),
			"gpu_distributed":  strconv.Itoa(gpuDistributed),
			"run_command":      oldParams.Command,
			"namespace":        task.Namespace,
			"env":              oldParams.Env,
			"dataset_path":     oldParams.DatasetPath,
			"train_path":       oldParams.TrainPath,
			"test_path":        oldParams.TestPath,
			"model_path":       oldParams.ModelPath,
			"gpu_mode":         oldParams.GpuMode,
			"git_url":          oldParams.GitUrl,
			"base_image":       oldParams.BaseImage,
			"branch":           oldParams.Branch,
			"script_path":      oldParams.ScriptPath,
			"node_name":        "", // TODO 依赖业务方在yaml中去除
		}
	} else {
		oldYamlParams := new(request.CreateTaskByYaml)
		err = json.Unmarshal([]byte(task.TaskParam), oldYamlParams)
		if err != nil {
			g.Log().Error("[api][task] retry get old yaml params failed", a.req.Common.ReqUuid, err.Error())
			return response.Error(
				a.req.Common.ReqUuid,
				enum.ErrCodeInternalServiceError,
				fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()))
		}
		for _, _param := range oldYamlParams.Params {
			param[_param.Key] = _param.Value
		}
		param["gpu_limit"] = strconv.Itoa(oldYamlParams.GpuLimit)
		param["gpu_limits"] = strconv.Itoa(oldYamlParams.GpuLimit)
		param["gpu_mode"] = oldYamlParams.GpuMode
		param["namespace"] = task.Namespace
		param["project"] = task.TaskName
		param["id"] = task.BuildID
		yamlUrl = oldYamlParams.YamlUrl
	}
	_, jobType := a.GetJobType(oldParams.GpuLimit, oldParams.IsDistributed)
	_, _, err = workflow.Wf.SubmitWorkflow(param, true, yamlUrl, jobType, a.req.Common.ReqUuid)
	if err != nil {
		g.Log().Error("[api][task] retry SubmitWorkflow failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()))
	}
	if _, err := database.Train.DB.Model(task).
		Data(g.Map{
			"status":      enum.TaskWaiting,
			"modify_time": time.Now(),
		}).
		Where("pipeline_id = ? and status = ?", task.PipelineID, task.Status).
		Update(); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	var logList []*model.Log
	logList = append(logList, &model.Log{
		UUID:         task.PipelineID,
		ReqUuid:      a.req.Common.ReqUuid,
		BusinessType: enum.TaskBusinessType,
		OperateType:  enum.PostOperateType,
		CreateBy:     a.req.Common.SamAccountName,
		CreateTime:   time.Now(),
	})
	err = model.Log{}.Insert(logList)
	if err != nil {
		g.Log().Error("[api][task] retry write log failed", a.req.Common.ReqUuid, err)
	}
	result := response.Task{
		PipelineID: task.PipelineID,
		BuildID:    task.BuildID,
		Status:     enum.TaskStatusMap[enum.TaskWaiting],
		StatusDesc: enum.TaskStatusCnMap[enum.TaskWaiting],
		TaskName:   task.TaskName,
		Creator:    task.Creator,
		Namespace:  task.Namespace,
		Scene:      task.Scene,
		CreateTime: task.CreateTime.Unix(),
		UpdateTime: task.ModifyTime.Unix(),
		StatusCode: enum.TaskWaiting,
		GpuLimit:   task.GpuLimit,
		MemLimit:   task.MemLimit,
		CpuLimit:   task.CpuLimit,
		Stage:      enum.StageStatusMap[enum.TaskWaiting],
	}
	return response.Success(a.req.Common.ReqUuid, result)
}

func (t RetryTask) GetJobType(gpuLimit int, IsDistributed bool) (yamlUrl string, JobType string) {
	yamlUrl = config.Cfg.K8s.DeployYaml
	JobType = config.Cfg.K8s.JobKind

	if gpuLimit > enum.GpuNodeCount || IsDistributed {
		yamlUrl = config.Cfg.K8s.MultiDeployYaml
		JobType = config.Cfg.K8s.PytorchJobKind
	}
	return
}
