package task

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"fmt"

	"github.com/gogf/gf/frame/g"

	"github.com/gogf/gf/net/ghttp"
)

type GetTaskPods struct {
	req request.GetTaskPods
}

func (a GetTaskPods) Do(r *ghttp.Request) interface{} {
	var pods []response.GetTaskPodsResp
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	var tasks []model.Task
	if err := database.Train.DB.Model(model.Task{}).
		Where("pipeline_id in (?) and status!= ?", a.req.PipelineID, enum.TaskDeleted).
		Scan(&tasks); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	for _, eachTask := range tasks {
		pod := response.GetTaskPodsResp{
			PipelineID: eachTask.PipelineID,
			BuildID:    eachTask.BuildID,
			Status:     enum.TaskStatusMap[eachTask.Status],
			StatusDesc: enum.TaskStatusCnMap[eachTask.Status],
		}
		switch eachTask.Status {
		case enum.TaskRunning, enum.TaskComplete, enum.TaskFailed, enum.TaskRunErr, enum.TaskPodPending:
			// 改为批量查询
			_pods, err := k8s.K8s.GetPodsByLabel(eachTask.Namespace, []string{eachTask.TaskName + "-" + eachTask.BuildID})
			if err != nil {
				g.Log().Error("[api][task] GET GetJobPodsByJobName failed :", eachTask.TaskName+"-"+eachTask.BuildID, a.req.Common.ReqUuid, err.Error())
				continue
			}
			for _, _pod := range _pods.Items {
				pod.PodName = append(pod.PodName, _pod.Name)
			}
		}
		pods = append(pods, pod)
	}
	return response.Success(a.req.Common.ReqUuid, pods)
}
