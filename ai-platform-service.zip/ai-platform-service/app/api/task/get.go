package task

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/config"
	"fmt"
	"time"

	"github.com/gogf/gf/database/gdb"
	"github.com/gogf/gf/net/ghttp"
)

type GetTask struct {
	req request.GetTask
}

func (a GetTask) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	if len(a.req.ResourceType) == 0 {
		a.req.ResourceType = []string{config.Cfg.K8s.JobKind, config.Cfg.K8s.PytorchJobKind}
	}
	var taskList []model.Task
	query := database.Train.DB.Model(model.Task{}).
		Where("status != ?", enum.TaskDeleted)
	countQuery := database.Train.DB.Model(model.Task{}).Fields("id").
		Where("status != ?", enum.TaskDeleted)
	query = a.getQuery(query)
	query = a.getOrderQuery(query)
	countQuery = a.getQuery(countQuery)
	err := query.Scan(&taskList)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	count, err := countQuery.Count()
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	var dataList []response.GetTask
	for _, item := range taskList {
		dataList = append(dataList, response.GetTask{
			PipelineID: item.PipelineID,
			BuildID:    item.BuildID,
			TaskName:   item.TaskName,
			Creator:    item.Creator,
			Namespace:  item.Namespace,
			Scene:      item.Scene,
			CreateTime: item.CreateTime.Unix(),
			UpdateTime: item.ModifyTime.Unix(),
			StatusCode: item.Status,
			Status:     enum.TaskStatusMap[item.Status],
			StatusDesc: enum.TaskStatusCnMap[item.Status],
			GpuLimit:   item.GpuLimit,
			MemLimit:   item.MemLimit,
			CpuLimit:   item.CpuLimit,
			Detail:     item.ErrDesc,
			Stage:      enum.StageStatusMap[item.Status],
		})
	}

	return response.SuccessWithCount(a.req.Common.ReqUuid, dataList, &count)
}
func (a *GetTask) getQuery(query *gdb.Model) *gdb.Model {
	if len(a.req.PipelineID) > 0 {
		query.Where("pipeline_id", a.req.PipelineID)
	}
	if len(a.req.TaskName) > 0 {
		query.Where("task_name", a.req.TaskName)
	}
	if len(a.req.Status) > 0 {
		query.Where("status", a.req.Status)
	}
	if len(a.req.Creator) > 0 {
		query.Where("creator", a.req.Creator)
	}
	if a.req.StartTime != 0 {
		startTime := time.Unix(a.req.StartTime, 0)
		query.Where("create_time >=", startTime)
	}
	if a.req.EndTime != 0 {
		endTime := time.Unix(a.req.EndTime, 0)
		query.Where("create_time <=", endTime)
	}
	if len(a.req.ResourceType) > 0 {
		query.Where("resource_type", a.req.ResourceType)
	}
	query = query.Page(a.req.Page, a.req.PageCount)
	return query
}

func (a *GetTask) getOrderQuery(query *gdb.Model) *gdb.Model {
	if a.req.IsDesc == 1 {
		query = query.OrderDesc(a.req.OrderBy)
	} else {
		query = query.Order(a.req.OrderBy)
	}
	return query
}
