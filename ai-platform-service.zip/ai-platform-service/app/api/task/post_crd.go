package task

import (
	"ai-platform-service/app/api/common"
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/app/workflow"
	"encoding/json"
	"fmt"
	"time"

	uuid "github.com/satori/go.uuid"

	"github.com/gogf/gf/util/gconv"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
)

// 自定义资源创建接口
type CreateTaskCRD struct {
	req request.CreateTaskCRD
}

func (a CreateTaskCRD) Do(r *ghttp.Request) interface{} {
	err := r.Parse(&a.req)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	if a.req.GpuMode == enum.ResourceTypeMIG && a.req.GpuLimit > 1 {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInvalidParameter, "GpuLimit"),
		)
	}
	// 获取资源Yaml配置
	resourceYaml, err := workflow.Wf.GetDeployYamlFromGit(a.req.YamlUrl)
	if err != nil {
		g.Log().Error("[api][task] crdGetDeployYamlFromGit failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()))
	}

	param := map[string]string{
		"cpu_limit": gconv.String(a.req.CpuLimit),
		"mem_limit": gconv.String(a.req.MemLimit) + "Gi",
		"gpu_limit": gconv.String(a.req.GpuLimit),
		"gpu_type":  common.TranslateResourceTypeRequestKey(a.req.GpuMode),
	}
	for _, _param := range a.req.Params {
		param[_param.Key] = _param.Value
	}
	resource, err := workflow.Wf.ParseDeployYamlToResource(resourceYaml, param, a.req.ResourceType)
	if err != nil {
		g.Log().Error("[api][task] crd ParseDeployYamlToResource failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInvalidParameter, "Yaml:"+err.Error()))
	}
	buildID := utils.RandStringBytesMaskImpr(enum.BuildIDLength)
	workflow.Wf.ReplaceResourceParams(resource, a.req.TaskName+"-"+buildID, common.TranslateNodeSelector(a.req.GpuMode, a.req.GpuLimit))
	err = workflow.Wf.SubmitWorkflowByResource(resource, a.req.Namespace, a.req.Common.ReqUuid)
	if err != nil {
		g.Log().Error("[api][task] crd SubmitWorkflowByResource failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()))
	}
	// 任务参数
	taskParam, err := json.Marshal(a.req)
	if err != nil {
		g.Log().Error("[api][task] crdMarshal taskParam failed", a.req.Common.ReqUuid, err)
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	// 存数据
	pipelineID := uuid.NewV4().String()
	timeNow := time.Now()
	if _, err := database.Train.DB.Model(model.Task{}).Save(&model.Task{
		PipelineID:   pipelineID,
		TaskName:     a.req.TaskName,
		Namespace:    a.req.Namespace,
		GpuLimit:     a.req.GpuLimit,
		CpuLimit:     a.req.CpuLimit,
		MemLimit:     a.req.MemLimit,
		NodeType:     common.TranslateNodeSelector(a.req.GpuMode, a.req.GpuLimit),
		BuildID:      buildID,
		Status:       enum.TaskWaiting,
		TaskParam:    string(taskParam),
		CreateTime:   timeNow,
		ModifyTime:   timeNow,
		ResourceType: a.req.ResourceType,
		Scene:        a.req.Scene,
		Creator:      a.req.Common.SamAccountName,
		Remark:       a.req.ResourceRecycle,
	}); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	var logList []*model.Log

	logList = append(logList, &model.Log{
		UUID:         pipelineID,
		ReqUuid:      a.req.Common.ReqUuid,
		BusinessType: enum.NotebookBusinessType,
		IsTurnOn:     enum.TurnOn,
		GpuLimit:     a.req.GpuLimit,
		OperateType:  enum.PostOperateType,
		CreateBy:     a.req.Common.SamAccountName,
		CreateTime:   timeNow,
		Remark:       enum.WebIDEStart,
	})
	err = model.Log{}.Insert(logList)
	if err != nil {
		g.Log().Error("[api][task] crd write log failed", a.req.Common.ReqUuid, err)
	}

	result := response.Task{
		PipelineID: pipelineID,
		BuildID:    buildID,
		Status:     enum.TaskStatusMap[enum.TaskWaiting],
		StatusDesc: enum.TaskStatusCnMap[enum.TaskWaiting],
		TaskName:   a.req.TaskName,
		Creator:    a.req.Common.SamAccountName,
		Namespace:  a.req.Namespace,
		Scene:      a.req.Scene,
		CreateTime: timeNow.Unix(),
		UpdateTime: timeNow.Unix(),
		StatusCode: enum.TaskWaiting,
		GpuLimit:   a.req.GpuLimit,
		MemLimit:   a.req.MemLimit,
		CpuLimit:   a.req.CpuLimit,
		Stage:      enum.StageStatusMap[enum.TaskWaiting],
	}
	return response.Success(a.req.Common.ReqUuid, result)
}
