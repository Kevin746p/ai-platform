package task

import (
	"ai-platform-service/app/api/common"
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/k8s/resource_types"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/config"
	"encoding/json"
	"fmt"
	"time"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	"github.com/gogf/gf/util/gconv"
	v1 "k8s.io/api/core/v1"
	_resource "k8s.io/apimachinery/pkg/api/resource"
)

type UpdateTask struct {
	req request.UpdateTask
}

// 修改Notebook 资源信息
func (a UpdateTask) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	var info model.Task
	if err := database.Train.DB.Model(info).
		Where("pipeline_id = ? and status != ?", a.req.PipelineID, enum.TaskDeleted).
		Scan(&info); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	gpuLimit := info.GpuLimit
	if a.req.GpuLimit != nil {
		gpuLimit = *a.req.GpuLimit
	}

	gpuMode := common.TranslateNodeSelector(info.NodeType, gpuLimit)
	if a.req.GpuMode != "" {
		gpuMode = common.TranslateNodeSelector(a.req.GpuMode, gpuLimit)
	}
	if info.ResourceType != config.Cfg.K8s.NoteBookKind {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeUpdateNoteSupport,
			enum.ErrDescUpdateNoteSupport,
		)
	}
	resource, err := k8s.K8s.TranslateResourceType(info.ResourceType)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInvalidParameter, "ResourceType"),
		)
	}
	resourceObject, err := k8s.K8s.GetResourceObject(info.Namespace, info.TaskName+"-"+info.BuildID, resource)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	// 更新资源信息
	notebook := new(resource_types.Notebook)
	errJson, err := json.Marshal(resourceObject.Object)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	err = json.Unmarshal(errJson, notebook)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	if len(notebook.Spec.Template.Spec.Containers) <= 0 {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, "notebook container len is 0"),
		)
	}
	status := enum.TaskWaiting
	if a.req.Replicas != nil { // 启停通过修改Annotations实现
		annotations := resourceObject.GetAnnotations()
		if *a.req.Replicas == 1 {
			delete(annotations, "kubeflow-resource-stopped")
		} else if *a.req.Replicas == 0 {
			status = enum.TaskComplete
			annotations["kubeflow-resource-stopped"] = time.Now().UTC().Format("2006-01-02T15:04:05Z")
		}
		resourceObject.SetAnnotations(annotations)
	}
	var updateList []*model.Log
	updateMap := g.Map{"status": status, "modify_time": time.Now()}
	statusRemark := ""

	var isTurnOn int
	if status == enum.TaskWaiting && info.Status != enum.TaskRunning && info.Status != enum.TaskPodPending {
		statusRemark = enum.WebIDEStart
		isTurnOn = enum.TurnOn
	}
	if status == enum.TaskComplete && (info.Status == enum.TaskRunning || info.Status == enum.TaskPodPending) {
		statusRemark = enum.WebIDEStop
		isTurnOn = enum.TurnOff
	}
	updateList = append(updateList, a.GetLogItem(info.PipelineID, "status", gconv.String(status), gconv.String(info.Status), statusRemark, isTurnOn, info.GpuLimit))
	if a.req.GpuLimit != nil && *a.req.GpuLimit != info.GpuLimit {
		resourceName := v1.ResourceName(common.TranslateResourceTypeRequestKey(a.req.GpuMode))
		delete(notebook.Spec.Template.Spec.Containers[0].Resources.Limits, enum.ResourceTypeMIGRequestKey)
		delete(notebook.Spec.Template.Spec.Containers[0].Resources.Requests, enum.ResourceTypeMIGRequestKey)
		delete(notebook.Spec.Template.Spec.Containers[0].Resources.Limits, enum.ResourceTypeA100RequestKey)
		delete(notebook.Spec.Template.Spec.Containers[0].Resources.Requests, enum.ResourceTypeA100RequestKey)
		notebook.Spec.Template.Spec.Containers[0].Resources.Limits[resourceName] = _resource.MustParse(gconv.String(*a.req.GpuLimit))
		notebook.Spec.Template.Spec.Containers[0].Resources.Requests[resourceName] = _resource.MustParse(gconv.String(*a.req.GpuLimit))
		updateMap["gpu_limit"] = a.req.GpuLimit
		gpuRemark := ""
		if info.GpuLimit == 0 && *a.req.GpuLimit != 0 && statusRemark == "" {
			gpuRemark = enum.WebIEDBindBand
			isTurnOn = enum.TurnOn
		}
		updateList = append(updateList, a.GetLogItem(info.PipelineID, "gpu_limit", gconv.String(a.req.GpuLimit), gconv.String(info.GpuLimit), gpuRemark, isTurnOn, *a.req.GpuLimit))
	}
	if a.req.CpuLimit != nil && *a.req.CpuLimit != info.CpuLimit {
		notebook.Spec.Template.Spec.Containers[0].Resources.Limits[v1.ResourceCPU] = _resource.MustParse(gconv.String(*a.req.CpuLimit))
		notebook.Spec.Template.Spec.Containers[0].Resources.Requests[v1.ResourceCPU] = _resource.MustParse(gconv.String(*a.req.CpuLimit))
		updateMap["cpu_limit"] = a.req.CpuLimit
		updateList = append(updateList, a.GetLogItem(info.PipelineID, "cpu_limit", gconv.String(a.req.CpuLimit), gconv.String(info.CpuLimit), "", 0, info.GpuLimit))

	}
	if a.req.MemLimit != nil && *a.req.MemLimit != info.MemLimit {
		notebook.Spec.Template.Spec.Containers[0].Resources.Limits[v1.ResourceMemory] = _resource.MustParse(gconv.String(*a.req.MemLimit) + "Gi")
		notebook.Spec.Template.Spec.Containers[0].Resources.Requests[v1.ResourceMemory] = _resource.MustParse(gconv.String(*a.req.MemLimit) + "Gi")
		updateMap["mem_limit"] = a.req.MemLimit
		updateList = append(updateList, a.GetLogItem(info.PipelineID, "mem_limit", gconv.String(a.req.MemLimit), gconv.String(info.MemLimit), "", 0, info.GpuLimit))

	}
	if a.req.ResourceRecycle != "" && a.req.ResourceRecycle != info.Remark {
		updateList = append(updateList, a.GetLogItem(info.PipelineID, "remark", gconv.String(a.req.ResourceRecycle), gconv.String(info.Remark), "", 0, info.GpuLimit))
	}

	notebook.Spec.Template.Spec.NodeSelector = map[string]string{"resource.type": gpuMode}
	if gpuMode != info.NodeType {
		updateMap["node_type"] = gpuMode
		updateList = append(updateList, a.GetLogItem(info.PipelineID, "node_type", gpuMode, gconv.String(info.NodeType), "", 0, info.GpuLimit))
	}
	resourceObject.Object["spec"] = notebook.Spec
	// 重新部署
	err = k8s.K8s.UpdateNotebookResource(info.Namespace, resourceObject)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	if _, err := database.Train.DB.Model(info).
		Update(updateMap, "pipeline_id", a.req.PipelineID); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	if len(updateList) != 0 {
		err = model.Log{}.Insert(updateList)
		if err != nil {
			g.Log().Error("[api][task] update write log failed", a.req.Common.ReqUuid, err)
		}
	}
	return response.Success(a.req.Common.ReqUuid, nil)
}

func (a UpdateTask) GetLogItem(UUID, ChangeField, CurrentValue, OldValue, Remark string, IsTurnOn, GpuLimit int) *model.Log {
	return &model.Log{
		UUID:         UUID,
		ReqUuid:      a.req.Common.ReqUuid,
		BusinessType: enum.NotebookBusinessType,
		OperateType:  enum.PutOperateType,
		IsTurnOn:     IsTurnOn,
		GpuLimit:     GpuLimit,
		ChangeField:  ChangeField,
		CurrentValue: CurrentValue,
		OldValue:     OldValue,
		CreateBy:     a.req.Common.SamAccountName,
		Remark:       Remark,
		CreateTime:   time.Now(),
	}
}
