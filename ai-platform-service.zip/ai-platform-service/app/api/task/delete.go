package task

import (
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/k8s"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/config"
	"fmt"
	"time"

	"github.com/gogf/gf/frame/g"

	"github.com/gogf/gf/net/ghttp"
)

type DeleteTask struct {
	req request.DeleteTask
}

func (a DeleteTask) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&a.req); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}
	var info model.Task
	if err := database.Train.DB.Model(info).
		Where("pipeline_id = ? and status != ?", a.req.PipelineID, enum.TaskDeleted).
		Scan(&info); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	switch info.Status {
	case enum.TaskRunning, enum.TaskPodPending, enum.TaskWaiting, enum.TaskComplete: // 清理k8s资源 + 置状态
		if err := k8s.K8s.DeleteResourceObject(info.Namespace, info.TaskName+"-"+info.BuildID, info.ResourceType); err != nil {
			return response.Error(
				a.req.Common.ReqUuid,
				enum.ErrCodeInternalServiceError,
				fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
			)
		}
		if _, err := database.Train.DB.Model(info).
			Update(g.Map{"status": enum.TaskCanceled, "modify_time": time.Now()}, "pipeline_id", a.req.PipelineID); err != nil {
			return response.Error(
				a.req.Common.ReqUuid,
				enum.ErrCodeInternalServiceError,
				fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
			)

		}
		logRemark := ""
		var isTurnOn int
		if info.ResourceType == config.Cfg.K8s.NoteBookKind {
			logRemark = enum.WebIDEStop
			isTurnOn = enum.TurnOff
		}
		var logList []*model.Log
		businessType := enum.TaskBusinessType
		if info.ResourceType == config.Cfg.K8s.NoteBookKind {
			businessType = enum.NotebookBusinessType
		}
		logList = append(logList, &model.Log{
			UUID:         info.PipelineID,
			ReqUuid:      a.req.Common.ReqUuid,
			BusinessType: businessType,
			OperateType:  enum.DelOperateType,
			CreateBy:     a.req.Common.SamAccountName,
			CreateTime:   time.Now(),
			IsTurnOn:     isTurnOn,
			GpuLimit:     info.GpuLimit,
			Remark:       logRemark,
		})
		err := model.Log{}.Insert(logList)
		if err != nil {
			g.Log().Error("[api][task] delete write log failed", a.req.Common.ReqUuid, err)
		}

	case enum.TaskCanceled:
		return response.Success(a.req.Common.ReqUuid, nil)
	default:
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeCancelNotSupport,
			fmt.Sprintf(enum.ErrDescCancelNotSupport, enum.TaskStatusMap[info.Status]),
		)
	}
	return response.Success(a.req.Common.ReqUuid, nil)
}
