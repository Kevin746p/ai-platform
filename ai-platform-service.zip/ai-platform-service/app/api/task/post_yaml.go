package task

import (
	"ai-platform-service/app/api/common"
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/app/workflow"
	"ai-platform-service/config"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	uuid "github.com/satori/go.uuid"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	v1 "k8s.io/api/batch/v1"
)

// 通过外部传入Yaml创建训练任务，当前仅支持3090和单机任务
type CreateTaskByYaml struct {
	req request.CreateTaskByYaml
}

func (a CreateTaskByYaml) Do(r *ghttp.Request) interface{} {
	err := r.Parse(&a.req)
	if err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}

	// 获取yaml
	jobYaml, _err := workflow.Wf.GetDeployYamlFromGit(a.req.YamlUrl)
	if _err != nil {
		g.Log().Error("[api][task] yaml GetDeployYamlFromGit failed", a.req.Common.ReqUuid, _err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, _err.Error()))
	}

	// 替换yaml中参数
	param := make(map[string]string)
	for _, _param := range a.req.Params {
		param[_param.Key] = _param.Value
		param["gpu_limit"] = strconv.Itoa(a.req.GpuLimit) // 默认替换gpu_limit
	}
	job, err := workflow.Wf.ParseDeployYamlToResource(jobYaml, param, config.Cfg.K8s.JobKind)
	if err != nil {
		g.Log().Error("[api][task] yaml ParseDeployYamlToResource failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInvalidParameter, "Yaml:"+err.Error()))
	}
	//强制指定Job信息
	buildID := utils.RandStringBytesMaskImpr(enum.BuildIDLength)
	job.(*v1.Job).ObjectMeta.Name = a.req.TaskName + "-" + buildID
	job.(*v1.Job).Spec.Template.Spec.NodeSelector = map[string]string{"gpu.mode": a.req.GpuMode}
	err = workflow.Wf.SubmitWorkflowByResource(job, a.req.Namespace, a.req.Common.ReqUuid)
	if err != nil {
		g.Log().Error("[api][task] yaml SubmitWorkflowByResource failed", a.req.Common.ReqUuid, err.Error())
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()))
	}
	// 任务参数
	taskParam, err := json.Marshal(a.req)
	if err != nil {
		g.Log().Error("[api][task] yaml Marshal taskParam failed", a.req.Common.ReqUuid, err)
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	// 存数据
	pipelineID := uuid.NewV4().String()
	timeNow := time.Now()
	if _, err := database.Train.DB.Model(model.Task{}).Save(&model.Task{
		PipelineID:   pipelineID,
		TaskName:     a.req.TaskName,
		Namespace:    a.req.Namespace,
		GpuLimit:     a.req.GpuLimit,
		BuildID:      buildID,
		Status:       enum.TaskWaiting,
		TaskParam:    string(taskParam),
		CreateTime:   timeNow,
		ModifyTime:   timeNow,
		ResourceType: config.Cfg.K8s.JobKind,
		Creator:      a.req.Common.SamAccountName,
		NodeType:     common.TranslateNodeSelector(a.req.GpuMode, a.req.GpuLimit),
	}); err != nil {
		return response.Error(
			a.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			fmt.Sprintf(enum.ErrDescInternalServiceError, err.Error()),
		)
	}
	var logList []*model.Log
	logList = append(logList, &model.Log{
		UUID:         pipelineID,
		ReqUuid:      a.req.Common.ReqUuid,
		BusinessType: enum.TaskBusinessType,
		OperateType:  enum.PostOperateType,
		CreateBy:     a.req.Common.SamAccountName,
		CreateTime:   timeNow,
	})
	err = model.Log{}.Insert(logList)
	if err != nil {
		g.Log().Error("[api][task] yaml write log failed", a.req.Common.ReqUuid, err)
	}
	result := response.Task{
		PipelineID: pipelineID,
		BuildID:    buildID,
		Status:     enum.TaskStatusMap[enum.TaskWaiting],
		StatusDesc: enum.TaskStatusCnMap[enum.TaskWaiting],
		TaskName:   a.req.TaskName,
		Creator:    a.req.Common.SamAccountName,
		Namespace:  a.req.Namespace,
		CreateTime: timeNow.Unix(),
		UpdateTime: timeNow.Unix(),
		StatusCode: enum.TaskWaiting,
		GpuLimit:   a.req.GpuLimit,
		Stage:      enum.StageStatusMap[enum.TaskWaiting],
	}
	return response.Success(a.req.Common.ReqUuid, result)
}
