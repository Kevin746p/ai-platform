package task

import (
	"ai-platform-service/app/api/common"
	"ai-platform-service/app/database"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/model"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"ai-platform-service/app/workflow"
	"ai-platform-service/config"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	uuid "github.com/satori/go.uuid"
)

type CreateTask struct {
	req *request.CreateTask
}

func (t CreateTask) Do(r *ghttp.Request) interface{} {
	if err := r.Parse(&t.req); err != nil {
		return response.Error(
			t.req.Common.ReqUuid,
			enum.ErrCodeParseParameterFailed,
			fmt.Sprintf(enum.ErrDescParseParameterFailed, err.Error()),
		)
	}

	if t.req.IsDistributed && t.req.GpuLimit < enum.GpuNodeCount {
		return response.Error(
			t.req.Common.ReqUuid,
			enum.ErrCodeInvalidParameter,
			fmt.Sprintf(enum.ErrDescInvalidParameter, "IsDistributed"),
		)
	}

	buildID := utils.RandStringBytesMaskImpr(enum.BuildIDLength)
	yamlUrl, jobType := t.GetJobType()
	gpuDistributed, gpuWorker := t.GetDistributedWorkerNum()
	pipelineID := uuid.NewV4().String()

	param := map[string]string{
		"project":          t.req.TaskName,
		"id":               buildID,
		"gpu_limits":       strconv.Itoa(t.req.GpuLimit), // GPU
		"gpu_requests":     strconv.Itoa(t.req.GpuLimit), // GPU
		"gpu_machine":      strconv.Itoa(gpuWorker),      // GPU worker
		"gpu_distributed":  strconv.Itoa(gpuDistributed),
		"pname_value":      t.req.PNameValue, // 任务场景
		"is_preprocessing": utils.FormatBoolWithSymbol(t.req.IsPreprocessing),
		"is_bad_case":      utils.FormatBoolWithSymbol(t.req.IsBadCase),
		"run_command":      t.req.Command,
		"namespace":        t.req.Namespace,
		"env":              t.req.Env,
		"dataset_path":     t.req.DatasetPath,
		"train_path":       t.req.TrainPath,
		"test_path":        t.req.TestPath,
		"model_path":       t.req.ModelPath,
		"gpu_mode":         common.TranslateNodeSelector(t.req.GpuMode, t.req.GpuLimit),
		"git_url":          t.req.GitUrl,
		"base_image":       t.req.BaseImage,
		"branch":           t.req.Branch,
		"script_path":      t.req.ScriptPath,
		"node_name":        "", // TODO 依赖业务方在yaml中去除
	}
	_, _, err := workflow.Wf.SubmitWorkflow(param, false, yamlUrl, jobType, t.req.Common.ReqUuid)
	if err != nil {
		g.Log().Error("[api][task] POST SubmitWorkflow error:", pipelineID, t.req.Common.ReqUuid, err)
		return response.Error(
			t.req.Common.ReqUuid,
			enum.ErrCodeWorkflowError,
			enum.ErrDescWorkflowError,
		)
	}
	g.Log().Info("[api][task] POST SubmitWorkflow succeed", pipelineID, buildID, t.req.Common.ReqUuid)
	task, err := t.SaveTasks(pipelineID, buildID, jobType)
	if err != nil {
		g.Log().Error("[api][task] POST SaveTasks error:", pipelineID, t.req.Common.ReqUuid, err)
		return response.Error(
			t.req.Common.ReqUuid,
			enum.ErrCodeInternalServiceError,
			enum.ErrDescInternalServiceError,
		)
	}
	result := response.Task{
		PipelineID: pipelineID,
		BuildID:    buildID,
		Status:     enum.TaskStatusMap[enum.TaskWaiting],
		StatusDesc: enum.TaskStatusCnMap[enum.TaskWaiting],
		TaskName:   t.req.TaskName,
		Creator:    t.req.Common.SamAccountName,
		Namespace:  t.req.Namespace,
		CreateTime: task.CreateTime.Unix(),
		UpdateTime: task.ModifyTime.Unix(),
		StatusCode: enum.TaskWaiting,
		GpuLimit:   t.req.GpuLimit,
		Stage:      enum.StageStatusMap[enum.TaskWaiting],
	}

	return response.Success(t.req.Common.ReqUuid, result)
}
func (t CreateTask) GetDistributedWorkerNum() (workerGpu int, workerNum int) {
	workerGpu = enum.GpuNodeCount
	if t.req.IsDistributed {
		workerGpu = enum.DistributedGpuCount
	}
	workerNum = (t.req.GpuLimit / workerGpu) - 1 // worker replicas
	if t.req.GpuLimit%workerGpu != 0 {
		workerNum++
	}
	return
}
func (t CreateTask) GetJobType() (yamlUrl string, JobType string) {
	yamlUrl = config.Cfg.K8s.DeployYaml
	JobType = config.Cfg.K8s.JobKind
	if t.req.GpuLimit > enum.GpuNodeCount || t.req.IsDistributed {
		yamlUrl = config.Cfg.K8s.MultiDeployYaml
		JobType = config.Cfg.K8s.PytorchJobKind
	}
	return
}

// save db
func (t CreateTask) SaveTasks(pipelineID, workflowID, jobType string) (task model.Task, err error) {

	taskParam, err := json.Marshal(t.req)
	if err != nil {
		g.Log().Error("[api][task] POST Marshal taskParam failed", t.req.Common.ReqUuid, err)
		return task, err
	}

	timeNow := time.Now()
	task = model.Task{
		PipelineID:   pipelineID,
		TaskName:     t.req.TaskName,
		Namespace:    t.req.Namespace,
		Scene:        t.req.PNameValue,
		GpuLimit:     t.req.GpuLimit,
		BuildID:      workflowID,
		Status:       enum.TaskWaiting,
		TaskParam:    string(taskParam),
		CreateTime:   timeNow,
		ModifyTime:   timeNow,
		ResourceType: jobType,
		NodeType:     common.TranslateNodeSelector(t.req.GpuMode, t.req.GpuLimit),
		Creator:      t.req.Common.SamAccountName,
	}
	if _, err := database.Train.DB.Model(model.Task{}).Save(task); err != nil {
		return task, err
	}
	return task, model.Log{}.Insert([]*model.Log{{
		UUID:         pipelineID,
		ReqUuid:      t.req.Common.ReqUuid,
		BusinessType: enum.TaskBusinessType,
		OperateType:  enum.PostOperateType,
		CreateBy:     t.req.Common.SamAccountName,
		CreateTime:   timeNow,
	}})
}
