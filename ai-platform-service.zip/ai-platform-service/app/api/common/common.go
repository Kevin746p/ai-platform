package common

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/config"
)

func TranslateResourceTypeRequestKey(ResourceType string) string {
	switch ResourceType {
	case enum.ResourceTypeMIG:
		return enum.ResourceTypeMIGRequestKey
	default:
		return enum.ResourceTypeA100RequestKey
	}
}

func TranslateNodeSelector(gpuMode string, gpuLimit int) string {
	if gpuLimit == 0 {
		return config.Cfg.K8s.NoUseGpuNodeType
	}
	return gpuMode
}
