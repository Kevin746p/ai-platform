package api

import (
	"ai-platform-service/app/api/gpu"
	"ai-platform-service/app/api/log"
	"ai-platform-service/app/api/node"
	"ai-platform-service/app/api/task"
	"ai-platform-service/app/enum"
	"ai-platform-service/app/request"
	"ai-platform-service/app/response"
	"ai-platform-service/app/utils"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
	uuid "github.com/satori/go.uuid"
)

var GroupActionMethods = map[string]Action{
	"task--POST":              &task.CreateTask{},
	"task-list-POST":          &task.GetTask{},
	"task--PUT":               &task.UpdateTask{},
	"task--DELETE":            &task.DeleteTask{},
	"task-pods-POST":          &task.GetTaskPods{},
	"task-yaml-POST":          &task.CreateTaskByYaml{}, // 创建任务by Yaml
	"task-crd-POST":           &task.CreateTaskCRD{},
	"task-retry-POST":         &task.RetryTask{},
	"gpu-info-GET":            &gpu.GetGpuInfo{},
	"gpu-usage-POST":          &gpu.GetGpuAvgUsage{},
	"gpu-pods-GET":            &gpu.GetGpuPods{},
	"gpu-indicators-GET":      &gpu.GetGpuIndicators{},
	"gpu-podMonitor-GET":      &gpu.GetPodMonitorRate{},
	"gpu-monitorSummary-POST": &gpu.GetMonitorSummary{},
	"gpu-monitorTopN-GET":     &gpu.GetMonitorTopN{},
	"gpu-sceneMonitor-GET":    &gpu.GetSceneMonitor{},
	"gpu-podCalRate-GET":      &gpu.GetPodCalRate{},
	"log--GET":                &log.OperateLog{},
	"node-abnormalNodes-GET":  &node.GetAbnormalNodes{},
	"node-resourcesTopN-GET":  &node.GetResourcesTopN{},
}

type Action interface {
	Do(r *ghttp.Request) interface{}
}

func HandlerFunc(r *ghttp.Request) {
	uid := uuid.NewV4()
	userInfo := analysisToken(r)
	r.SetParam("Common", request.Common{ReqUuid: uid.String(), UserInfo: userInfo})
	group := r.GetRouterString("group")
	actionName := r.GetRouterString("action")
	action, ok := GroupActionMethods[group+"-"+actionName+"-"+r.Method]
	if !ok {
		if err := r.Response.WriteJson(response.Error(
			uid.String(),
			enum.ErrCodeInvalidUrlOrMethod,
			fmt.Sprintf(enum.ErrDescInvalidUrlOrMethod, group+"/"+actionName, r.Method),
		)); err != nil {
			g.Log().Error(fmt.Sprintf("[api][HandlerFunc] TaskHandle WriteJson Failed %s", err.Error()))
		}
		return
	}
	g.Log().Info("[api][HandlerFunc] receive a request", r.GetHeader("access_token"), r.Method, r.URL, strings.ReplaceAll(r.GetBodyString(), "\n", ""), uid.String())
	data := action.Do(r)
	if err := r.Response.WriteJson(data); err != nil {
		g.Log().Error(fmt.Sprintf("[api][HandlerFunc] TaskHandle WriteJson Failed %s", err.Error()))
	}
	//g.Log().Info("[api][HandlerFunc] response ", data)
}

func analysisToken(r *ghttp.Request) (userInfo request.UserInfo) {
	key := "access_token"
	AccessToken := r.Header.Get(key)
	if AccessToken == "" {
		userInfo.SamAccountName = r.GetClientIp()
		return
	}
	parts := strings.Split(AccessToken, ".")
	if len(parts) != 3 {
		userInfo.SamAccountName = r.GetClientIp()
		g.Log().Error(fmt.Sprintf("[api][HandlerFunc] analysisToken token is illegal %s", AccessToken))
		return
	}
	payloadBytes, err := utils.DecodeSegment(parts[1])
	if err != nil {
		userInfo.SamAccountName = r.GetClientIp()
		g.Log().Error(fmt.Sprintf("[api][HandlerFunc] analysisToken decodeSegment Failed %s", err.Error()))
		return
	}
	err = json.Unmarshal(payloadBytes, &userInfo)
	if err != nil {
		userInfo.SamAccountName = r.GetClientIp()
		g.Log().Error(fmt.Sprintf("[api][HandlerFunc] analysisToken unmarshal Failed %s", err.Error()))
		return
	}
	return
}
