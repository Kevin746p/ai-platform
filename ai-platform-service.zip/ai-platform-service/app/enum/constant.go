package enum

const (
	TaskDeleted      = 0
	TaskWaiting      = 1
	TaskRunning      = 4
	TaskPodPending   = 6
	TaskRunErr       = 7
	TaskComplete     = 8
	TaskFailed       = 9
	TaskJobNotExists = 10
	TaskCanceled     = 11
)

var TaskStatusMap = map[int]string{
	TaskWaiting:      "wait",
	TaskPodPending:   "pending",
	TaskRunning:      "running",
	TaskRunErr:       "suspended",
	TaskComplete:     "complete",
	TaskFailed:       "failed",
	TaskJobNotExists: "error",
	TaskCanceled:     "canceled",
}

var TaskStatusCnMap = map[int]string{
	TaskWaiting:      "排队中",
	TaskPodPending:   "调度中",
	TaskRunning:      "运行中",
	TaskRunErr:       "运行异常",
	TaskComplete:     "完成",
	TaskFailed:       "任务失败",
	TaskJobNotExists: "异常错误",
	TaskCanceled:     "已取消",
}

var StageStatusMap = map[int][]int{
	TaskWaiting:      {1, 0, 0, 0},
	TaskPodPending:   {2, 2, 1, 0},
	TaskRunning:      {2, 2, 2, 1},
	TaskRunErr:       {2, 2, 2, 3},
	TaskComplete:     {2, 2, 2, 2},
	TaskFailed:       {2, 2, 2, 3},
	TaskJobNotExists: {2, 2, 2, 3},
	TaskCanceled:     {0, 0, 0, 0},
}

const (
	OrderTypeDesc = "Desc"
	OrderTypeAsc  = "Asc"
)

// log operate_type操作类型
const (
	PostOperateType = "post"
	PutOperateType  = "put"
	DelOperateType  = "delete"
)

const (
	ResourceRecycleNever = "never"
	ResourceRecycleAuto  = "auto"
)

// log business_type 业务类型
const (
	NotebookBusinessType = "notebook"
	TaskBusinessType     = "task"
)

// 单机GPU数量
const GpuNodeCount = 8

// 资源池类型
const (
	ResourceTypeMIG            = "MIG"
	ResourceTypeMIGRequestKey  = "nvidia.com/mig-1g.10gb"
	ResourceTypeRTX3090        = "RTX3090"
	ResourceTypeA100           = "A100"
	ResourceTypeA100RequestKey = "nvidia.com/gpu"
	ResourceTypeCpu            = "cpu"
)

const (
	MonitorGPUCalPower = "GPUCalPower"
	MonitorCPU         = "CPU"
	MonitorGPUMemory   = "GPUMemory"
	MonitorMemory      = "Memory"
)

// webIDE  事件类型
const (
	WebIDEStart          = "人工启动"
	WebIDEStop           = "人工停止"
	WebIEDBindBand       = "人工绑定GPU"
	WebIEDFirstDemotion  = "自动初次降级"
	WebIEDSecondDemotion = "自动二次降级"
)

// 操作人类型
const (
	OperatorType = "auto"
)

const BuildIDLength = 5
const DistributedGpuCount = 4

//任务前缀
const (
	TaskPrefix     = "automl"
	NotebookPrefix = "notebook"
)

// notebook 开关机状态
const (
	TurnOn  = 1
	TurnOff = 2
)

const (
	TaskNotebookResorceType = "Notebook"
	TaskPVCResorceType      = "PersistentVolumeClaim"
)

const (
	GpuUseAbleKey   = "nvidia.com/gpu"
	VCudaUseAbleKey = "tencent.com/vcuda-core"
)

//异常原因
const (
	LabelAbnormal     = "标签异常"
	ComponentAbnormal = "基础组件异常"
	TaintsAbnormal    = "污点异常"
	OtherAbnormal     = "其他异常"
)

// 节点查询指标
const (
	Cpu    = "CpuRate"
	Gpu    = "GpuRate"
	Memory = "MemoryRate"
)
