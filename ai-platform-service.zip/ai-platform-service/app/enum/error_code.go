package enum

const (
	ErrCodeParseParameterFailed      = 18000
	ErrDescParseParameterFailed      = "Parse parameter failed [%v] "
	ErrCodeInvalidParameter          = 18001
	ErrDescInvalidParameter          = "Invalid parameter [%v]"
	ErrCodeInternalServiceError      = 18002
	ErrDescInternalServiceError      = "Internal service [%v]"
	ErrCodeWorkflowError             = 18003
	ErrDescWorkflowError             = "Build error"
	ErrCodeLackResError              = 18004
	ErrDescLackResError              = "Insufficient resources, please try again later"
	ErrCodeInvalidUrlOrMethod        = 18005
	ErrDescInvalidUrlOrMethod        = "Invalid Action [%v] Or Method [%v]"
	ErrCodeGetGpuInfoFailed          = 18006
	ErrDescGetGpuInfoFailed          = "Get Gpu Info Failed: [%v]"
	ErrCodeCancelNotSupport          = 18007
	ErrDescCancelNotSupport          = "Task can not Cancel, Status: [%v]"
	ErrCodeGetGpuAvgUsageFailed      = 18008
	ErrDescGetGpuAvgUsageFailed      = "Get Gpu Avg Usage Failed: [%v]"
	ErrCodeGetGpuPodsFailed          = 18009
	ErrDescGetGpuPodsFailed          = "Get Gpu Pods Failed: [%v]"
	ErrCodeUpdateNoteSupport         = 18010
	ErrDescUpdateNoteSupport         = "Only Notebook Can Update"
	ErrCodeInsufficientPersonalQuota = 18011
	ErrDescInsufficientPersonalQuota = "insufficient Personal Quota [%v]"
	ErrCodeInsufficientSceneQuota    = 18012
	ErrDescInsufficientSceneQuota    = "insufficient Scene Quota [%v]"
)

// 任务错误描述
const (
	ErrDescGetPodStatusFailed = "get pod status failed"
	ErrDescJobExecFailed      = "k8s job exec failed"
	ErrDescNilJob             = "k8s job is nil"
	ErrDescJobNotExists       = "k8s job not exists"
	ErrDescUnknownPodStatus   = "k8s pod status unknown"
	ErrDescNilPodList         = "get k8s podList Err: podList is nil"
	ErrDescZeroPodListItem    = "podList item is zero"
	ErrDescObjectHasNoEvent   = "object has no event"
	ErrDescGetEventErr        = "get k8s event err"
)

// 自定义错误描述
const (
	ErrorDesc1 = "Start must less than or equal to End"
)
