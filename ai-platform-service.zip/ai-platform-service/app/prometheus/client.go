package prometheus

import (
	"ai-platform-service/config"
	"context"
	"time"

	"github.com/gogf/gf/frame/g"
	"github.com/prometheus/client_golang/api"
	v1 "github.com/prometheus/client_golang/api/prometheus/v1"
	"github.com/prometheus/common/model"
)

var PromeCli *Prometheus

type Prometheus struct {
	cfg    config.PrometheusCfg
	ctx    context.Context
	cancel context.CancelFunc
	client v1.API
}

func (p *Prometheus) Init() {
	p.cfg = config.Cfg.Prometheus
	p.ctx, p.cancel = context.WithCancel(context.Background())
	PromeCli = p
}

func (p *Prometheus) Start() error {
	client, err := api.NewClient(api.Config{
		Address: p.cfg.Address,
	})
	if err != nil {
		g.Log().Error("[prometheus][start] NewClient failed: ", err.Error())
		return err
	}
	p.client = v1.NewAPI(client)
	return nil
}

func (p *Prometheus) Stop() error {
	p.cancel()
	return nil
}

func (p *Prometheus) Name() string {
	return "Prometheus"
}

// 查询瞬时数据
func (p *Prometheus) Query(promeQL string) (error, model.Value) {
	result, warnings, err := p.client.Query(p.ctx, promeQL, time.Now(), v1.WithTimeout(time.Duration(config.Cfg.Prometheus.Timeout)*time.Second))
	if err != nil {
		g.Log().Error("[prometheus][Query] failed :", err.Error())
		return err, result
	}
	if len(warnings) > 0 {
		g.Log().Warning("[prometheus][Query] warnings :", warnings)
	}
	return nil, result
}

//查询区间向量
func (p *Prometheus) QueryRange(promeQL string, start, end time.Time, step time.Duration) (error, model.Value) {
	r := v1.Range{
		Start: start,
		End:   end,
		Step:  step,
	}
	result, warnings, err := p.client.QueryRange(p.ctx, promeQL, r, v1.WithTimeout(time.Duration(config.Cfg.Prometheus.Timeout)*time.Second))
	if err != nil {
		g.Log().Error("[prometheus][QueryRange] failed :", err.Error())
		return err, result
	}
	if len(warnings) > 0 {
		g.Log().Warning("[prometheus][QueryRange] warnings :", warnings)
	}
	return nil, result
}
