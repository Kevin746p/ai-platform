package model

import (
	"ai-platform-service/app/enum"
	"time"
)

type Task struct {
	ID           uint      `orm:"primary_key" json:"ID"` // 主键
	PipelineID   string    `orm:"pipeline_id" json:"PipelineID"`
	QueueID      int64     `orm:"queue_id" json:"QueueID"`
	BuildID      string    `orm:"build_id" json:"BuildID"`
	TaskName     string    `orm:"task_name" json:"TaskName"`
	Namespace    string    `orm:"namespace" json:"Namespace"`
	GpuLimit     int       `orm:"gpu_limit" json:"GpuLimit"`
	CpuLimit     int       `orm:"cpu_limit" json:"CpuLimit"`
	MemLimit     int       `orm:"mem_limit" json:"MemLimit"`
	NodeType     string    `orm:"node_type" json:"NodeType"` // 节点资源类型 - A100  ,RTX3090 ,MIG , Cpu
	Scene        string    `orm:"scene" json:"Scene"`
	ResourceType string    `orm:"resource_type" json:"ResourceType"` // 创建k8s资源类型 -notebook,pvc,job
	Status       int       `orm:"status" json:"Status"`
	ErrDesc      string    `orm:"err_desc" json:"ErrDesc"`
	Remark       string    `orm:"remark" json:"Remark"`
	TaskParam    string    `orm:"task_param" json:"TaskParam"`
	ModifyTime   time.Time `orm:"modify_time" json:"ModifyTime"`
	CreateTime   time.Time `orm:"create_time" json:"CreateTime"` // 入库时间
	Creator      string    `orm:"creator" json:"Creator"`
}

// TableName get sql table name.获取数据库表名
func (t Task) TableName() string {
	return "tbl_task_info2"
}

func (t *Task) IsMultiGpuTask() bool {
	if t.GpuLimit/enum.GpuNodeCount > 1 && t.GpuLimit%enum.GpuNodeCount == 0 {
		return true
	}
	return false
}

type TaskMonitor struct {
	ID            uint      `orm:"primary_key" json:"ID"`
	PipelineID    string    `orm:"pipeline_id" json:"PipelineID"`
	Scene         string    `orm:"scene" json:"Scene"`
	TaskName      string    `orm:"task_name" json:"TaskName"`
	ResourceType  string    `orm:"resource_type" json:"ResourceType"`
	CpuRate       float64   `orm:"cpu_rate" json:"CpuRate"`
	GpuMemRate    float64   `orm:"gpu_mem_rate" json:"GpuMemRate"`
	GpuCalRate    float64   `orm:"gpu_cal_rate" json:"GpuCalRate"`
	MemoryUse     float64   `orm:"memory_use" json:"MemoryUse"`
	GpuOccupyTime float64   `orm:"gpu_occupy_time" json:"GpuOccupyTime"`
	GpuMode       string    `orm:"gpu_mode" json:"GpuMode"`
	IsFinish      int       `orm:"is_finish" json:"IsFinish"`
	CreateDate    time.Time `orm:"create_date" json:"CreateDate"`
	CreateTime    time.Time `orm:"create_time" json:"CreateTime"`
}

// TableName get sql table name.获取数据库表名
func (t TaskMonitor) TableName() string {
	return "tbl_task_monitor"
}

type GpuUsageStatistics struct {
	ID             uint      `orm:"primary_key" json:"ID"`
	StatisticsData time.Time `orm:"statistics_data" json:"StatisticsData"`
	CreateTime     time.Time `orm:"create_time" json:"CreateTime"`
	GpuMode        string    `orm:"gpu_mode" json:"GpuMode"`               // GPU类型
	GpuTotal       int       `orm:"gpu_total" json:"GpuTotal"`             // GPU资源总数量
	OccupyRate     float64   `orm:"occupy_rate" json:"OccupyRate"`         // 占用率（占用卡数*占用时长(min)/总卡数*24*60）
	UsageRate      float64   `orm:"usage_rate" json:"UsageRate"`           // 占用平均使用率（任务占用卡数*平均利用率*时间/占用卡数*占用时长(min)）
	OccupyDuration float64   `orm:"occupy_duration" json:"OccupyDuration"` // 占用时长
	UsageDuration  float64   `orm:"usage_duration" json:"UsageDuration"`   // 真实利用时长 （sum(占用时长 * 平均利用率)）
}

func (t GpuUsageStatistics) TableName() string {
	return "tbl_gpu_usage_statistic"
}
