package model

import (
	"ai-platform-service/app/database"
	"time"
)

type Log struct {
	ID           uint      `orm:"primary_key" json:"ID"` // 主键
	UUID         string    `orm:"uuid" json:"UUID"`
	ReqUuid      string    `orm:"req_uuid" json:"ReqUuid"`
	BusinessType string    `orm:"business_type" json:"BusinessType"`
	OperateType  string    `orm:"operate_type" json:"OperateType"`
	IsTurnOn     int       `orm:"is_turn_on" json:"IsTurnOn"`
	GpuLimit     int       `orm:"gpu_limit" json:"GpuLimit"`
	ChangeField  string    `orm:"change_field" json:"ChangeField"`
	CurrentValue string    `orm:"current_value" json:"CurrentValue"`
	OldValue     string    `orm:"old_value" json:"OldValue"`
	Remark       string    `orm:"remark" json:"Remark"`
	CreateBy     string    `orm:"create_by" json:"CreateBy"`
	CreateTime   time.Time `orm:"create_time" json:"CreateTime"`
}

// TableName get sql table name.获取数据库表名
func (l Log) TableName() string {
	return "tbl_operate_log"
}

func (l Log) Insert(log []*Log) error {
	_, err := database.Train.DB.Model(Log{}).Save(log)
	return err
}
