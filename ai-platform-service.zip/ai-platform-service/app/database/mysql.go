package database

import (
	"ai-platform-service/config"
	"context"
	"strconv"

	"github.com/gogf/gf/frame/g"

	"github.com/gogf/gf/database/gdb"
)

var Train *DataBase

type DataBase struct {
	cfg    *config.MysqlCfg
	ctx    context.Context
	cancel context.CancelFunc
	DB     gdb.DB
}

func (db *DataBase) Init() {
	db.cfg = &config.Cfg.Mysql
	db.ctx, db.cancel = context.WithCancel(context.Background())
}

func (db *DataBase) Start() error {
	gdb.AddConfigNode(db.cfg.Database, gdb.ConfigNode{
		Host:     db.cfg.Host,
		Port:     strconv.Itoa(db.cfg.Port),
		User:     db.cfg.User,
		Pass:     db.cfg.Pwd,
		Name:     db.cfg.Database,
		Type:     db.cfg.Type,
		Timezone: db.cfg.Timezone,
		Debug:    true,
	})
	db.DB = g.DB(db.cfg.Database)
	Train = db
	return nil
}

func (db *DataBase) Stop() error {
	db.cancel()
	return db.DB.Close(db.ctx)
}

func (db *DataBase) Name() string { return "DataBase" }
