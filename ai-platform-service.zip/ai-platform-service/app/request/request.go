package request

type CreateTask struct {
	TaskName        string `v:"caseSensitive:TaskName|required"`
	GitUrl          string `v:"caseSensitive:GitUrl|required"`
	Branch          string `v:"caseSensitive:Branch|required"`
	Namespace       string `v:"caseSensitive:Namespace|required|in:perception-project,pnc-project,data-project"`
	PNameValue      string `v:"caseSensitive:PNameValue|required"`
	GpuMode         string `v:"caseSensitive:GpuMode|required|in:A100,RTX3090"`
	GpuLimit        int    `v:"caseSensitive:GpuLimit|required|integerMulti:8"`
	Command         string `v:"caseSensitive:Command|required"`
	DatasetPath     string `v:"caseSensitive:DatasetPath"`
	ModelPath       string `v:"caseSensitive:ModelPath"`
	IsDistributed   bool   `v:"caseSensitive:IsDistributed"`
	ScriptPath      string `v:"caseSensitive:ScriptPath|required"`
	BaseImage       string `v:"caseSensitive:BaseImage|required"`
	IsPreprocessing bool   `v:"caseSensitive:IsPreprocessing"`
	IsBadCase       bool   `v:"caseSensitive:IsBadCase|required" d:"false"`
	TrainPath       string `v:"caseSensitive:TrainPath"`
	TestPath        string `v:"caseSensitive:TestPath"`
	Env             string `v:"caseSensitive:Env"`
	BuildID         string `json:"-"`
	Common          Common `json:"-"`
}

type GetTask struct {
	PipelineID   []string `v:"caseSensitive:PipelineID"`
	TaskName     []string `v:"caseSensitive:TaskName"`
	Status       []int    `v:"caseSensitive:Status"`
	Creator      []string `v:"caseSensitive:Creator"`
	StartTime    int64    `v:"caseSensitive:StartTime"`
	EndTime      int64    `v:"caseSensitive:EndTime"`
	OrderBy      string   `v:"caseSensitive:OrderBy|in:id,creator,create_time,modify_time" d:"id"`
	ResourceType []string `v:"caseSensitive:ResourceType"`
	IsDesc       int      `v:"caseSensitive:IsDesc|in:0,1" d:"1"`
	Page         int      `v:"caseSensitive:Page|min:1" d:"1"`
	PageCount    int      `v:"caseSensitive:PageCount|min:1" d:"20"`
	Common       Common   `json:"-"`
}

type GetTaskPods struct {
	PipelineID []string `v:"caseSensitive:PipelineID|required"`
	Common     Common   `json:"-"`
}

type RetryTask struct {
	Resume     string `v:"caseSensitive:Resume"`
	PipelineID string `v:"caseSensitive:PipelineID|required"`
	Common     Common `json:"-"`
}

type CreateTaskByYaml struct {
	TaskName  string       `v:"caseSensitive:TaskName|required"`
	YamlUrl   string       `v:"caseSensitive:YamlUrl|required"`
	Namespace string       `v:"caseSensitive:Namespace|in:perception-project,pnc-project,data-project" d:"perception-project"`
	GpuLimit  int          `v:"caseSensitive:GpuLimit|min:1|max:8" d:"1"`
	GpuMode   string       `v:"caseSensitive:GpuMode|in:RTX3090,A100,V100" d:"RTX3090"`
	Params    []YamlParams `v:"caseSensitive:Params"`
	Common    Common       `json:"-"`
}

type CreateTaskCRD struct {
	TaskName        string       `v:"caseSensitive:TaskName|required"`
	YamlUrl         string       `v:"caseSensitive:YamlUrl|required"`
	Scene           string       `v:"caseSensitive:Scene|required"`
	Namespace       string       `v:"caseSensitive:Namespace" d:"kubeflow-perception"`
	GpuLimit        int          `v:"caseSensitive:GpuLimit|max:8"`
	CpuLimit        int          `v:"caseSensitive:CpuLimit"`
	MemLimit        int          `v:"caseSensitive:MemLimit"`
	GpuMode         string       `v:"caseSensitive:GpuMode|in:RTX3090,A100,MIG"`
	Params          []YamlParams `v:"caseSensitive:Params"`
	ResourceType    string       `v:"caseSensitive:ResourceType|required|in:Notebook,PersistentVolumeClaim"` // k8s api-version：jobs,pytorchjobs,notebooks
	ResourceRecycle string       `v:"caseSensitive:ResourceRecycle|in:never,auto" d:"auto"`                  // 资源回收策略，默认自动回收,never:不回收
	Common          Common       `json:"-"`
}

type YamlParams struct {
	Key   string `v:"caseSensitive:Key|required"`
	Value string `v:"caseSensitive:Value|required"`
}

type DeleteTask struct {
	PipelineID string `v:"caseSensitive:PipelineID|required"`
	Common     Common `json:"-"`
}

// 修改暂时仅支持 Notebook
type UpdateTask struct {
	PipelineID      string `v:"caseSensitive:PipelineID|required"`
	Replicas        *int32 `v:"caseSensitive:Replicas"`
	GpuLimit        *int   `v:"caseSensitive:GpuLimit|max:8"`
	CpuLimit        *int   `v:"caseSensitive:CpuLimit"`
	MemLimit        *int   `v:"caseSensitive:MemLimit"`
	GpuMode         string `v:"caseSensitive:GpuMode|in:RTX3090,A100,MIG"`
	ResourceRecycle string `v:"caseSensitive:ResourceRecycle|in:auto,never"` // 资源回收策略，默认自动回收,never:不回收
	Common          Common `json:"-"`
}
type GetGpuInfo struct {
	Common Common `json:"-"`
}

type GetGpuAvgUsage struct {
	Start    *int64 `v:"caseSensitive:Start|required-with:end|validTimestamp:s"`
	End      *int64 `v:"caseSensitive:End|required-with:start|validTimestamp:s"`
	Step     string `v:"caseSensitive:Step|in:1h,1d" d:"1h"`
	NodeName string `v:"caseSensitive:NodeName"`
	Common   Common `json:"-"`
}

type GetGpuPods struct {
	Common Common `json:"-"`
}

type Common struct {
	ReqUuid string
	UserInfo
}
type UserInfo struct {
	DisplayName    string `json:"displayName"`
	SamAccountName string `json:"samAccountName"`
	PeopleSoftID   string `json:"peopleSoftID"`
}

type GetLog struct {
	Uuid         string `v:"caseSensitive:Uuid|required"`
	BusinessType string `v:"caseSensitive:BusinessType|required|in:notebook,task"`
	OperateType  string `v:"caseSensitive:OperateType|in:post,delete,put"`
	Creator      string `v:"caseSensitive:Creator"`
	Common       Common `json:"-"`
}

type GetGpuIndicators struct {
	Start  int64  `v:"caseSensitive:Start|required-with:end|validTimestamp:s"`
	End    int64  `v:"caseSensitive:End|required-with:start|validTimestamp:s"`
	Step   int64  `v:"caseSensitive:Step|required-with:end,start" d:"1"`
	Common Common `json:"-"`
}

type GetPodMonitorRate struct {
	PipelineID  string `v:"caseSensitive:PipelineID|required"`
	MonitorType string `v:"caseSensitive:MonitorType|required|in:GPUCalPower,CPU,GPUMemory,Memory"`
	Start       int64  `v:"caseSensitive:Start|required-with:end|validTimestamp:s"`
	End         int64  `v:"caseSensitive:End|required-with:start|validTimestamp:s"`
	Step        int64  `v:"caseSensitive:Step|required-with:end,start" d:"60"`
	Common      Common `json:"-"`
}
type GetSceneMonitorRate struct {
	Scene       string `v:"caseSensitive:Scene|required"`
	Type        string `v:"caseSensitive:Type|required"`
	MonitorType string `v:"caseSensitive:MonitorType|required|in:GPUCalPower,CPU,GPUMemory,Memory"`
	Common      Common `json:"-"`
}

type GetMonitorSummary struct {
	IsRange      bool     `v:"caseSensitive:IsRange|required" d:"false"`
	Start        string   `v:"caseSensitive:Start|required-with:end|date-format:Y-m-d"`
	End          string   `v:"caseSensitive:End|required-with:start|date-format:Y-m-d"`
	TargetDate   string   `v:"caseSensitive:TargetDate|date-format:Y-m-d"`
	Scene        []string `v:"caseSensitive:Scene"`
	Desc         string   `v:"caseSensitive:Desc"`
	Asc          string   `v:"caseSensitive:Asc"`
	ResourceType string   `v:"caseSensitive:ResourceType"`
	Common       Common   `json:"-"`
}

type GetMonitorTopN struct {
	IsRange    bool   `v:"caseSensitive:IsRange|required" d:"false"`
	Start      string `v:"caseSensitive:Start|required-with:end|date-format:Y-m-d"`
	End        string `v:"caseSensitive:End|required-with:start|date-format:Y-m-d"`
	TargetDate string `v:"caseSensitive:TargetDate|date-format:Y-m-d"`
	IsDesc     bool   `v:"caseSensitive:IsDesc|required" d:"True"`
	Limit      int    `v:"caseSensitive:Limit|required" d:"5"`
	Target     string `v:"caseSensitive:Target|required|in:cpu_rate,gpu_mem_rate,gpu_cal_rate,memory_use" d:"gpu_cal_rate"`
	Common     Common `json:"-"`
}
type GetSceneMonitor struct {
	Common Common `json:"-"`
}

type GetPodCalRate struct {
	PipelineID string `v:"caseSensitive:PipelineID|required"`
	Common     Common `json:"-"`
}

type GetAbnormalNodes struct {
	NodeIP         string `v:"caseSensitive:NodeIP"`
	NodeName       string `v:"caseSensitive:NodeName"`
	AbnormalReason string `v:"caseSensitive:AbnormalReason"`
	NodeType       string `v:"caseSensitive:NodeType"`
	Common         Common `json:"-"`
}

type GetResourcesTopN struct {
	Common Common `json:"-"`
	Target string `v:"caseSensitive:Target|required|in:CpuRate,GpuRate,MemoryRate"`
	Limit  int    `v:"caseSensitive:Limit|required" d:"10"`
	IsDesc bool   `v:"caseSensitive:IsDesc|required" d:"true"`
}
