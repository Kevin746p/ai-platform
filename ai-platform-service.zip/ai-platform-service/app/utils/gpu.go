package utils

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/app/prometheus"
	"ai-platform-service/app/response"
	"ai-platform-service/config"
	"fmt"
	"github.com/prometheus/common/model"
	"time"

	"github.com/gogf/gf/util/gconv"
)

type GpuNode struct {
	HostName string
	GpuMode  string
	NotUsed  int64 // 剩余数量
}
type NodeRate struct {
	NodeName string
	NodeIP   string
	Rate     float64
}

func GetValidGpuNode(gpuMode string, requiredGpu int64) (result GpuNodeList, err error) {
	err, data := prometheus.PromeCli.Query(config.Cfg.ExternalUrl.GpuLeftUrl)
	if data.Type() != model.ValVector {
		err = fmt.Errorf("invalid data type")
		return
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return
	}
	for _, item := range vector {
		notUsed := gconv.Int64(item.Value)
		if string(item.Metric["gpu_mode"]) == gpuMode && notUsed >= requiredGpu {
			result = append(result, GpuNode{
				HostName: string(item.Metric["hostname"]),
				GpuMode:  string(item.Metric["gpu_mode"]),
				NotUsed:  int64(item.Value),
			})
		}
	}
	return
}

func GetAllValidGpuCount() (map[string]int64, error) {
	err, data := prometheus.PromeCli.Query(config.Cfg.ExternalUrl.GpuLeftUrl)
	if data.Type() != model.ValVector {
		err = fmt.Errorf("invalid data type")
		return nil, err
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return nil, err
	}
	gpuNotUsed := make(map[string]int64)
	for _, eachGpu := range vector {
		gpuNotUsed[string(eachGpu.Metric["gpu_mode"])] += gconv.Int64(eachGpu.Value)
	}
	return gpuNotUsed, nil
}

type GpuNodeList []GpuNode

func (s GpuNodeList) Len() int { return len(s) }

func (s GpuNodeList) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s GpuNodeList) Less(i, j int) bool {
	return s[i].NotUsed < s[j].NotUsed
}

type gpuUsage struct {
	HostName, GpuMode, Instance string
	RateWithTimeList            []model.SamplePair
}
type gpuLatestUsage struct {
	HostName string
	GpuMode  string
	Rate     float64
	Time     int64
}
type gpuPodUsage struct {
	Pod      string
	PodUsage float64
	HostName string
	Time     int64
}
type podCardGpuUsage struct {
	UUID, Gpu, HostName string
	Values              []model.SamplePair
}
type podCpuUsage struct {
	Time  int64
	Value float64
}

// 获取历史数据所有GPU使用率
func GetGpuUsage(start, end, step int64, nodeName string) (result []gpuUsage, err error) {
	var data model.Value
	cTime := time.Now().Unix()
	if start == 0 || end == 0 {
		start = cTime
		end = cTime
		step = 1
	}
	if nodeName != "" {
		nodeName = fmt.Sprintf("{hostname=\"%s\"}", nodeName)
	}
	gpuInfoUrl := fmt.Sprintf(config.Cfg.ExternalUrl.GpuAvgUsageUrl, nodeName)
	err, data = prometheus.PromeCli.QueryRange(gpuInfoUrl, time.Unix(start, 0), time.Unix(end, 0), time.Duration(step)*time.Second)

	if data.Type() != model.ValMatrix {
		err = fmt.Errorf("invalid data type")
		return
	}
	var matrix model.Matrix
	if err = gconv.Struct(data, &matrix); err != nil {
		return
	}
	for _, item := range matrix {
		result = append(result, gpuUsage{
			HostName:         string(item.Metric["hostname"]),
			GpuMode:          string(item.Metric["gpu_mode"]),
			Instance:         string(item.Metric["instance"]),
			RateWithTimeList: item.Values,
		})
	}
	return
}

// GetLatestGpuUsage 获取最新GPU使用率
func GetLatestGpuUsage(nodeName string) (result []gpuLatestUsage, err error) {
	var data model.Value
	if nodeName != "" {
		nodeName = fmt.Sprintf("{hostname=\"%s\"}", nodeName)
	}
	gpuInfoUrl := fmt.Sprintf(config.Cfg.ExternalUrl.GpuAvgUsageUrl, nodeName)
	err, data = prometheus.PromeCli.Query(gpuInfoUrl)

	if data.Type() != model.ValVector {
		err = fmt.Errorf("invalid data type")
		return
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return
	}

	for _, item := range vector {
		result = append(result, gpuLatestUsage{
			HostName: string(item.Metric["hostname"]),
			GpuMode:  string(item.Metric["gpu_mode"]),
			Rate:     float64(item.Value),
			Time:     int64(item.Timestamp),
		})
	}
	return
}

type GpuCardCount struct {
	GpuMode   string
	Count     float64
	NotUsed   float64
	EightNode float64
	FourNode  float64
}

// GetGpuPodUsage 获取GPU pod占用情况
func GetGpuPodUsage() (result []gpuPodUsage, err error) {
	var data model.Value
	err, data = prometheus.PromeCli.Query(config.Cfg.ExternalUrl.GpuPodUsageUrl)
	if data.Type() != model.ValVector {
		err = fmt.Errorf("invalid data type")
		return
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return
	}
	for _, item := range vector {
		result = append(result, gpuPodUsage{
			Pod:      string(item.Metric["pod"]),
			PodUsage: float64(item.Value),
			HostName: string(item.Metric["hostname"]),
			Time:     int64(item.Timestamp),
		})
	}
	return
}

// 获取GPU总卡数
func GetGpuCardCountByType() (error, map[string]float64) {
	count := make(map[string]float64)
	err, data := prometheus.PromeCli.Query(config.Cfg.ExternalUrl.GpuMonitorUrl)
	if err != nil {
		return err, count
	}
	if data.Type() != model.ValVector {
		return fmt.Errorf("invalid data type"), count
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return err, count
	}
	for _, v := range vector {
		if v.Metric["resource_type"] != "" { //空表示总数
			count[string(v.Metric["resource_type"])] = float64(v.Value)
		}
	}
	return nil, count
}

// 获取GPU剩余卡数
func GetGpuLeftCardCount() (error, map[string]float64) {
	count := make(map[string]float64)
	err, data := prometheus.PromeCli.Query(config.Cfg.ExternalUrl.GpuNotUseUrl)
	if err != nil {
		return err, count
	}
	if data.Type() != model.ValVector {
		return fmt.Errorf("invalid data type"), count
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return err, count
	}
	for _, v := range vector {
		if v.Metric["resource_type"] != "" { //空表示总数
			count[string(v.Metric["resource_type"])] = float64(v.Value)
		}
	}
	return nil, count
}

// GetGpuNodeCount 根据GPU类型获取节点数
func GetGpuNodeCount() (error, map[string]float64) {
	count := make(map[string]float64)
	err, data := prometheus.PromeCli.Query(config.Cfg.ExternalUrl.GpuNodeCountUrl)
	if err != nil {
		return err, count
	}
	if data.Type() != model.ValVector {
		return fmt.Errorf("invalid data type"), count
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return err, count
	}
	for _, v := range vector {
		if v.Metric["gpu_mode"] != "" { //空表示总数
			count[string(v.Metric["gpu_mode"])] = float64(v.Value)
		}
	}
	return nil, count
}

// 获取GPU8卡空闲节点数，4卡空闲节点数
func GetGpuFreeNode() (error, map[string]*GpuCardCount) {
	count := make(map[string]*GpuCardCount)
	err, data := prometheus.PromeCli.Query(config.Cfg.ExternalUrl.Gpu8FreeNodeUrl)
	if err != nil {
		return err, count
	}
	if data.Type() != model.ValVector {
		return fmt.Errorf("invalid data type"), count
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return err, count
	}
	for _, v := range vector {
		if v.Metric["gpu_mode"] != "" { //空表示总数
			if _, ok := count[string(v.Metric["gpu_mode"])]; !ok {
				count[string(v.Metric["gpu_mode"])] = new(GpuCardCount)
			}
			count[string(v.Metric["gpu_mode"])].EightNode = float64(v.Value)
		}
	}
	err, data = prometheus.PromeCli.Query(config.Cfg.ExternalUrl.Gpu4FreeNodeUrl)
	if err != nil {
		return err, count
	}
	if data.Type() != model.ValVector {
		return fmt.Errorf("invalid data type"), count
	}
	if err = gconv.Struct(data, &vector); err != nil {
		return err, count
	}
	for _, v := range vector {
		if v.Metric["gpu_mode"] != "" { //空表示总数
			if _, ok := count[string(v.Metric["gpu_mode"])]; !ok {
				count[string(v.Metric["gpu_mode"])] = new(GpuCardCount)
			}
			count[string(v.Metric["gpu_mode"])].FourNode = float64(v.Value)
		}
	}
	return nil, count
}

// GetPodCardGpuUsage 获取Pod Gpu使用率
func GetPodCardGpuUsage(start, end, step int64, podName string) (result []response.CommonRateWithTime, err error) {
	cTime := time.Now().Unix()
	if start == 0 {
		start = cTime
	}
	if end == 0 {
		end = cTime
	}
	if step == 0 {
		step = int64(60)
	}
	gpuInfoUrl := fmt.Sprintf(config.Cfg.ExternalUrl.GpuPodCardAvgUsageUrl, podName)
	var data model.Value
	err, data = prometheus.PromeCli.QueryRange(gpuInfoUrl, time.Unix(start, 0), time.Unix(end, 0), time.Duration(step)*time.Second)
	if err != nil {
		return
	}
	if data.Type() != model.ValMatrix {
		return nil, fmt.Errorf("invalid data type")
	}
	var matrix model.Matrix
	if err = gconv.Struct(data, &matrix); err != nil {
		return
	}
	for _, item := range matrix {
		for _, v := range item.Values {
			result = append(result, response.CommonRateWithTime{
				Time: v.Timestamp.Unix(),
				Rate: float64(v.Value),
			})
		}
	}
	return
}

// GetPodCpuUsage 获取Pod Cpu使用率
func GetPodCpuUsage(podName string) (result []podCpuUsage, err error) {
	now := time.Now()
	start := now.Add(-time.Minute * time.Duration(config.Cfg.ExternalUrl.CpuPodCardUsageUrlRange))
	step := int64(60)
	gpuInfoUrl := fmt.Sprintf(config.Cfg.ExternalUrl.CpuPodCardUsageUrl, podName)
	err, data := prometheus.PromeCli.QueryRange(gpuInfoUrl, start, now, time.Duration(step)*time.Second)
	if data.Type() != model.ValMatrix {
		err = fmt.Errorf("invalid data type")
		return
	}
	var matrix model.Matrix
	if err = gconv.Struct(data, &matrix); err != nil {
		return
	}
	for _, item := range matrix {
		for _, v := range item.Values {
			result = append(result, podCpuUsage{
				Value: float64(v.Value),
				Time:  int64(v.Timestamp),
			})
		}
	}
	return
}

// GetGpuClusterUsage 获取GPU集群使用率
func GetGpuClusterUsage(start, end, step int64) (result response.GpuClusterPowerRateList, err error) {
	var data model.Value
	err, data = prometheus.PromeCli.QueryRange(config.Cfg.ExternalUrl.GpuClusterAvgUsageUrl, time.Unix(start, 0), time.Unix(end, 0), time.Duration(step)*time.Second)
	if err != nil {
		return
	}
	if data.Type() != model.ValMatrix {
		return nil, fmt.Errorf("invalid data type")
	}
	gpuClusterUsage := make(map[int64]float64)
	var matrix model.Matrix
	if err = gconv.Struct(data, &matrix); err != nil {
		return
	}
	for _, item := range matrix {
		for _, v := range item.Values {
			timeStamp := v.Timestamp.Unix()
			gpuClusterUsage[timeStamp] = float64(v.Value)
		}

	}
	for start <= end {
		if v, ok := gpuClusterUsage[start]; !ok {
			result = append(result, response.CommonRateWithTime{Time: start, Rate: 0})
		} else {
			result = append(result, response.CommonRateWithTime{Time: start, Rate: v})
		}
		start += step
	}
	return
}

type ClusterPower struct {
	PowerTotal   float64
	PowerA100    float64
	PowerRTX3090 float64
}

// GetGpuClusterPower  获取GPU总算力
func GetGpuClusterPower() (clusterPower ClusterPower, err error) {
	err, count := GetGpuCardCountByType()
	if err != nil {
		return
	}
	if v, ok := count[enum.ResourceTypeA100]; ok {
		clusterPower.PowerA100 = v * config.Cfg.GPUCalPower.A100
	} else {
		err = fmt.Errorf("get gpu:%v  card failed", enum.ResourceTypeA100)
		return
	}
	clusterPower.PowerTotal = clusterPower.PowerA100
	if clusterPower.PowerTotal == 0 {
		err = fmt.Errorf("get gpu power failed")
		return
	}
	return
}

// GetGpuClusterMemory 获取GPU显存利用率
func GetGpuClusterMemory(start, end, step int64) (result response.GpuClusterMemoryRateList, err error) {
	var data model.Value
	err, data = prometheus.PromeCli.QueryRange(config.Cfg.ExternalUrl.GpuClusterMemoryUsageUrl, time.Unix(start, 0), time.Unix(end, 0), time.Duration(step)*time.Second)
	if err != nil {
		return
	}
	if data.Type() != model.ValMatrix {
		return nil, fmt.Errorf("invalid data type")
	}
	gpuClusterMemoryUsage := make(map[int64]float64)
	var matrix model.Matrix
	if err = gconv.Struct(data, &matrix); err != nil {
		return
	}
	for _, item := range matrix {
		for _, v := range item.Values {
			timeStamp := v.Timestamp.Unix()
			gpuClusterMemoryUsage[timeStamp] = float64(v.Value)
		}
	}
	for start <= end {
		if v, ok := gpuClusterMemoryUsage[start]; !ok {
			result = append(result, response.CommonRateWithTime{Time: start, Rate: 0})
		} else {
			result = append(result, response.CommonRateWithTime{Time: start, Rate: v})
		}
		start += step
	}
	return
}

// GetPodRangeAvgUsage 获取Pod Gpu,Gpu显存，内存，Cpu平均使用率
func GetPodRangeAvgUsage(start, end, step int64, query string) (result response.PodRangeAvgUsage, err error) {
	cTime := time.Now().Unix()
	if start == 0 {
		start = cTime
	}
	if end == 0 {
		end = cTime
	}
	if step == 0 {
		step = int64(60)
	}
	var data model.Value
	err, data = prometheus.PromeCli.QueryRange(query, time.Unix(start, 0), time.Unix(end, 0), time.Duration(step)*time.Second)
	if err != nil {
		return
	}
	if data.Type() != model.ValMatrix {
		return nil, fmt.Errorf("invalid data type")
	}
	var matrix model.Matrix

	podGpuUsage := make(map[int64]float64)
	if err = gconv.Struct(data, &matrix); err != nil {
		return
	}
	for _, item := range matrix {
		for _, v := range item.Values {
			timeStamp := v.Timestamp.Unix()
			podGpuUsage[timeStamp] = float64(v.Value)
		}
	}
	for start <= end {
		if v, ok := podGpuUsage[start]; !ok {
			result = append(result, response.CommonRateWithTime{Time: start, Rate: 0})
		} else {
			result = append(result, response.CommonRateWithTime{Time: start, Rate: v})
		}
		start += step
	}
	return
}

func GetGpuPodUsedCount(podName string) (map[string]int, error) {
	podMap := make(map[string]int)
	query := fmt.Sprintf(config.Cfg.ExternalUrl.GpuPodUsedCount, podName)
	err, data := prometheus.PromeCli.Query(query)
	if data.Type() != model.ValVector {
		err = fmt.Errorf("invalid data type")
		return podMap, err
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return podMap, err
	}
	for _, item := range vector {

		value := gconv.Int(item.Value)
		if item.Metric["pod"] == "" {
			continue
		}
		podMap[string(item.Metric["pod"])] = value
	}
	return podMap, err
}

type NodeList []NodeRate

func GetNodeMonitorData(isDesc, target string, limit int) (result NodeList, err error) {
	var query string
	var nodeNameKey, nodeIPKey model.LabelName
	switch target {
	case enum.Cpu:
		query = fmt.Sprintf(config.Cfg.ExternalUrl.NodeCpuUsage, isDesc, limit)
		nodeNameKey = "instance"
		nodeIPKey = "internal_ip"
	case enum.Gpu:
		query = fmt.Sprintf(config.Cfg.ExternalUrl.NodeGpuUsage, isDesc, limit)
		nodeNameKey = "hostname"
		nodeIPKey = "instance"
	case enum.Memory:
		query = fmt.Sprintf(config.Cfg.ExternalUrl.NodeMemoryUsage, isDesc, limit)
		nodeNameKey = "instance"
		nodeIPKey = "internal_ip"

	default:
		err = fmt.Errorf("get wrong target type")
		return
	}
	err, data := prometheus.PromeCli.Query(query)
	if data.Type() != model.ValVector {
		err = fmt.Errorf("invalid data type")
		return
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return
	}

	for _, item := range vector {

		result = append(result, NodeRate{
			NodeName: string(item.Metric[nodeNameKey]),
			NodeIP:   string(item.Metric[nodeIPKey]),
			Rate:     gconv.Float64(fmt.Sprintf("%.2f", item.Value)),
		})

	}
	return
}

func GetNodeUseAgeByQuery(query string) (float64, error) {
	err, data := prometheus.PromeCli.Query(query)
	if data.Type() != model.ValVector {
		err = fmt.Errorf("invalid data type")
		return 0, err
	}
	var vector model.Vector
	if err = gconv.Struct(data, &vector); err != nil {
		return 0, err
	}
	for _, item := range vector {
		value := gconv.Float64(fmt.Sprintf("%.2f", item.Value))
		return value, nil

	}
	return 0, nil
}
