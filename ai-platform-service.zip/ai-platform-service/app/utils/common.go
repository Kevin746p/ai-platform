package utils

import (
	"sort"
)

func IsExistString(targetSlice []string, target string) bool {
	for _, v := range targetSlice {
		if v == target {
			return true
		}
	}
	return false
}
func IsExistInt(targetSlice []int, target int) bool {
	for _, v := range targetSlice {
		if v == target {
			return true
		}
	}
	return false
}

type TimeInterval struct {
	Start int64
	End   int64
}
type TimeSlice []TimeInterval

func (t TimeSlice) Len() int { return len(t) }

func (t TimeSlice) Swap(i, j int) { t[i], t[j] = t[j], t[i] }

func (t TimeSlice) Less(i, j int) bool { return t[i].Start < t[j].Start }
func (t TimeSlice) Intersect() TimeSlice {
	var s TimeSlice

	if len(t) > 1 {
		sort.Stable(t)
		s = append(s, t[0])
		for k, v := range t {
			if v.Start > v.End {
				return s
			}
			if k == 0 {
				continue
			}
			// 两个时间段相交
			if v.Start >= s[0].Start && v.Start <= s[0].End {
				// 开始时间取最大的那个
				s[0].Start = v.Start
				// 结束时间取最小的那个
				if v.End <= s[0].End {
					s[0].End = v.End
				}
			} else {
				return s[:0]
			}
		}
	}

	return s
}
