package utils

import (
	"encoding/base64"
	"math/rand"
	"strings"
	"time"
)

func FormatBool(b bool) string {
	if b {
		return "1"
	}
	return "0"
}
func FormatBoolWithSymbol(b bool) string {
	if b {
		return "\"1\""

	}
	return "\"0\""
}
func FormatBoolWithInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

const letterBytes = "0123456789abcdefghijklmnopqrstuvwxyz"
const (
	letterIdxBits = 6                    // 6 bits to represent a letter index
	letterIdxMask = 1<<letterIdxBits - 1 // All 1-bits, as many as letterIdxBits
	letterIdxMax  = 63 / letterIdxBits   // # of letter indices fitting in 63 bits
)

func RandStringBytesMaskImpr(n int) string {
	b := make([]byte, n)
	rand.Seed(time.Now().UnixNano()) // 纳秒时间戳
	for i, cache, remain := n-1, rand.Int63(), letterIdxMax; i >= 0; {
		if remain == 0 {
			cache, remain = rand.Int63(), letterIdxMax
		}
		if idx := int(cache & letterIdxMask); idx < len(letterBytes) {
			b[i] = letterBytes[idx]
			i--
		}
		cache >>= letterIdxBits
		remain--
	}
	return string(b)
}

// 计算step时间戳
func GetStepTimeStamp(start, end, step int64) (timestamps []int64) {
	if step == 0 {
		return
	}
	if start == 0 || end == 0 {
		return
	}
	for start <= end {
		timestamps = append(timestamps, start)
		start += step
	}
	return timestamps
}

// 计算step时间戳
func TransferTimeStepIntoSecond(step string) int64 {
	switch step {
	case "1d":
		return 86400
	case "1h":
		return 3600
	case "1s":
		return 1
	}
	return 0
}

// DecodeSegment 解码特定于JWT的base64url编码，去除填充
func DecodeSegment(seg string) ([]byte, error) {
	if l := len(seg) % 4; l > 0 {
		seg += strings.Repeat("=", 4-l)
	}

	return base64.URLEncoding.DecodeString(seg)
}
