package nacos

import (
	"ai-platform-service/app/enum"
	"ai-platform-service/config"
	"context"
	"encoding/json"
	"errors"
	"net"
	"sort"
	"strconv"

	"github.com/gogf/gf/frame/g"
	"github.com/nacos-group/nacos-sdk-go/clients"
	"github.com/nacos-group/nacos-sdk-go/clients/config_client"
	"github.com/nacos-group/nacos-sdk-go/clients/naming_client"
	"github.com/nacos-group/nacos-sdk-go/common/constant"
	"github.com/nacos-group/nacos-sdk-go/model"
	"github.com/nacos-group/nacos-sdk-go/vo"
)

var NacosClients *Nacos

type Nacos struct {
	cfg          *config.NacosCfg
	ctx          context.Context
	cancel       context.CancelFunc
	namingClient naming_client.INamingClient
	configClient config_client.IConfigClient
}

func (n *Nacos) Init() {
	// nacos 的默认配置
	n.cfg = &config.Cfg.Nacos
	n.ctx, n.cancel = context.WithCancel(context.Background())
	NacosClients = n
}

func (n *Nacos) Start() (err error) {
	//if n.cfg.Enable {
	//	err = n.newClient()
	//	if err != nil {
	//		return err
	//	}
	//	err = n.getConfigFromNacos(&config.Cfg)
	//	if err != nil {
	//		return err
	//	}
	//	err = n.register()
	//	if err != nil {
	//		return err
	//	}
	//	go n.listenConfig()
	//}
	return nil
}

func (n *Nacos) Stop() error {
	n.cancel()
	return nil
}
func (n *Nacos) Name() string { return "Nacos" }

func (n *Nacos) newClient() (err error) {
	serverConfigs := []constant.ServerConfig{
		{
			IpAddr: n.cfg.Ip,
			Port:   uint64(n.cfg.Port),
		},
	}
	clientConfig := constant.ClientConfig{
		NotLoadCacheAtStart: true,
	}
	n.namingClient, err = clients.NewNamingClient(
		vo.NacosClientParam{
			ClientConfig:  &clientConfig,
			ServerConfigs: serverConfigs,
		})
	if err != nil {
		g.Log().Error("create nacos naming client Error: ", err.Error())
		return err
	}
	n.configClient, err = clients.NewConfigClient(
		vo.NacosClientParam{
			ClientConfig:  &clientConfig,
			ServerConfigs: serverConfigs,
		})
	if err != nil {
		g.Log().Error("create nacos config client Error: ", err.Error())
		return err
	}
	return err
}

// 向nacos注册本节点
func (n *Nacos) register() error {
	if n.cfg == nil {
		return errors.New("nacos config not found")
	}
	ip, err := n.getClientIp()
	if err != nil {
		g.Log().Error("create nacos client get host ip Error: ", err.Error())
		return err
	}
	port, err := strconv.ParseUint(config.Cfg.Server.Address[1:], 10, 64)
	if err != nil {
		g.Log().Error("create nacos client get host ip Error: ", err.Error())
		return err
	}
	instances, err := n.getInstancesOrderByWeight(enum.OrderTypeDesc)
	if err != nil {
		g.Log().Error("[Nacos][getInstances]", err.Error())
		return err
	}
	weight := n.cfg.Weight
	if len(instances) > 0 {
		weight = instances[0].Weight + 10
	}
	_, err = n.namingClient.RegisterInstance(vo.RegisterInstanceParam{
		Ip:          ip,
		Port:        port,
		ServiceName: n.cfg.ServiceName,
		Weight:      weight,
		Enable:      true,
		Healthy:     true,
		Ephemeral:   true,
	})
	if err != nil {
		g.Log().Error("RegisterInstance Error: ", err.Error())
		return err
	}

	return nil
}

func (n *Nacos) getClientIp() (string, error) {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "", err
	}

	for _, address := range addrs {
		// 检查ip地址判断是否回环地址
		if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String(), nil
			}

		}
	}
	return "", errors.New("can not find the client ip address")
}

func (n *Nacos) getConfigFromNacos(dest *config.Config) error {
	content, err := n.configClient.GetConfig(vo.ConfigParam{
		DataId: n.cfg.DataID,
		Group:  n.cfg.Group,
	})
	if err != nil {
		return err
	}
	return json.Unmarshal([]byte(content), dest)
}

func (n *Nacos) listenConfig() {
	defer func() {
		if err := recover(); err != nil {
			g.Log().Error("[Nacos][listenConfig] recover failed", err)
		}
	}()
	if err := n.configClient.ListenConfig(vo.ConfigParam{
		DataId: n.cfg.DataID,
		Group:  n.cfg.Group,
		OnChange: func(namespace, group, dataId, data string) {
			err := json.Unmarshal([]byte(data), &config.Cfg)
			if err != nil {
				g.Log().Error("[Nacos][listenConfig] update cfg failed", err.Error())
			}
		},
	}); err != nil {
		g.Log().Error("[Nacos][listenConfig]", err.Error())
	}
}

func (n *Nacos) getInstancesOrderByWeight(order string) (Instances, error) {
	nodes, err := n.namingClient.SelectAllInstances(vo.SelectAllInstancesParam{ServiceName: n.cfg.ServiceName})
	sort.Sort(Instances(nodes))
	if order == enum.OrderTypeDesc {
		sort.Sort(sort.Reverse(Instances(nodes)))
	}
	return nodes, err
}

func (n *Nacos) IsMinWeightInstance() bool {
	instances, err := n.getInstancesOrderByWeight(enum.OrderTypeAsc)
	if err != nil {
		g.Log().Error("nacos GetUsingInstanceOrderByWeight", err.Error())
		return false
	}
	ip, err := n.getClientIp()
	if err != nil {
		g.Log().Error("create nacos client get host ip Error: ", err.Error())
		return false
	}
	return len(instances) > 0 && instances[0].Ip == ip
}

type Instances []model.Instance

func (s Instances) Len() int { return len(s) }

func (s Instances) Swap(i, j int) { s[i], s[j] = s[j], s[i] }

func (s Instances) Less(i, j int) bool {
	return s[i].Weight < s[j].Weight
}
