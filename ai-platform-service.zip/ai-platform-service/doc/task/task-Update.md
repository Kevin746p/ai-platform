# 任务相关接口文档

## 修改任务
当前仅支持notebook副本数修改
- 请求路由： /actuator/task
- 请求方式：PUT
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |----------- |
| PipelineID      | string  |任务ID|是|
| Replicas   | int|  副本数量:1/0 ，为0则停止notebook  |否|
| GpuLimit   | int|   Gpu申请卡数，默认0,最大8，MIG类型最大为7|否|
| CpuLimit   | int|   Cpu申请数量，默认1C,最大32C     |否|
| MemLimit   | int|   内存申请数量，默认1Gi，最大128Gi    |否|
| GpuMode   | string|   申请Gpu类型，枚举值：A100,RTX3090,MIG，默认MIG    |否|
| ResourceRecycle   | string|   资源回收策略：never：不自动回收，auto:自动回收，默认auto  |否|



请求示例
```http request
curl --location --request PUT 'http://0.0.0.0:8080/actuator/task/' \
--header 'Content-Type: application/json' \
--data-raw '{
    "PipelineID":"cc884751-fd28-4966-b7cb-5c50e837aacb",
    "Replicas":0  
}'```
返回参数

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | object|   数据  |是|
| ReqUuid   | string| 请求Uuid     |是|


返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": null ,
    "ReqUuid": "48d47a66-ca24-4434-9934-4f228442b60e"
}
```