# GPU训练任务创建

- 创建Notebook ，存储卷等自定义资源
    - 请求路由： /actuator/task/crd
    - 请求方式：POST
    - 请求头中需要携带数据平台登录统一生成的access_token用于鉴权
    - 测试线：ai-platform.perception-project.svc.cluster.local:80
    - 生产线：ai-platform.perception-project.svc.cluster.local:80

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |----------- |
| TaskName      | string  |任务名称|是|
| YamlUrl   | string|   yaml获取git地址  |是|
| Namespace      | string  |任务运行k8s namespace，默认：kubeflow-perception否|
| Scene   | string|   场景  |是|
| GpuLimit   | int|   Gpu申请卡数，默认0,最大8,MIG最大7 |否|
| CpuLimit   | int|   Cpu申请数量，默认1C,最大32C     |否|
| MemLimit   | int|   内存申请数量，默认1Gi，最大128Gi    |否|
| GpuMode   | string|   申请Gpu类型，枚举值：A100,RTX3090,MIG，默认MIG    |否|
| ResourceType   | string|  资源类型：支持"Notebook,PersistentVolumeClaims"     |是|
| Params   | []Object|   yaml中需要替换的参数     |否|
| ResourceRecycle   | string|   资源回收策略：never：不自动回收，auto:自动回收，默认auto  |否|

Params Object 说明

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |----------- |
| Key      | string  |参数名称名称|是|
| Value   | string|   参数值  |是|

请求示例
```http request
curl --location --request POST 'http://0.0.0.0:8080/actuator/task/crd' \
--header 'access_token: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkaXNwbGF5TmFtZSI6IuadqOiMl-WHryIsImN1cnJlbnRUaW1lTWlsbGlzIjoiMTY1OTA1OTkwMDkxMiIsInNhbUFjY291bnROYW1lIjoiZS1NaW5na2FpLllhbmciLCJuYW1lIjoiZS1NaW5na2FpLllhbmciLCJwZW9wbGVTb2Z0SUQiOiIwMzIzNTA3IiwiaWQiOjE1MjQ3MjYzNDE2ODM0MjUyODIsImV4cCI6MTY1OTA2MjkwMH0.6j7c2xyIlqunzfeDPgkGhnpBSLrwRhYuVepmIv05veQ' \
--header 'Content-Type: application/json' \
--data-raw '{
   "YamlUrl":"https://git-auto.zeekrlife.com/boyi.sun/test-git/-/raw/master/notebook.yaml",
   "TaskName":"sby-note-book-shs",
   "ResourceType":"Notebook",
   "Namespace":"kubeflow-perception",
   "Params":[
       {
           "Key":"image_ide",
           "Value":"devops-harbor.zeekrlife.com/kubeflow/traffic_light_continuous_image_ide827:v1.0"
       },
       {
           "Key":"pvc_name",
           "Value":"z0327851222"
       }
   ]
}'
```

```http request 创建Pvc
curl --location --request POST 'http://0.0.0.0:8080/actuator/task/crd' \
--header 'access_token: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkaXNwbGF5TmFtZSI6IuadqOiMl-WHryIsImN1cnJlbnRUaW1lTWlsbGlzIjoiMTY1OTA1OTkwMDkxMiIsInNhbUFjY291bnROYW1lIjoiZS1NaW5na2FpLllhbmciLCJuYW1lIjoiZS1NaW5na2FpLllhbmciLCJwZW9wbGVTb2Z0SUQiOiIwMzIzNTA3IiwiaWQiOjE1MjQ3MjYzNDE2ODM0MjUyODIsImV4cCI6MTY1OTA2MjkwMH0.6j7c2xyIlqunzfeDPgkGhnpBSLrwRhYuVepmIv05veQ' \
--header 'Content-Type: application/json' \
--data-raw '{
   "YamlUrl":"https://git-auto.zeekrlife.com/boyi.sun/test-git/-/raw/master/pvc.yaml",
   "TaskName":"sby-note-book",
   "ResourceType":"PersistentVolumeClaim",
   "Namespace":"kubeflow-perception",
   "Params":[
       {
           "Key":"storage",
           "Value":"5Gi"
       },
       {
           "Key":"storage_class_name",
           "Value":"automl-perception-project-20"
       }
   ]
}'
```
返回参数

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | Object|   数据  |是|
| ReqUuid   | string| 请求Uuid     |是|
| PipelineID   | string| 执行PipelineID     |是|

Data 说明 ：

| 参数名称   | 参数类型 | 参数说明     | 是否一定返回 |
| ---------- | -------- | ------------ | -- |
| PipelineID | string   | 任务ID       | 是 |
| BuildID    | string   | 工作流ID     | 是 |
| TaskName   | string   | 任务名称     | 是 |
| Status     | string   | 状态：枚举值 | 是 |
| StatusCode | int      | 状态code     | 是 |
| Creator    | string   | 创建人域账号 | 是 |
| NameSapce | string | 命名空间 | 是 |
| Scene | string | 场景 | 是 |
| CreateTime | int      | 创建时间     | 是 |
| UpdateTime | int      | 更新时间     | 是 |
| StatusDesc | string   | 状态描述     | 是 |
| GpuLimit | int | cpu | 是 |
| MemLimit | int | 内存 | 是 |
| CpuLimit | int | cpu | 是 |
| Stage      | []int    | 任务步骤状态 | 是 |

返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": {
        "PipelineID": "7ad420eb-9c4d-4a31-9dc6-ac9402737805",
        "BuildID": "hnwmt",
        "Status": "wait",
        "StatusDesc": "排队中",
        "TaskName": "sby-note-book-shs",
        "Creator": "e-Lei.Peng",
        "Namespace": "perception-project",
        "Scene": "",
        "CreateTime": 1666609655,
        "UpdateTime": 1666609655,
        "StatusCode": 1,
        "GpuLimit": 1,
        "MemLimit": 1,
        "CpuLimit": 1,
        "Stage": [
            1,
            0,
            0,
            0
        ]
    },
    "ReqUuid": "3029ed15-6672-4abd-a75c-7466a09c8b30"
}
```