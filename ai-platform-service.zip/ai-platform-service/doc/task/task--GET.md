# 任务相关接口文档

## 获取任务详情 
- 请求路由： /actuator/task
- 请求方式：GET  
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |----------- |
| PipelineID      | string  |任务ID|是|

请求示例
```http request
curl --location --request GET 'http://0.0.0.0:8080/actuator/task?PipelineID=ae793b3a-f357-4595-c551-ff788c16ef46'
```
返回参数：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | Object|   任务信息  |是|
| ReqUuid   | string| 请求Uuid     |是|

Data 说明 ：

|参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| PipelineID      | string  |任务ID |是|
| BuildID   | string   |   工作流ID【Jenkins / Argo】   |是|
| PodName   | string|   创建的Pod名称【执行的jenkins Job名称】   |是|
| Status   | string| 状态：枚举值      |是|
| StatusDesc   | string| 状态描述：枚举值见下表      |是
| Detail   | string| 异常错误描述      |状态为异常错误时返回|
| Stage   | []int| 任务步骤状态      |是|

-  任务状态枚举值
Tips ： 任务状态待整合

| status 枚举值      |statusDesc枚举值 |  备注| 
| ----------- | ----------- | ---|
| wait      | 排队中  | |
| building   | 构建中   ||  
| buildFailed   | 构建失败|  
| pending   | 调度中|  
| running   | 运行中|  
| complete   | 完成|  
| suspended   | 运行异常|  
| failed   | 任务失败| 
| error   | 异常错误| 
| canceled   | 已取消| 

	
返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": {
        "buildId": "417",
        "hostIp": "1.2.3.4",
        "status": "complete",
        "statusDesc": "完成",
        "stage": [
            2,
            2,
            2,
            2
        ]
    },
    "ReqUuid": "20696b6a-2eae-46b-a555-d5d3dcdef46a"
}
```