# 任务相关接口文档

## 创建任务

- 请求路由： /actuator/task
- 请求方式：POST
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |------|
| TaskName      | string  |任务名称| 是    |
| Branch   | string|   代码分支     | 是    |
| Namespace      | string  |k8s namespace,枚举值：perception-project| 是    |
| PNameValue   | string|    任务场景    | 是    |
| GpuMode   | string|   GPU型号,枚举值：A100,RTX3090 | 是    |
| GpuLimit   | int|   GPU卡数限制,最小为1     | 是    |
| GitUrl   | string|   代码仓库地址  | 是    |
| Command   | string| 启动命令 | 是    |
| Env   | string|   环境变量   | 否    |
| DatasetPath   | string|   数据集路径     | 否    |
| ModelPath   | string|   模型路径     | 否    |
| ScriptPath   | string|  脚本路径     | 是    |
| BaseImage   | string|   基础镜像     | 是    |
| IsPreprocessing   | bool|   是否预处理     | 否    |
| IsDistributed   | bool|   是否分布式训练     | 否    |
| IsBadCase | bool | 是否输出评测可视化结果 | 否    |
| TrainPath   | string|   训练集路径     | 否    |
| TestPath   | string|   测试集路径     | 否    |

请求示例

```http request
curl --location --request POST 'http://0.0.0.0:8080/actuator/task' \
--header 'Content-Type: application/json' \
--data-raw '{
    "TaskName":"0908case",
    "Branch":"wangchen_automl",
    "Namespace":"perception-project",
    "PNameValue":"parking",
    "GpuMode":"A100",
    "GpuLimit":1,
    "GitUrl":"http://git-auto.zeekrlife.com/zpilot/zdrive/perception/modules/network/parking.git",
    "Command":"TRAIN",
    "Env":"null",
    "DatasetPath":"/data/parking/1=6.txt",
    "ModelPath":"hahah",
    "ScriptPath":"parking/",
    "BaseImage":"devops-harbor.zeekrlife.com/zeekr_automl/parking_image:baseline",
    "IsPreprocessing":true,"IsBadCase":true,
    "TrainPath":"/perception/label_dataset/dataset/APA_lidarseg/train_list.txt",
    "TestPath":"null"
}'
```

返回参数

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | Object|   数据  |是|
| ReqUuid   | string| 请求Uuid     |是|
| PipelineID   | string| 执行PipelineID     |是|

Data 说明 ：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| ---------- | -------- | ------------ | -- |
| PipelineID | string | 任务ID | 是 |
| BuildID | string | 工作流ID | 是 |
| TaskName | string | 任务名称 | 是 |
| Status | string | 状态：枚举值 | 是 |
| StatusCode | int | 状态code | 是 |
| Creator | string | 创建人域账号 | 是 |
| Namespace | string | 命名空间 | 是 |
| Scene | string | 场景 | 是 |
| CreateTime | int | 创建时间 | 是 |
| UpdateTime | int | 更新时间 | 是 |
| StatusDesc | string | 状态描述 | 是 |
| GpuLimit | int | gpu | 是 |
| MemLimit | int | 内存 | 是 |
| CpuLimit | int | cpu | 是 |
| Stage | []int | 任务步骤状态 | 是 |

返回示例

```json
{
  "RetCode": 0,
  "Message": "",
  "Data": {
    "PipelineID": "4296fbf0-b25f-4f77-aeca-7700cf275d9a",
    "BuildID": "fuvrv",
    "Status": "wait",
    "StatusDesc": "排队中",
    "TaskName": "0908case",
    "Creator": "e-Lei.Peng",
    "Namespace": "perception-project",
    "CreateTime": 1666597743,
    "UpdateTime": 1666597743,
    "StatusCode": 1,
    "Stage": [
      1,
      0,
      0,
      0
    ]
  },
  "ReqUuid": "80c4430a-9e3d-424d-8e9b-89494ddbbd9c"
}
```