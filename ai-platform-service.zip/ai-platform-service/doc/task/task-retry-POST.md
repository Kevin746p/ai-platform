# 任务重试

## 任务重试
- 请求路由： /actuator/task/retry
- 请求方式：POST
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |----------- |
| PipelineID     | string  |任务ID|是|
| Resume     | string  |Pth文件路径|否|



请求示例
```http request
curl --location --request POST 'http://0.0.0.0:8080/actuator/task/retry' \
--header 'Content-Type: application/json' \
--data-raw '{ 否"PipelineID":"4a3aa733-df2d-4590-a0f6-84315a73965b",
    "Resume":"212112"
    }'

```
返回参数

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | Object|   数据  |是|
| ReqUuid   | string| 请求Uuid     |是|
| PipelineID   | string| 任务ID     |是|

Data 说明 ：

| 参数名称   | 参数类型 | 参数说明     | 是否一定返回 |
| ---------- | -------- | ------------ | -- |
| PipelineID | string   | 任务ID       | 是  |
| BuildID    | string   | 工作流ID     | 是  |
| TaskName   | string   | 任务名称     | 是  |
| Status     | string   | 状态：枚举值 | 是  |
| StatusCode | int      | 状态code     | 是  |
| Creator    | string   | 创建人域账号 | 是  |
| Namespace | string | 命名空间 | 是 |
| Scene | string | 场景 | 是 |
| CreateTime | int      | 创建时间     | 是  |
| UpdateTime | int      | 更新时间     | 是  |
| StatusDesc | string   | 状态描述     | 是  |
| GpuLimit | int | gpu | 是 |
| MemLimit | int | 内存 | 是 |
| CpuLimit | int | cpu | 是 |
| Stage      | []int    | 任务步骤状态 | 是  |

返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": {
        "PipelineID": "4930aaab-9166-4ceb-a9c2-e98079a43e6c",
        "BuildID": "kwymd",
        "Status": "wait",
        "StatusDesc": "排队中",
        "TaskName": "0908case",
        "Creator": "e-Lei.Peng",
        "Namespace": "perception-project",
        "CreateTime": 1666610380,
        "UpdateTime": 1666610380,
        "StatusCode": 1,
        "GpuLimit": 1,
        "MemLimit": 0,
        "CpuLimit": 0,
        "Stage": [
            1,
            0,
            0,
            0
        ]
    },
    "ReqUuid": "a02b7213-182c-446c-b5b3-7bb781a87766"
}
```