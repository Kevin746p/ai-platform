# 任务相关接口文档

## 获取任务详情 
- 请求路由： /actuator/task/list
- 请求方式：POST  
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数

| 参数名称       | 参数类型     |  参数说明 | 是否必填             |
|------------|----------|----------- |------------------|
| PipelineID | []string |任务ID| 否                |
| TaskName   | []string |任务名称| 否                |
| Status     | []int    |状态| 否                |
| Creator    | []string |创建人| 否                |
| OrderBy    | string   |排序:枚举| 否（默认0）           |
| IsDesc     | int      |是否倒序| 否[0:否，1：是] (默认1) |
| StartTime  | int |开始创建时间| 否 |
| EndTime    | int |结束创建时间| 否 |
| ResourceType   | []string|  资源类型：默认["Job","PytorchJob"]     |否|
| Page       | int      |页码| 否(默认1)           |
| PageCount  | int      |每页数据量| 否(默认20)          |

OrderBy枚举

| Orderby     | 描述       |
| ----------- | ---------- |
| id          | 主键(默认) |
| creator     | 创建人     |
| create_time | 创建时间   |
| modify_time | 更新时间   |



请求示例

```http request
curl --location --request POST 'http://0.0.0.0:8080/actuator/task/list'
--header 'Content-Type: application/json' \
--data-raw '{
    "PipelineID":["92f7949a-1566-4125-b17f-8508b732c5c6"],
    "Status":[8,4,6,9,10],
    "Page":1,
    "PageCount":3
}'
```
返回参数：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | --------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | []Object |   任务信息  |是|
| ReqUuid   | string| 请求Uuid     |是|
| Count | int | 总数 |是|

Data 说明 ：

|参数名称      | 参数类型 |  参数说明 | 是否一定返回 |
| ----------- |-----|----------- |--------|
| PipelineID      | string |任务ID | 是      |
| BuildID   | string |   工作流ID   | 是      |
| TaskName | string |   任务名称   | 是      |
| Status   | string | 状态：枚举值      | 是      |
| StatusCode | int | 状态code | 是 |
| Creator | string | 创建人域账号 | 是      |
| Namespace | string | 命名空间 | 是 |
| Scene | string | 场景 | 是 |
| CreateTime | int | 创建时间 | 是      |
| UpdateTime | int | 更新时间 | 是      |
| StatusDesc   | string | 状态描述：枚举值见下表      | 是      |
| GpuLimit | int | Gpu | 是 |
| MemLimit | int | 内存 | 是 |
| CpuLimit | int | cpu | 是 |
| Detail   | string | 异常错误描述      | 是      |
| Stage   | []int | 任务步骤状态      | 是      |

-  任务状态枚举值
Tips ： 任务状态待整合

| StatusCode | Status 枚举值     |StatusDesc枚举值 |  备注|
| ----------- | ----------- | --- | --- |
| 1     | wait      | 排队中  | |
| 2  | building   | 构建中   ||
| 5  | buildFailed   | 构建失败||
| 6  | pending   | 调度中||
| 4  | running   | 运行中||
| 8  | complete   | 完成||
| 7  | suspended   | 运行异常||
| 9  | failed   | 任务失败||
| 10 | error   | 异常错误||
| 11 | canceled   | 已取消||


返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [
        {
            "PipelineID": "92f7949a-1566-4125-b17f-8508b732c5c6",
            "BuildID": "6tpuv",
            "TaskName": "automl-parking-eval-case0831",
            "Creator": "e-Lei.Peng",
            "Namespace": "perception-project",
            "Scene": "",
            "CreateTime": 1664441099,
            "UpdateTime": 1666071822,
            "StatusCode": 10,
            "Status": "error",
            "StatusDesc": "异常错误",
            "GpuLimit": 16,
            "MemLimit": 0,
            "CpuLimit": 0,
            "Detail": "Unauthorized",
            "Stage": [
                2,
                2,
                2,
                3
            ]
        }
    ],
    "ReqUuid": "88097d70-86fa-4fde-beb0-6fcc6134ff97",
    "Count": 1
}
```