# GPU训练任务创建

- 根据提供yaml创建k8s Job,仅支持RTX3090 
    - 请求路由： /actuator/task/yaml
    - 请求方式：POST
    - 请求头中需要携带数据平台登录统一生成的access_token用于鉴权   
    - 测试线：ai-platform.perception-project.svc.cluster.local:80
    - 生产线：ai-platform.perception-project.svc.cluster.local:80

k8s Job yaml说明：[示例yaml](
           http://git-auto.zeekrlife.com/boyi.sun/test-git/-/blob/master/template.yaml)
1. yaml中必须包含对资源申请的限制，resource limit 字段，并设置值为 "{gpu_limit}" ，
2. yaml在实际运行需要替换的变量使用花括号标识，如示例文件中的 '{param}'
3. yaml中须要配置污点容忍以保证服务正常调度到GPU节点，请见示例配置
4. vcuda 接入需要对 yaml中资源申请部分进行替换，可参考[vuda示例yaml](
                                             https://git-auto.zeekrlife.com/boyi.sun/test-git/-/raw/master/vcuda.yaml)

| 参数名称      |参数类型 | 参数说明                                    | 是否必填 |
| ----------- | ----------- |-----------------------------------------|----------- |
| TaskName      | string  | 任务名称                                    |是|
| YamlUrl   | string| yaml获取git地址                             |是|
| Namespace      | string  | 任务运行k8s namespace，默认：perception-project |否|
| GpuLimit   | int| 任务所需GPU卡数,默认为1,最大为8                     |否|
| GpuMode | string | gpu类型 RTX3090,A100,V100 默认RTX3090       |否|
| Params   | []Object| yaml中需要替换的参数                            |否|

Params Object 说明

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |----------- |
| Key      | string  |参数名称名称|是|
| Value   | string|   参数值  |是|

请求示例
```http request
curl --location --request POST 'http://0.0.0.0:8080/actuator/task/yaml' \
--header 'access_token: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkaXNwbGF5TmFtZSI6IuadqOiMl-WHryIsImN1cnJlbnRUaW1lTWlsbGlzIjoiMTY1OTA1OTkwMDkxMiIsInNhbUFjY291bnROYW1lIjoiZS1NaW5na2FpLllhbmciLCJuYW1lIjoiZS1NaW5na2FpLllhbmciLCJwZW9wbGVTb2Z0SUQiOiIwMzIzNTA3IiwiaWQiOjE1MjQ3MjYzNDE2ODM0MjUyODIsImV4cCI6MTY1OTA2MjkwMH0.6j7c2xyIlqunzfeDPgkGhnpBSLrwRhYuVepmIv05veQ' \
--header 'Content-Type: application/json' \
--data-raw '{
   "YamlUrl":"https://git-auto.zeekrlife.com/boyi.sun/test-git/-/raw/master/template.yaml",
   "TaskName":"task-name",
   "GpuLimit":1,
   "Params":[
       {
           "Key":"param",
           "Value":"mock param value"
       }
   ]
}'
```
返回参数：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | Object|   数据  |是|
| ReqUuid   | string| 请求Uuid     |是|
| PipelineID   | string| 执行PipelineID |    |是|

Data 说明 ：

| 参数名称   | 参数类型 | 参数说明     | 是否一定返回 |
| ---------- | -------- | ------------ | -- |
| PipelineID | string   | 任务ID       | 是  |
| BuildID    | string   | 工作流ID     | 是  |
| TaskName   | string   | 任务名称     | 是  |
| Status     | string   | 状态：枚举值 | 是  |
| StatusCode | int      | 状态code     | 是  |
| Creator    | string   | 创建人域账号 | 是  |
| Namespace  | string   | 命名空间     | 是  |
| Scene      | string   | 场景         | 是  |
| CreateTime | int      | 创建时间     | 是  |
| UpdateTime | int      | 更新时间     | 是  |
| StatusDesc | string   | 状态描述     | 是 |
| GpuLimit   | int      | gpu          | 是 |
| MemLimit   | int      | 内存         | 是 |
| CpuLimit   | int      | cpu          | 是 |
| Stage      | []int    | 任务步骤状态 | 是 |


返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": {
        "PipelineID": "f77b6bb3-c65d-4c6d-a2c8-61e8626b6892",
        "BuildID": "qq7qp",
        "Status": "wait",
        "StatusDesc": "排队中",
        "TaskName": "task-name",
        "Creator": "e-Mingkai.Yang",
        "Namespace": "perception-project",
        "CreateTime": 1666600979,
        "UpdateTime": 1666600979,
        "StatusCode": 1,
        "GpuLimit": 1,
        "Stage": [
            1,
            0,
            0,
            0
        ]
    },
    "ReqUuid": "4caa513c-b197-47f1-81d7-1b25f35d66ea"
}
```