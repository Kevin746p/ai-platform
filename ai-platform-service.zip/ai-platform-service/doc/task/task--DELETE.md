# 任务相关接口文档

## 取消【删除】任务
- 请求路由： /actuator/task
- 请求方式：DELETE
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数

| 参数名称      |参数类型 |  参数说明 | 是否必填 |
| ----------- | ----------- |----------- |----------- |
| PipelineID      | string  |任务ID|是|



请求示例
```http request
curl --location --request DELETE 'http://0.0.0.0:8080/actuator/task?PipelineID=72860bda-3ddb-44f9-800d-f489f47ff5d1'
```
返回参数

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|   错误信息   |是|
| Data   | object|   数据  |是|
| ReqUuid   | string| 请求Uuid     |是|


返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": null ,
    "ReqUuid": "48d7a66-ca2-4434-9934-4f228442b60e"
}
```