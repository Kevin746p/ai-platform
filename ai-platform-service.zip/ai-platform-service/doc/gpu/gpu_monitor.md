# pod 监控数据获取

## 基本信息

- 请求路由： /actuator/gpu/monitor
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数：

| 参数名称 | 参数类型 | 参数说明                    | 是否必须                      |
| -------- | -------- | --------------------------- | ----------------------------- |
| PipelineID | string | PipelineID | 是 |
| MonitorType | string | 枚举[GPUCalPower:gpu算力利用率,CPU:cpu利用率,GPUMemory:GPU显存利用率,Memory:内存利用率] | 是 |
| Start    | int      | 查询范围开始时间戳，秒级    | 否       |
| End      | int      | 查询范围结束时间戳，秒级    | 否     |
| Step     | int      | 数据返回时间间隔步长,单位秒,默认60s | 否|

请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/monitor?PipelineID=f24b1238-7054-409a-949f-7db8ba6ff625&MonitorType=GPUCalPower'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | []Object |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| Time     | int      | 时间     | 是           |
| Rate     | float64  | 利用率   | 是           |



返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [
                {"Time": 1659940758,
                 "Rate": 43.4} ,
            ],

    "ReqUuid": "35f9499c-a68a-46b9-a299-54da71ffc078"
}
```











