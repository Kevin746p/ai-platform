# 获取指定时间段的任务gpu算力利用率

## 基本信息

- 请求路由： /actuator/gpu/podCalRate
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数：

| 参数名称 | 参数类型 | 参数说明                    | 是否必须                      |
| -------- | -------- | --------------------------- | ----------------------------- |
| PipelineID | string | PipelineID | 是 |

请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/monitor?PipelineID=f24b1238-7054-409a-949f-7db8ba6ff625&'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | Object   |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称        | 参数类型 | 参数说明         | 是否一定返回 |
| --------------- | -------- | ---------------- | ------------ |
| PipelineID      | string   | PipelineID       | 是           |
| RateInFiveMin   | float64  | 5min内利用率     | 是           |
| RateInThirtyMin | float64  | 30min利用率      | 是           |
| RateInWhole     | float64  | 整个时间段利用率 | 是           |



返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": {
        		 "PipelineID": "f24b1238-7054-409a-949f-7db8ba6ff625",
                 "RateInFiveMin": 43.4,
                 "RateInThirtyMin": 43.4,
                 "RateInWhole": 43.4,
               } ,
    "ReqUuid": "35f9499c-a68a-46b9-a299-54da71ffc078"
}
```











