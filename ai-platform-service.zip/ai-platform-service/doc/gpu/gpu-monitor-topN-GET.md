# 监控数据获取topN



## 基本信息

- 请求路由： /actuator/gpu/monitorTopN
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数：

| 参数名称 | 参数类型 | 参数说明                    | 是否必须                      |
| -------- | -------- | --------------------------- | ----------------------------- |
| Limit | int | 数据量(默认5) | 是      |
| Target | string | 排序指标(默认gpu_cal_rate)cpu_rate：cpu使用率, gpu_mem_rate： gpu显存利用率,gpu_cal_rate：gpu算力利用率, memory_use：内存占用 | 是 |
| IsDesc | bool | 是否倒序（默认True） | 是 |
| IsRange | bool | 是否范围查询(默认否) | 是 |
| Start | string | 查询范围开始日期(Y-m-d) | 否(IsRange为True是必须) |
| End | string | 查询范围结束日期(Y-m-d) | 否(IsRange为True是必须) |
| Target | string | 指定查询日期(Y-m-d) | 否((IsRange为False是必须)) |

请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/monitorTopN？Limit=5&&Target=gpu_cal_rate'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | Object[] |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称     | 参数类型 | 参数说明       | 是否一定返回 |
| ------------ | -------- | -------------- | ------------ |
| PipelineID   | string   | 场景           | 是           |
| TaskName     | string   | 任务类型       | 是           |
| ResourceType | string   | 任务类型       | 是           |
| Scene        | string   | 场景           | 是           |
| Creator      | string   | 创建人(域账号) | 是           |
| OccupyGpu    | float    | 占卡时长(分)   | 是           |
| GpuCalRate   | float    | gpu算力利用率  | 是           |
| GpuMode      | string   | gpu类型        | 是           |



返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [{
        "PipelineID":"9cbfc477-128a-472f-86a1-78bb24594593",
        "TaskName":"test",
        "ResourceType":"notebook",
        "Scene":"trafficlightxc",
        "Creator":"xxx",
        "OccupyGpu":222.2,
        "OccupyRtx3090":222.2,
        "GpuMode":"A100"
    }]
           ,
    "ReqUuid": "35f9499c-a68a-46b9-a299-54da71ffc078"
}
```





