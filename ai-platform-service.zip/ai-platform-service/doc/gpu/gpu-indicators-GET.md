# 监控大屏指标获取

根据参数返回GPU利用率，算力

## 基本信息

- 请求路由： /actuator/gpu/indicators
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数：

| 参数名称 | 参数类型 | 参数说明                    | 是否必须                      |
| -------- | -------- | --------------------------- | ----------------------------- |
| Start    | int      | 查询范围开始时间戳，秒级    | 否       |
| End      | int      | 查询范围结束时间戳，秒级    | 否     |
| Step     | int      | 数据返回时间间隔步长,单位秒 | 否|

请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/indicators'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | Object   |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称             | 参数类型 | 参数说明                                                | 是否一定返回 |
| -------------------- | -------- | ------------------------------------------------------- | ------------ |
| GPUCalPower          | int      | GPU算力[A100 780 TFLOPS，可配置] | 是           |
| GPUClusterPowerRate  | []Object | GPU集群利用率(根据算力计算)                             | 是           |
| GPUClusterMemoryRate | []Object | GPU集群显存利用率                                       | 是           |

GPUClusterPowerRate，GPUClusterMemoryRate说明：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| Time     | int      | 时间     | 是           |
| Rate     | float64  | 利用率   | 是           |

返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": 
        {
            "GPUCalPower": 1233,
            "GPUClusterPowerRate": [
                {"Time": 1659940758,
                 "Rate": 43.4} ,
            ],
            "GPUClusterMemoryRate": [
                {"Time": 1659940758,
                 "Rate": 43.4} ,
            ]
        },
    "ReqUuid": "35f9499c-a68a-46b9-a299-54da71ffc078"
}
```

集群GPU利用率(算力)计算公式

~~~math
Rate = (集群RTX3090利用率*集群RTX3090总算力+集群A100利用率*集群A100总算力)/(集群RTX3090总算力+集群A100总算力)
~~~



