# 实时获取按场景聚合的gpu利用率



## 基本信息

- 请求路由： /actuator/gpu/sceneMonitor
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80



请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/sceneMonitor'

```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | Object[] |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称     | 参数类型 | 参数说明      | 是否一定返回 |
| ------------ | -------- | ------------- | ------------ |
| Scene        | string   | 场景          | 是           |
| CountA100    | int      | A100卡数      | 是           |
| CountRtx3090 | int      | 3090卡数      | 是           |
| ResourceType | string   | 资源类型      | 是           |
| GpuCalRate   | float    | GPU算力利用率 | 是           |



返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [{
        "Scene":"trafficlightxc",
        "ResourceType":"notebook",
        "CountA100":4,
        "CountRtx3090":4,
        "GpuCalRate":0.33 
    }]
           ,
    "ReqUuid": "35f9499c-a68a-46b9-a299-54da71ffc078"
}
```





