# 监控数据优化



## 基本信息

- 请求路由： /actuator/gpu/monitorSummary
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数：

| 参数名称 | 参数类型 | 参数说明                    | 是否必须                      |
| -------- | -------- | --------------------------- | ----------------------------- |
| IsRange | bool | 是否范围查询(默认否) | 是      |
| Start    | string | 查询范围开始日期(Y-m-d) | 否(IsRange为True是必须) |
| End | string | 查询范围结束日期(Y-m-d) | 否(IsRange为True是必须) |
| Target | string | 指定查询日期(Y-m-d) | 否((IsRange为False是必须)) |

请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/monitorSummary？IsRange=False&&Target=2022-10-11'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | Object[] |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称          | 参数类型 | 参数说明         | 是否一定返回 |
| ----------------- | -------- | ---------------- | ------------ |
| Scene             | string   | 场景             | 是           |
| ResourceType      | string   | 任务类型         | 是           |
| GpuCalRateA100    | float    | A100算力利用率   | 是           |
| GpuCalRateRtx3090 | float    | 3090算力利用率   | 是           |
| OccupyA100        | float    | A100占卡时长(分) | 是           |
| OccupyRtx3090     | float    | 3090占卡时长(分) | 是           |



返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [{
        "Scene":"trafficlightxc",
        "ResourceType":"notebook",
        "GpuCalRateA100":0.33,
        "GpuCalRateRtx3090":0.12,
        "OccupyA100":222.2,
        "OccupyRtx3090":222.2,
        
    }]
           ,
    "ReqUuid": "35f9499c-a68a-46b9-a299-54da71ffc078"
}
```





