# GPU 节点 Pod基本信息

返回调用时刻，系统内GPU服务器Pod占用信息

## 基本信息
- 请求路由： /actuator/gpu/pods
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求示例
```http request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/pods'
```
返回参数：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|     错误信息   |是|
| Data   | []Object|    |是|
| ReqUuid   | string| 请求Uuid     |是|

Object 说明：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| HostName      | string  |节点名称|是|
| GpuMode   | string |     GPU类型   |是|
| AvgUsage   | float|    节点平均使用率|是|
| Pod   | string|   Pod名称  |是|
| PodUsage   | int|   Pod占用Gpu数量  |是|
| HostUsage   | int|   节点占用Gpu数量  |是|


返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [
        {
            "GpuMode": "RTX3090",
            "HostName": "zeekr-gpu-work-16",
            "AvgUsage": 95.10,
            "Pod": "parking-train-exp-adam-cos3-qzbd8",
            "PodUsage" : 4 ,
            "HostUsage": 8
        },
        {
            "GpuMode": "RTX3090",
            "HostName": "zeekr-gpu-work-16",
            "AvgUsage": 95.10,
            "Pod": "mono3d-dd3d-pretrained-c7qzw",
            "PodUsage" : 4 ,
            "HostUsage": 8
        }
    ],
    "ReqUuid": "9cbfc477-128a-472f-86a1-78bb24594593"
}
```