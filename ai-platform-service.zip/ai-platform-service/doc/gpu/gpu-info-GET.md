# GPU 卡整体数量

返回调用时刻，系统内所有可用GPU卡总数和已使用数量


## 基本信息
- 请求路由： /actuator/gpu/info
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80


请求示例
```http request
curl --location --request GET 'http://0.0.0.0:8080/actuator/gpu/info'
```
返回参数：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|     错误信息   |是|
| Data   | []Object|    |是|
| ReqUuid   | string| 请求Uuid     |是|

Object 说明：

| 参数名称      |参数类型 | 参数说明     | 是否一定返回 |
| ----------- | ----------- |----------|----------- |
| GpuMode      | string  | GPU类型    |是|
| Count   | int| GPU卡总数   |是|
| Used   | int| 已使用数量    |是|
| NotUsed   | int| 未使用数量    |是|
| EightNode   | int| 空闲8卡节点数  |是|
| FourNode   | int| 空闲4卡节点数  |是|
| NodeCount   | int| gpu类型节点数 |是|


返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [
        {
            "GpuMode": "RTX3090",
            "Count": 8,
            "Used": 0,
            "NotUsed": 8,
            "EightNode": 1,
            "FourNode": 1,
            "NodeCount": 7
        },
        {
            "GpuMode": "A100",
            "Count": 24,
            "Used": 0,
            "NotUsed": 24,
            "EightNode": 3,
            "FourNode": 3,
            "NodeCount": 40
        }
    ],
    "ReqUuid": "9cbfc477-128a-472f-86a1-78bb24594593"
}
```