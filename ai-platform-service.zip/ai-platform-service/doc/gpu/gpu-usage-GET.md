# GPU 平均使用率

查询系统内GPU节点平均使用率

## 基本信息
- 请求路由： /actuator/gpu/usage
- 请求方式：POST
- 传参方式：json
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

返回参数：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| Start      | int  |查询范围开始时间戳，秒级|否，若End不为空，则必传|
| End   | string| 查询范围结束时间戳，秒级   |否，若Start不为空，则必传|
| HostName   | string|节点名称，不传则返回全部节点    |否|
| Step   | string|   数据返回时间间隔步长，eg："1h,1d" |否|


请求示例
```http request
curl --location --request POST 'http://10.114.242.31:32001/ai-platform/actuator/gpu/usage' \
--header 'Content-Type: application/json' \
--header 'Cookie: JSESSIONID=QtGab3g-gPgM1YC-wWPEuTE7AU5VEyCzc5K1SSss' \
--data-raw '{
    "Start":1658212759 ,
    "End":1660891189,
    "Step":"1d",
    "NodeName":"zeekr-test-k8s-node-10"
}'```


返回参数：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| RetCode      | int  |错误码|是|
| Message   | string|     错误信息   |是|
| Data   | []Object|    |是|
| ReqUuid   | string| 请求Uuid     |是|``

Data Object 说明：

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
| HostName      | string  |节点名称|是|
| GpuMode   | string|     GPU类型   |是|
| AvgUsageWithTime   | []Object|     平均使用率  |否|
| Instance   | string|     节点IP  |是|



AvgUsage Object 说明 

| 参数名称      |参数类型 |  参数说明 | 是否一定返回 |
| ----------- | ----------- |----------- |----------- |
|Time      | int64 |监控数据采集时间戳，秒级|是|
| AvgUsage   | float64|    平均使用率  |是|


返回示例
```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [
        {
            "GpuMode": "A100",
            "HostName": "zeekr-test-k8s-node-10",
            "Instance": "",
            "AvgUsageWithTime": [
                {
                    "Time": 1659940758,
                    "AvgUsage": 0
                },
                {
                    "Time": 1660027158,
                    "AvgUsage": 0
                },
                {
                    "Time": 1660113558,
                    "AvgUsage": 41.199999999999996
                },
                {
                    "Time": 1660199958,
                    "AvgUsage": 98.19999999999999
                },
                {
                    "Time": 1660286358,
                    "AvgUsage": 100
                },
                {
                    "Time": 1660372758,
                    "AvgUsage": 100
                },
                {
                    "Time": 1660459158,
                    "AvgUsage": 100
                },
                {
                    "Time": 1660545558,
                    "AvgUsage": 100
                },
                {
                    "Time": 1660631958,
                    "AvgUsage": 0
                },
                {
                    "Time": 1660718358,
                    "AvgUsage": 0
                },
                {
                    "Time": 1660891158,
                    "AvgUsage": 0
                }
            ]
        }
    ],
    "ReqUuid": "35f9499c-a68a-46b9-a299-54da71ffc078"
}
```