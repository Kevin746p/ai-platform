## 日志查询接口文档

- 请求路由： /actuator/log
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数

| 参数名称     | 参数类型 | 参数说明                        | 是否必填 |
| ------------ | -------- | ------------------------------- | -------- |
| Uuid         | string   | 操作源数据uuid                  | 是       |
| BusinessType | string   | 业务类型，枚举：notebook,task   | 是       |
| OperateType  | string   | 操作类型，枚举：post,delete,put | 否       |
| Creator      | string   | 创建人                          | 否       |

请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/log?Uuid=322fb455-d4b9-4e1e-be14-e8809a297fef&BusinessType=task&OperateType=put'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | []Object | 任务信息 | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |
| Count    | int      | 总数     | 是           |

Data 说明 ：

| 参数名称     | 参数类型 | 参数说明                        | 是否一定返回 |
| ------------ | -------- | ------------------------------- | ------------ |
| Uuid         | string   | 日志uuid                        | 是           |
| ReqUuid      | string   | 请求id                          | 是           |
| BusinessType | string   | 业务类型,枚举：notebook,task    | 是           |
| OperateType  | string   | 操作类型，枚举：post,delete,put | 是           |
| ChangeField  | string   | 修改字段名                      | 是           |
| CurrentValue | string   | 本次字段值                      | 是           |
| OldValue     | string   | 上次字段值                      | 是           |
| Creator      | string   | 创建人域账号                    | 是           |
| CreateTime   | int      | 创建时间                        | 是           |
| Remark       | string   | 备注                            | 是           |

 返回示例

~~~http-reques
 {
    "RetCode": 0,
    "Message": "",
    "Data": [
        {
            "Uuid": "322fb455-d4b9-4e1e-be14-e8809a297fef",
            "ReqUuid": "c6c3e8f9-523d-4796-87c1-591973752e92",
            "BusinessType": "task",
            "OperateType": "put",          
            "ChangeField":"GpuLimit",
            "CurrentValue":"0",
            "OldValue":"1",
            "Creator": "e-YanLin.Wang",
            "CreateTime": 1662106669,
        }
    ],
    "ReqUuid": "6d9a83e1-0e92-4858-9c90-8b7c7c7b92f5",
    "Count": 1
}
~~~



