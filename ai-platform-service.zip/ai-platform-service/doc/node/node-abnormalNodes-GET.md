# 异常节点列表


## 基本信息

- 请求路由： /actuator/node/abnormalNodes
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数：

请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/node/abnormalNodes'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | []Object |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称       | 参数类型 | 参数说明     | 是否一定返回 |
| -------------- | -------- | ------------ | ------------ |
| NodeName       | string   | 节点名       | 是           |
| NodeIP         | string   | 节点ip       | 是           |
| NodeType       | string   | 节点类型     | 是           |
| PodList        | []object | 使用gpu的pod | 是           |
| AbnormalReason | string   | 异常原因     | 是           |
| AbnormalInfo   | string   | 异常信息     | 是           |

PodList说明:

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| PodName  | string   | pod名    | 是           |
| GpuCount | int      | 占卡数   | 是           |

返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [
        {
            "NodeName": "zeekr-test-k8s-node-14",
            "NodeIP": "10.114.242.11",
            "NodeType": "RTX3090",
            "PodList": [
                {
                    "PodName": "trafficlane-prelabel-7bb48f589c-snfwt",
                    "GpuCount": 1
                }
            ],
            "AbnormalReason": "基础组件异常",
            "AbnormalInfo": "busybox-ds,fluent-bit,process-exporter,gpu-feature-discovery,"
        }
    ],
    "ReqUuid": "d41c0976-5f15-4888-b19c-ab7557ddcee0"
}
```





