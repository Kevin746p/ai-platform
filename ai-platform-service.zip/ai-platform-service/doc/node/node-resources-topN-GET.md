# 节点资源使用topN

## 基本信息

- 请求路由： /actuator/node/resourcesTopN
- 请求方式：GET
- 测试线：ai-platform.perception-project.svc.cluster.local:80
- 生产线：ai-platform.perception-project.svc.cluster.local:80

请求参数：

| 参数名称 | 参数类型 | 参数说明             | 是否必须     |
| -------- | -------- | -------------------- | ------------ |
| Limit    | int      | 错误码               | 否(默认10)   |
| Target   | string   | 指标(cpu,gpu,memory) | 是           |
| IsDesc   | bool     | 是否倒序             | 否(默认ture) |



请求示例

```http-request
curl --location --request GET 'http://0.0.0.0:8080/actuator/node/resourcesTop?Limit=1&Target=cpu'
```

返回参数：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| RetCode  | int      | 错误码   | 是           |
| Message  | string   | 错误信息 | 是           |
| Data     | []Object |          | 是           |
| ReqUuid  | string   | 请求Uuid | 是           |

Data 说明：

| 参数名称 | 参数类型 | 参数说明 | 是否一定返回 |
| -------- | -------- | -------- | ------------ |
| NodeName | string   | 节点名   | 是           |
| NodeIP   | string   | 节点ip   | 是           |
| Rate     | float    | 使用率   | 是           |



返回示例

```json
{
    "RetCode": 0,
    "Message": "",
    "Data": [
        {
            "NodeName": "zeekr-gpu-work-32",
            "NodeIP": "10.114.241.73",
            "Rate": 61.34415504520506
        }
    ],
    "ReqUuid": "7a35f018-a2c7-4b70-b05a-b75ef5b2cd67"
}
```





