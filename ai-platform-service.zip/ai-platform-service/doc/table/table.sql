-- auto-generated definition
create table tbl_operate_log
(
    id            int auto_increment comment '自增ID'
        primary key,
    uuid          varchar(255)                        not null comment '操作源数据uuid',
    req_uuid      varchar(255)                        not null comment '请求id',
    business_type varchar(50)                         not null comment '业务类型 (task,notebook)',
    operate_type  varchar(50) null comment '操作类型（post,delete,put）',
    change_field  varchar(50) null comment '修改字段名',
    current_value varchar(255) null comment '本次参数值',
    old_value     varchar(255) null comment '上次参数值',
    remark        varchar(255) null comment '备注',
    create_by     varchar(50) null comment '创建人',
    create_time   timestamp default CURRENT_TIMESTAMP not null comment '创建时间'
) comment '操作日志';

-- ----------------------------
-- Table structure for tbl_task_monitor
-- ----------------------------
DROP TABLE IF EXISTS `tbl_task_monitor`;
CREATE TABLE `tbl_task_monitor`
(
    `id`              int                                     NOT NULL AUTO_INCREMENT COMMENT 'id',
    `pipeline_id`     varchar(100)                            not null comment 'pipeline id',
    `scene`           varchar(50) null comment '场景(团队)',
    `resource_type`   varchar(50) null comment '资源类型',
    `cpu_rate`        DECIMAL(5, 2) DEFAULT NULL comment 'cpu使用率',
    `gpu_mem_rate`    DECIMAL(5, 2) DEFAULT NULL comment 'gpu显存利用率',
    `gpu_cal_rate`    DECIMAL(5, 2) DEFAULT NULL comment 'gpu算力利用率',
    `memory_use`      DECIMAL(5, 2) DEFAULT NULL comment '内存使用量',

    `gpu_occupy_time` DECIMAL(6, 2) DEFAULT NULL comment 'gpu占用时长',
    `gpu_mode`        varchar(30)   default NULL comment 'gpu类型',
    `is_finish`       TINYINT(4) DEFAULT NULL comment '是否完成',
    `create_date`     date                                    not null comment '创建日期',
    `create_time`     timestamp     default CURRENT_TIMESTAMP not null comment '创建时间',
    unique (pipeline_id, create_date),
    PRIMARY KEY (`id`) USING BTREE,
    KEY               `ix_tbl_task_monitor_data_1` (`scene`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT = Compact COMMENT = '任务监控数据';
