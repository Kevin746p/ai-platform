## 接口文档

###接口列表
  - [任务相关](task) <br>
        &emsp;[创建任务](task/task--POST.md) <br>
        &emsp;[查询任务信息](task/task--GET.md) <br>
        &emsp;[取消(删除)任务](task/task--DELETE.md) <br>
        &emsp;[重试任务](task/task-retry-POST.md) <br>
        &emsp;[通过Yaml创建训练任务](task/task-yaml-POST.md) <br>
        &emsp;[获取任务关联Pods](task/task-pods-GET.md) <br>
  - [GPU相关](gpu) <br>
        &emsp;[GPU数量](gpu/gpu-info-GET.md) <br>
        &emsp;[GPU Pods占用情况](gpu/gpu-pods-GET.md) <br>
        &emsp;[GPU平均使用率](gpu/gpu-usage-GET.md) <br>
        
        
### 发布流程
- 镜像仓库使用域账号登录
   `sudo docker login devops-harbor.zeekrlife.com`
- 打镜像，获取版本号
```code
    ./build_image.sh
```
- kubeSphere 修改镜像版本号发布:
    [kubeSphere测试环境](https://automl-dev.zeekrlife.com)
    
    [kubeSphere线上环境](https://automl.zeekrlife.com)

    
          