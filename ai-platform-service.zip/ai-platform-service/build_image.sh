#!/bin/bash
# TODO 使用公共ci
go build
current=`date "+%Y%m%d%H%M%S"`
sudo docker build -t ai-platform-service:${current} .
sudo docker tag ai-platform-service:${current} harbor-hz.zeekrlife.com/kubeflow/ai-platform-service:${current}
sudo docker push  harbor-hz.zeekrlife.com/kubeflow/ai-platform-service:${current}
echo harbor-hz.zeekrlife.com/kubeflow/ai-platform-service:${current}